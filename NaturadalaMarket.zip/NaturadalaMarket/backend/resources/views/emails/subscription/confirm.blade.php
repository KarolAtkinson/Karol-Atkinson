<!doctype html>
<html lang="pl">
<body style="font-family: Arial, sans-serif; color: #2f3b31; line-height: 1.6;">
    <h2>Potwierdź zapis do newslettera</h2>
    <p>Dziękujemy za zainteresowanie Naturadała. Kliknij poniższy przycisk, aby potwierdzić zapis. Będziemy wysyłać Ci wiadomości o nowych produktach, a po potwierdzeniu otrzymasz {{ $discount }}% zniżki na wszystkie produkty.</p>
    <p><a href="{{ $confirmUrl }}" style="display:inline-block;padding:12px 22px;background:#37483a;color:#fff;text-decoration:none;">Potwierdzam zapis</a></p>
    <p>Zniżka jest naliczana po zalogowaniu na konto z tym samym, zweryfikowanym adresem e-mail. Link jest ważny 7 dni. Jeśli to nie Ty zapisałeś(-aś) ten adres, zignoruj wiadomość.</p>
</body>
</html>
