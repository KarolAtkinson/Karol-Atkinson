<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <title>@yield('title') | Naturadała Partner</title>
    <link rel="stylesheet" href="{{ asset('styles.css') }}">
    <script src="{{ asset('image-fallback.js') }}"></script>
    <script src="{{ asset('en-translations.js') }}" defer></script>
    <script src="{{ asset('cookie-consent.js') }}" defer></script>
    <script src="{{ asset('app.js') }}" defer></script>
</head>
<body class="retailer-workspace-page">
    <a class="skip-link" href="#main">Przejdź do treści</a>
    <header class="retailer-header">
        <div class="brand-language-group">
            <a class="brand" href="{{ route('retailer.workspace') }}" aria-label="Naturadała — przestrzeń partnera">
                <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
            </a>
            @include('shared.language-switcher')
        </div>
        <nav class="retailer-navigation" aria-label="Nawigacja partnera">
            <a href="{{ route('retailer.workspace') }}" aria-current="page">Katalog hurtowy</a>
            <a href="{{ route('basket.show') }}">Zapytania / koszyk</a>
            <a href="{{ route('account.show') }}">Moje konto</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="text-link" type="submit">Wyloguj się</button>
            </form>
        </nav>
    </header>
    <main class="retailer-main" id="main">
        @yield('content')
    </main>
    <footer class="retailer-footer">
        <span>© {{ now()->year }} Naturadała</span>
        <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button>
        <span>Przestrzeń dla zatwierdzonych partnerów handlowych</span>
    </footer>
    @include('shared.cookie-consent')
</body>
</html>
