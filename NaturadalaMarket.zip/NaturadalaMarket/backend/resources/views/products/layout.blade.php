<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <meta name="description" content="@yield('description', 'Poznaj produkty Naturadała dla klientów i zatwierdzonych partnerów hurtowych.')">
    <title>@yield('title', 'Produkty') | Naturadała</title>
    <link rel="preconnect" href="https://naturadala.pl">
    <link rel="stylesheet" href="{{ asset('styles.css') }}">
    <script src="{{ asset('image-fallback.js') }}"></script>
    <script src="{{ asset('en-translations.js') }}" defer></script>
    <script src="{{ asset('cookie-consent.js') }}" defer></script>
    <script src="{{ asset('app.js') }}" defer></script>
</head>
<body class="marketplace-page">
    <a class="skip-link" href="#main">Przejdź do treści</a>
    @include('shared.announcement')
    <header class="site-header">
        <div class="brand-language-group">
            <a class="brand" href="{{ route('home') }}" aria-label="Naturadała — strona główna">
                <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
            </a>
            @include('shared.language-switcher')
        </div>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">
            <span class="menu-toggle-label">Menu</span><span class="menu-icon" aria-hidden="true"><i></i><i></i></span>
        </button>
        <nav class="primary-navigation" id="primary-navigation" aria-label="Nawigacja główna">
            <a href="{{ route('home') }}">Strona główna</a>
            <a href="{{ route('products.index') }}">Produkty</a>
            <a href="{{ route('home') }}#wspolpraca">Współpraca</a>
            <a href="{{ route('home') }}#o-nas">O Naturadale</a>
            <a href="{{ route('home') }}#kontakt">Kontakt</a>
        </nav>
        <div class="header-actions">
            @guest
                <a class="account-link" href="{{ route('login') }}">Zaloguj się</a>
                @if (config('marketplace.registration_enabled'))
                    <a class="button button-small button-outline" href="{{ route('register') }}">Zarejestruj się</a>
                @endif
            @else
                <a class="account-link" href="{{ route('account.show') }}">Moje konto</a>
                @if (auth()->user()->isApprovedRetailer() && (! config('features.retailer_maintenance') || auth()->user()->hasRole('admin')))
                    <a class="account-link" href="{{ route('retailer.workspace') }}">Przestrzeń partnera</a>
                @endif
                @if (auth()->user()->hasVerifiedEmail())
                    <a class="account-link" href="{{ route('wishlist.index') }}">Ulubione</a>
                @endif
            @endguest
            <a class="button button-small button-dark" href="{{ route('products.index') }}">Oferta <span aria-hidden="true">↗</span></a>
            @include('shared.basket-button')
        </div>
    </header>
    <main id="main">
        @yield('content')
    </main>
    @include('shared.newsletter')
    <footer class="site-footer">
        <a class="footer-brand" href="{{ route('home') }}" aria-label="Naturadała — strona główna">
            <img src="https://naturadala.pl/wp-content/uploads/2026/02/Logo_NaturaDala.png" alt="Naturadała">
        </a>
        <p>Codzienne wsparcie organizmu<br>tak jak natura dała.</p>
        <nav aria-label="Nawigacja w stopce">
            <a href="{{ route('products.index') }}">Produkty</a>
            <a href="{{ route('home') }}#wspolpraca">Współpraca</a>
            <a href="{{ route('home') }}#o-nas">O nas</a>
            <a href="mailto:kontakt@naturadala.pl">Kontakt</a>
        </nav>
        <span class="copyright">© {{ now()->year }} Naturadała <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button></span>
    </footer>
    @include('shared.basket-panel')
    @include('shared.cookie-consent')
</body>
</html>
