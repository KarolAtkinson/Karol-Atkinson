@extends('products.layout')

@section('title', $product->name)
@section('description', $product->short_description)

@section('content')
    <section class="product-detail-section">
        <a class="text-link product-breadcrumb" href="{{ route('products.index') }}">← Wszystkie produkty</a>
        <article class="product-detail-card">
            <div class="product-image-wrap product-detail-image">
                @if ($product->image_url)
                    <img src="{{ $product->image_url }}" alt="{{ $product->name }}">
                @else
                    <span class="product-image-placeholder">Naturadała</span>
                @endif
            </div>
            <div class="product-details">
                <p class="eyebrow">Produkt Naturadała · {{ $product->sku }}</p>
                <h1 class="product-detail-title">{{ $product->name }}</h1>
                <p class="product-description">{{ $product->description }}</p>
                <ul class="product-facts">
                    @if ($product->size_label)
                        <li><span>Opakowanie</span><strong>{{ $product->size_label }}</strong></li>
                    @endif
                    <li><span>Forma</span><strong>Żel / galareta</strong></li>
                    <li><span>Minimalna ilość</span><strong>{{ $product->minimum_order_quantity }} szt.</strong></li>
                    @if ($product->stock_quantity !== null)
                        <li><span>Dostępność</span><strong>{{ $product->stock_quantity >= $product->minimum_order_quantity ? 'Dostępny' : 'Brak dostępnej ilości minimalnej' }}</strong></li>
                    @endif
                </ul>
                <div class="catalogue-price detail-price">
                    @if ($approvedRetailer && $product->wholesalePrices->isNotEmpty())
                        <span>Cena partnerska</span>
                        @foreach ($product->wholesalePrices as $price)
                            <strong>{{ number_format((float) $price->unit_price, 2, ',', ' ') }} zł <small>netto · od {{ $price->minimum_quantity }} szt.</small></strong>
                        @endforeach
                    @elseif (! $approvedRetailer && $product->retail_price !== null)
                        @if (auth()->user()?->isSubscriber())
                            <span>Cena dla subskrybenta (−{{ config('features.subscriber_discount_percent') }}%)</span>
                            <strong>{{ number_format($product->subscriberPrice(), 2, ',', ' ') }} zł <s class="price-was">{{ number_format((float) $product->retail_price, 2, ',', ' ') }} zł</s></strong>
                        @else
                            <span>Cena detaliczna</span>
                            <strong>{{ number_format((float) $product->retail_price, 2, ',', ' ') }} zł</strong>
                            <small class="price-hint"><a href="#newsletter">Zapisz się do newslettera: −{{ config('features.subscriber_discount_percent') }}% na wszystkie produkty</a></small>
                        @endif
                    @else
                        <span>Warunki sprzedaży</span>
                        <strong>Cena dostępna po kontakcie</strong>
                    @endif
                </div>
                <div class="product-detail-actions">
                    @auth
                        @if (auth()->user()->hasVerifiedEmail())
                            @if ($product->stock_quantity === null || $product->stock_quantity >= $product->minimum_order_quantity)
                                <form method="POST" action="{{ route('basket.store', $product) }}">
                                    @csrf
                                    <label class="quantity-label" for="quantity">Ilość</label>
                                    <input class="quantity-input" id="quantity" name="quantity" type="number" min="{{ $product->minimum_order_quantity }}" max="{{ min(999, $product->stock_quantity ?? 999) }}" value="{{ $product->minimum_order_quantity }}" required>
                                    <button class="button button-dark" type="submit">Dodaj do koszyka <span aria-hidden="true">+</span></button>
                                </form>
                            @else
                                <p class="form-hint">Obecny stan nie pozwala zrealizować minimalnej ilości zamówienia.</p>
                            @endif
                            @error('quantity') <span class="field-error">{{ $message }}</span> @enderror
                            <form method="POST" action="{{ $wishlisted ? route('wishlist.destroy', $product) : route('wishlist.store', $product) }}">
                                @csrf
                                @if ($wishlisted) @method('DELETE') @endif
                                <button class="button button-outline" type="submit">{{ $wishlisted ? 'Usuń z ulubionych' : 'Dodaj do ulubionych' }}</button>
                            </form>
                        @else
                            <p class="form-hint">Potwierdź adres e-mail, aby korzystać z koszyka i listy ulubionych.</p>
                        @endif
                    @else
                        <a class="button button-dark" href="{{ route('login') }}">Zaloguj się, aby dodać do koszyka <span aria-hidden="true">↗</span></a>
                    @endauth
                    @if (! $approvedRetailer && (! config('features.retailer_maintenance') || auth()->user()?->hasRole('admin')))
                        <a class="text-link" href="{{ auth()->check() && auth()->user()->hasVerifiedEmail() ? route('retailer.application') : route('register') }}">Zapytaj o współpracę hurtową <span aria-hidden="true">↗</span></a>
                    @endif
                </div>
                <p class="product-note">Informacje handlowe i aktualna dostępność wymagają potwierdzenia. Skład, porcjowanie i sposób użycia sprawdź na oficjalnym opakowaniu produktu.</p>
            </div>
        </article>
    </section>
@endsection
