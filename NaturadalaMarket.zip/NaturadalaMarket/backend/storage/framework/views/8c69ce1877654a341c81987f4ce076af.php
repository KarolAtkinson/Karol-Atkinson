<section class="newsletter" id="newsletter" aria-labelledby="newsletter-title">
    <div class="newsletter-copy">
        <p class="eyebrow"><span class="eyebrow-line"></span> Newsletter</p>
        <h2 id="newsletter-title">Nowości i <em><?php echo e(config('features.subscriber_discount_percent')); ?>% zniżki.</em></h2>
        <p>Zapisz się, a powiadomimy Cię e-mailem o nowych produktach. Subskrybenci mają <?php echo e(config('features.subscriber_discount_percent')); ?>% zniżki na wszystkie produkty po zalogowaniu na konto z tym samym adresem e-mail.</p>
    </div>
    <form class="newsletter-form" method="POST" action="<?php echo e(route('subscription.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <label for="newsletter-email">Adres e-mail</label>
        <div class="newsletter-row">
            <input id="newsletter-email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="email" maxlength="190" required>
            <button class="button button-dark" type="submit">Zapisuję się <span aria-hidden="true">↗</span></button>
        </div>
        <input class="hp-field" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
        <label class="checkbox-label newsletter-consent">
            <input type="checkbox" name="consent" value="1" <?php if(old('consent')): echo 'checked'; endif; ?> required>
            <span>Zgadzam się na otrzymywanie e-mailem informacji o nowych produktach Naturadała. Zgodę mogę w każdej chwili wycofać, klikając link wypisania w wiadomości.</span>
        </label>
        <?php if(session('subscription_status') === 'check-email'): ?>
            <p class="status-message" role="status">Sprawdź skrzynkę e-mail i kliknij link potwierdzający, aby dokończyć zapis.</p>
        <?php endif; ?>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" role="alert"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['consent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" role="alert"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </form>
</section>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/shared/newsletter.blade.php ENDPATH**/ ?>