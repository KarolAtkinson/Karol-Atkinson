<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <meta name="description" content="<?php echo $__env->yieldContent('description', 'Poznaj produkty Naturadała dla klientów i zatwierdzonych partnerów hurtowych.'); ?>">
    <title><?php echo $__env->yieldContent('title', 'Produkty'); ?> | Naturadała</title>
    <link rel="preconnect" href="https://naturadala.pl">
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <script src="<?php echo e(asset('image-fallback.js')); ?>"></script>
    <script src="<?php echo e(asset('en-translations.js')); ?>" defer></script>
    <script src="<?php echo e(asset('cookie-consent.js')); ?>" defer></script>
    <script src="<?php echo e(asset('app.js')); ?>" defer></script>
</head>
<body class="marketplace-page">
    <a class="skip-link" href="#main">Przejdź do treści</a>
    <?php echo $__env->make('shared.announcement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <header class="site-header">
        <div class="brand-language-group">
            <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="Naturadała — strona główna">
                <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
            </a>
            <?php echo $__env->make('shared.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">
            <span class="menu-toggle-label">Menu</span><span class="menu-icon" aria-hidden="true"><i></i><i></i></span>
        </button>
        <nav class="primary-navigation" id="primary-navigation" aria-label="Nawigacja główna">
            <a href="<?php echo e(route('home')); ?>">Strona główna</a>
            <a href="<?php echo e(route('products.index')); ?>">Produkty</a>
            <a href="<?php echo e(route('home')); ?>#wspolpraca">Współpraca</a>
            <a href="<?php echo e(route('home')); ?>#o-nas">O Naturadale</a>
            <a href="<?php echo e(route('home')); ?>#kontakt">Kontakt</a>
        </nav>
        <div class="header-actions">
            <?php if(auth()->guard()->guest()): ?>
                <a class="account-link" href="<?php echo e(route('login')); ?>">Zaloguj się</a>
                <?php if(config('marketplace.registration_enabled')): ?>
                    <a class="button button-small button-outline" href="<?php echo e(route('register')); ?>">Zarejestruj się</a>
                <?php endif; ?>
            <?php else: ?>
                <a class="account-link" href="<?php echo e(route('account.show')); ?>">Moje konto</a>
                <?php if(auth()->user()->isApprovedRetailer() && (! config('features.retailer_maintenance') || auth()->user()->hasRole('admin'))): ?>
                    <a class="account-link" href="<?php echo e(route('retailer.workspace')); ?>">Przestrzeń partnera</a>
                <?php endif; ?>
                <?php if(auth()->user()->hasVerifiedEmail()): ?>
                    <a class="account-link" href="<?php echo e(route('wishlist.index')); ?>">Ulubione</a>
                <?php endif; ?>
            <?php endif; ?>
            <a class="button button-small button-dark" href="<?php echo e(route('products.index')); ?>">Oferta <span aria-hidden="true">↗</span></a>
            <?php echo $__env->make('shared.basket-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </header>
    <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('shared.newsletter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <footer class="site-footer">
        <a class="footer-brand" href="<?php echo e(route('home')); ?>" aria-label="Naturadała — strona główna">
            <img src="https://naturadala.pl/wp-content/uploads/2026/02/Logo_NaturaDala.png" alt="Naturadała">
        </a>
        <p>Codzienne wsparcie organizmu<br>tak jak natura dała.</p>
        <nav aria-label="Nawigacja w stopce">
            <a href="<?php echo e(route('products.index')); ?>">Produkty</a>
            <a href="<?php echo e(route('home')); ?>#wspolpraca">Współpraca</a>
            <a href="<?php echo e(route('home')); ?>#o-nas">O nas</a>
            <a href="mailto:kontakt@naturadala.pl">Kontakt</a>
        </nav>
        <span class="copyright">© <?php echo e(now()->year); ?> Naturadała <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button></span>
    </footer>
    <?php echo $__env->make('shared.basket-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('shared.cookie-consent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/products/layout.blade.php ENDPATH**/ ?>