

<?php $__env->startSection('title', 'Rejestr umów partnerów'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja · rejestr</p>
            <h1 class="auth-title">Umowy<br><em>partnerów.</em></h1>
        </div>
        <a class="button button-outline button-small" href="<?php echo e(route('admin.retailers.directory')); ?>">Baza partnerów</a>
    </div>
    <p class="auth-description">Zarządzaj metadanymi umów przypisanymi do zatwierdzonych firm. Ten rejestr nie przechowuje plików ani treści prawnej i nie zastępuje podpisanej umowy.</p>

    <?php if(session('status')): ?>
        <p class="status-message">Zmiana w rejestrze umów została zapisana.</p>
    <?php endif; ?>

    <aside class="retailer-demo-record" aria-labelledby="retailer-demo-heading">
        <p class="eyebrow">Przykład demonstracyjny · fikcyjne dane</p>
        <h2 id="retailer-demo-heading">Jak czytać rekord firmy i umowy</h2>
        <p><strong>Example Retail Ltd</strong> · konto partnera · właściciel wewnętrzny: Example account owner</p>
        <p><code>DEMO-0001</code> · Wholesale cooperation record · okres 01.01.2026–31.12.2026 · status: przykładowy</p>
        <p>To wyłącznie wzór pól, nie prawdziwy kontrahent ani zawarta umowa. Pola firmy nawiązują do standardowego rekordu CRM, a pola umowy do popularnych metadanych rejestrów CLM.</p>
        <ul>
            <li><a href="https://developer.salesforce.com/docs/atlas.en-us.object_reference.meta/object_reference/sforce_api_objects_account.htm" target="_blank" rel="noopener noreferrer">Salesforce: standardowe pola rekordu Account</a></li>
            <li><a href="https://www.spotdraft.com/blog/contract-metadata-reporting" target="_blank" rel="noopener noreferrer">SpotDraft: raportowanie metadanych umów</a></li>
        </ul>
    </aside>

    <section class="retailer-contract-form-section" aria-labelledby="new-contract-heading">
        <h2 id="new-contract-heading">Dodaj rekord metadanych</h2>
        <?php if($retailers->isEmpty()): ?>
            <p class="notice-panel">Najpierw zatwierdź aktywną firmę, aby przypisać do niej rekord umowy.</p>
        <?php else: ?>
            <form class="review-form retailer-contract-form" method="POST" action="<?php echo e(route('admin.retailers.contracts.store')); ?>">
                <?php echo csrf_field(); ?>
                <label for="new-retailer">Firma</label>
                <select id="new-retailer" name="retailer_profile_id" required>
                    <?php $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($profile->id); ?>" <?php if(old('retailer_profile_id') == $profile->id): echo 'selected'; endif; ?>><?php echo e($profile->legal_business_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="new-reference">Numer / identyfikator</label>
                <input id="new-reference" name="reference" value="<?php echo e(old('reference')); ?>" maxlength="64" required>
                <label for="new-title">Tytuł rekordu</label>
                <input id="new-title" name="title" value="<?php echo e(old('title')); ?>" maxlength="190" required>
                <label for="new-type">Typ</label>
                <input id="new-type" name="contract_type" value="<?php echo e(old('contract_type')); ?>" maxlength="100" required>
                <label for="new-owner">Opiekun wewnętrzny</label>
                <select id="new-owner" name="internal_owner_id">
                    <option value="">Nieprzypisany</option>
                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($owner->id); ?>" <?php if(old('internal_owner_id') == $owner->id): echo 'selected'; endif; ?>><?php echo e($owner->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label for="new-start">Data rozpoczęcia</label>
                <input id="new-start" type="date" name="effective_date" value="<?php echo e(old('effective_date')); ?>">
                <label for="new-end">Data zakończenia</label>
                <input id="new-end" type="date" name="expiry_date" value="<?php echo e(old('expiry_date')); ?>">
                <label for="new-notice">Okres wypowiedzenia (dni)</label>
                <input id="new-notice" type="number" name="notice_period_days" min="0" max="3650" value="<?php echo e(old('notice_period_days')); ?>">
                <label for="new-status">Status</label>
                <select id="new-status" name="status" required>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php if(old('status', 'draft') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__currentLoopData = ['retailer_profile_id', 'reference', 'title', 'contract_type', 'internal_owner_id', 'effective_date', 'expiry_date', 'notice_period_days', 'status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="button button-dark" type="submit">Dodaj do rejestru</button>
            </form>
        <?php endif; ?>
    </section>

    <section class="retailer-data-section" aria-labelledby="contract-records-heading">
        <div class="retailer-section-heading"><div><p class="eyebrow"><span class="eyebrow-line"></span> Dane zapisane</p><h2 id="contract-records-heading">Rejestr metadanych</h2></div></div>
        <div class="retailer-table-wrap">
            <table class="retailer-table">
                <caption class="sr-only">Edytowalne rekordy metadanych umów</caption>
                <thead><tr><th scope="col">Firma</th><th scope="col">Numer / tytuł</th><th scope="col">Typ / opiekun</th><th scope="col">Okres / status</th><th scope="col">Zarządzanie</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($contract->retailerProfile->legal_business_name); ?><small><?php echo e($contract->retailerProfile->tax_identifier ?: 'Identyfikator niepodany'); ?></small></th>
                            <td><code><?php echo e($contract->reference); ?></code><small><?php echo e($contract->title); ?></small></td>
                            <td><?php echo e($contract->contract_type); ?><small><?php echo e($contract->internalOwner?->name ?: 'Nieprzypisany'); ?></small></td>
                            <td><?php echo e($contract->effective_date?->format('d.m.Y') ?: '—'); ?> – <?php echo e($contract->expiry_date?->format('d.m.Y') ?: '—'); ?><small><?php echo e(ucfirst($contract->status)); ?> · wypowiedzenie: <?php echo e($contract->notice_period_days ?? '—'); ?> dni</small></td>
                            <td>
                                <details>
                                    <summary>Edytuj</summary>
                                    <form class="review-form retailer-contract-form" method="POST" action="<?php echo e(route('admin.retailers.contracts.update', $contract)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <label for="retailer-<?php echo e($contract->id); ?>">Firma</label>
                                        <select id="retailer-<?php echo e($contract->id); ?>" name="retailer_profile_id" required>
                                            <?php $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($profile->id); ?>" <?php if($profile->id === $contract->retailer_profile_id): echo 'selected'; endif; ?>><?php echo e($profile->legal_business_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="reference-<?php echo e($contract->id); ?>">Numer</label>
                                        <input id="reference-<?php echo e($contract->id); ?>" name="reference" value="<?php echo e($contract->reference); ?>" maxlength="64" required>
                                        <label for="title-<?php echo e($contract->id); ?>">Tytuł</label>
                                        <input id="title-<?php echo e($contract->id); ?>" name="title" value="<?php echo e($contract->title); ?>" maxlength="190" required>
                                        <label for="type-<?php echo e($contract->id); ?>">Typ</label>
                                        <input id="type-<?php echo e($contract->id); ?>" name="contract_type" value="<?php echo e($contract->contract_type); ?>" maxlength="100" required>
                                        <label for="owner-<?php echo e($contract->id); ?>">Opiekun wewnętrzny</label>
                                        <select id="owner-<?php echo e($contract->id); ?>" name="internal_owner_id">
                                            <option value="">Nieprzypisany</option>
                                            <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($owner->id); ?>" <?php if($owner->id === $contract->internal_owner_id): echo 'selected'; endif; ?>><?php echo e($owner->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <label for="start-<?php echo e($contract->id); ?>">Data rozpoczęcia</label>
                                        <input id="start-<?php echo e($contract->id); ?>" type="date" name="effective_date" value="<?php echo e($contract->effective_date?->format('Y-m-d')); ?>">
                                        <label for="end-<?php echo e($contract->id); ?>">Data zakończenia</label>
                                        <input id="end-<?php echo e($contract->id); ?>" type="date" name="expiry_date" value="<?php echo e($contract->expiry_date?->format('Y-m-d')); ?>">
                                        <label for="notice-<?php echo e($contract->id); ?>">Okres wypowiedzenia (dni)</label>
                                        <input id="notice-<?php echo e($contract->id); ?>" type="number" name="notice_period_days" min="0" max="3650" value="<?php echo e($contract->notice_period_days); ?>">
                                        <label for="status-<?php echo e($contract->id); ?>">Status</label>
                                        <select id="status-<?php echo e($contract->id); ?>" name="status" required>
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($status); ?>" <?php if($contract->status === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <button class="button button-dark button-small" type="submit">Zapisz zmiany</button>
                                    </form>
                                </details>
                                <form method="POST" action="<?php echo e(route('admin.retailers.contracts.destroy', $contract)); ?>" onsubmit="return confirm('Usunąć ten rekord metadanych? Nie usuwa to podpisanego dokumentu.');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="text-link" type="submit">Usuń rekord</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5">Brak zapisanych rekordów. Przykład powyżej jest fikcyjny i nie został dodany do bazy.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($contracts->links()); ?>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/retailers/contracts.blade.php ENDPATH**/ ?>