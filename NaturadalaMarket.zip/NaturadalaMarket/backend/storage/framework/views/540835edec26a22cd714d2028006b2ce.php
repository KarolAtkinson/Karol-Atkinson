

<?php $__env->startSection('title', 'Lista ulubionych'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Twoje<br><em>ulubione.</em></h1>
    <p class="auth-description">Zapisane produkty z katalogu Naturadała.</p>
    <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error" role="alert"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if($products->isEmpty()): ?>
        <div class="notice-panel">
            <strong>Lista jest pusta.</strong>
            <p>Przeglądaj produkty i dodawaj te, do których chcesz wrócić.</p>
            <a class="button button-dark" href="<?php echo e(route('products.index')); ?>">Przejdź do produktów <span aria-hidden="true">↗</span></a>
        </div>
    <?php else: ?>
        <div class="saved-product-list">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="saved-product">
                    <a class="saved-product-image" href="<?php echo e(route('products.show', $product)); ?>">
                        <?php if($product->image_url): ?><img src="<?php echo e($product->image_url); ?>" alt="" loading="lazy"><?php endif; ?>
                    </a>
                    <div>
                        <h2>
                            <?php if($product->active): ?>
                                <a href="<?php echo e(route('products.show', $product)); ?>"><?php echo e($product->name); ?></a>
                            <?php else: ?>
                                <?php echo e($product->name); ?>

                            <?php endif; ?>
                        </h2>
                        <p><?php echo e($product->short_description); ?></p>
                        <?php if($product->active): ?>
                            <a class="text-link" href="<?php echo e(route('products.show', $product)); ?>">Szczegóły produktu <span aria-hidden="true">↗</span></a>
                        <?php else: ?>
                            <p class="basket-item-unavailable">Produkt nie jest obecnie dostępny w katalogu. Możesz usunąć go z listy.</p>
                        <?php endif; ?>
                        <?php if($product->active && ($product->stock_quantity === null || $product->stock_quantity >= $product->minimum_order_quantity)): ?>
                            <form class="wishlist-basket-form" method="POST" action="<?php echo e(route('basket.store', $product)); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="quantity" value="<?php echo e($product->minimum_order_quantity); ?>">
                                <button class="button button-dark button-small" type="submit">Dodaj do koszyka <span aria-hidden="true">+</span></button>
                            </form>
                        <?php elseif($product->active): ?>
                            <p class="field-hint">Chwilowo brak dostępnej ilości minimalnej.</p>
                        <?php endif; ?>
                    </div>
                    <form method="POST" action="<?php echo e(route('wishlist.destroy', $product)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="remove-button" type="submit" aria-label="Usuń <?php echo e($product->name); ?> z ulubionych">Usuń</button>
                    </form>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/wishlist.blade.php ENDPATH**/ ?>