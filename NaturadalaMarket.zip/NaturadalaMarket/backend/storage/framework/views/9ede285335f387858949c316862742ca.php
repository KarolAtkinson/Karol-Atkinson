<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <title><?php echo $__env->yieldContent('title'); ?> | Naturadała Partner</title>
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <script src="<?php echo e(asset('image-fallback.js')); ?>"></script>
    <script src="<?php echo e(asset('en-translations.js')); ?>" defer></script>
    <script src="<?php echo e(asset('cookie-consent.js')); ?>" defer></script>
    <script src="<?php echo e(asset('app.js')); ?>" defer></script>
</head>
<body class="retailer-workspace-page">
    <a class="skip-link" href="#main">Przejdź do treści</a>
    <header class="retailer-header">
        <div class="brand-language-group">
            <a class="brand" href="<?php echo e(route('retailer.workspace')); ?>" aria-label="Naturadała — przestrzeń partnera">
                <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
            </a>
            <?php echo $__env->make('shared.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <nav class="retailer-navigation" aria-label="Nawigacja partnera">
            <a href="<?php echo e(route('retailer.workspace')); ?>" aria-current="page">Katalog hurtowy</a>
            <a href="<?php echo e(route('basket.show')); ?>">Zapytania / koszyk</a>
            <a href="<?php echo e(route('account.show')); ?>">Moje konto</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="text-link" type="submit">Wyloguj się</button>
            </form>
        </nav>
    </header>
    <main class="retailer-main" id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="retailer-footer">
        <span>© <?php echo e(now()->year); ?> Naturadała</span>
        <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button>
        <span>Przestrzeń dla zatwierdzonych partnerów handlowych</span>
    </footer>
    <?php echo $__env->make('shared.cookie-consent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/retailer/layout.blade.php ENDPATH**/ ?>