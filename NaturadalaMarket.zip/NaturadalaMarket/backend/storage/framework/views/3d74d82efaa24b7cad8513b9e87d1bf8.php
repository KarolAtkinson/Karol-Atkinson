<div class="cookie-consent" data-cookie-consent hidden>
    <div class="cookie-card" role="dialog" aria-modal="false" aria-labelledby="cookie-title" aria-describedby="cookie-intro" tabindex="-1">
        <p class="eyebrow"><span class="eyebrow-line"></span> Prywatność</p>
        <h2 id="cookie-title">Pliki <em>cookies.</em></h2>
        <p id="cookie-intro" class="cookie-intro">Używamy plików cookies i pamięci przeglądarki, aby strona działała poprawnie. Za Twoją zgodą zapamiętamy też listę zapytania. Możesz zaakceptować wszystko, odrzucić opcjonalne albo wybrać tylko niektóre kategorie. Wybór zmienisz w każdej chwili przyciskiem „Ustawienia cookies” w stopce.</p>

        <form class="cookie-options" data-cookie-options hidden>
            <label class="cookie-option">
                <input type="checkbox" checked disabled>
                <span><strong>Niezbędne</strong><small>Sesja, logowanie, zabezpieczenia formularzy i wybrany język. Strona nie działa bez nich, dlatego są zawsze włączone.</small></span>
            </label>
            <label class="cookie-option">
                <input type="checkbox" name="preferences">
                <span><strong>Preferencje</strong><small>Zapamiętanie listy zapytania w Twojej przeglądarce między wizytami.</small></span>
            </label>
            <label class="cookie-option">
                <input type="checkbox" name="analytics">
                <span><strong>Analityka</strong><small>Statystyki odwiedzin. Obecnie nie używamy żadnych narzędzi analitycznych; ten wybór będzie obowiązywał, jeśli je dodamy.</small></span>
            </label>
            <label class="cookie-option">
                <input type="checkbox" name="marketing">
                <span><strong>Marketing</strong><small>Personalizacja i reklamy. Obecnie nie używamy żadnych narzędzi marketingowych; ten wybór będzie obowiązywał, jeśli je dodamy.</small></span>
            </label>
            <button class="button button-dark" type="submit" data-cookie-save>Zapisz wybór</button>
        </form>

        <div class="cookie-actions" data-cookie-actions>
            <button class="button button-dark" type="button" data-cookie-accept>Akceptuję wszystkie</button>
            <button class="button button-dark" type="button" data-cookie-reject>Odrzucam opcjonalne</button>
            <button class="button button-light" type="button" data-cookie-customize aria-expanded="false">Wybieram kategorie</button>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/shared/cookie-consent.blade.php ENDPATH**/ ?>