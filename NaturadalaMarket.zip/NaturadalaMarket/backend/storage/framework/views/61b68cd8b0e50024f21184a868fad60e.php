

<?php $__env->startSection('title', 'Produkty Naturadała'); ?>
<?php $__env->startSection('description', 'Poznaj ofertę Naturadała dla klientów i partnerów biznesowych. Ceny hurtowe widoczne po zatwierdzeniu konta firmy.'); ?>

<?php $__env->startSection('content'); ?>
    <section class="catalogue-hero">
        <p class="eyebrow"><span class="eyebrow-line"></span> Oferta Naturadała</p>
        <div class="catalogue-intro">
            <h1>Prosty skład.<br><em>Dobry wybór.</em></h1>
            <p>Odkryj koncentrat kolagenowy Naturadała. Partnerzy biznesowi mogą złożyć wniosek o dostęp do warunków hurtowych.</p>
        </div>
    </section>

    <section class="catalogue-section" aria-labelledby="catalogue-title">
        <div class="catalogue-heading">
            <div>
                <p class="eyebrow"><span class="eyebrow-line"></span> Starannie opracowany produkt</p>
                <h2 id="catalogue-title">Nasza oferta</h2>
            </div>
            <?php if($approvedRetailer): ?>
                <span class="audience-badge">Konto partnera zatwierdzone</span>
            <?php elseif(auth()->check() && auth()->user()->retailerProfile?->verification_status === 'pending'): ?>
                <span class="audience-badge">Wniosek firmy w weryfikacji</span>
            <?php endif; ?>
        </div>

        <form class="catalogue-toolbar" method="GET" action="<?php echo e(route('products.index')); ?>">
            <label class="search-field">
                <span class="sr-only">Szukaj produktu</span>
                <input type="search" name="q" value="<?php echo e($search); ?>" maxlength="120" placeholder="Szukaj produktu, opisu lub składnika" aria-label="Szukaj produktu">
            </label>
            <label class="sort-field">
                <span>Sortowanie</span>
                <select name="sort">
                    <option value="default" <?php echo e($sort === 'default' ? 'selected' : ''); ?>>Najczęściej wybierane</option>
                    <option value="name" <?php echo e($sort === 'name' ? 'selected' : ''); ?>>Nazwa A–Z</option>
                    <option value="newest" <?php echo e($sort === 'newest' ? 'selected' : ''); ?>>Najnowsze</option>
                </select>
            </label>
            <button class="button button-outline button-small" type="submit">Filtruj</button>
            <?php if($search !== '' || $sort !== 'default'): ?>
                <a class="text-link catalogue-clear" href="<?php echo e(route('products.index')); ?>">Wyczyść filtry</a>
            <?php endif; ?>
        </form>
        <?php $__errorArgs = ['q'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error" role="alert"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['sort'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error" role="alert"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php if($products->isEmpty()): ?>
            <div class="empty-state">
                <p>Brak produktów pasujących do filtrów. Spróbuj zmienić frazę lub wyczyścić wyszukiwanie.</p>
                <?php if($search !== '' || $sort !== 'default'): ?>
                    <a class="button button-outline button-small" href="<?php echo e(route('products.index')); ?>">Pokaż wszystkie produkty</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="catalogue-results" role="status">
                Wyświetlono <?php echo e($products->firstItem()); ?>–<?php echo e($products->lastItem()); ?> z <?php echo e($products->total()); ?> produktów
                <?php if($search !== ''): ?>
                    dla frazy „<?php echo e($search); ?>”
                <?php endif; ?>
            </p>
            <div class="catalogue-grid">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('products.card', [
                        'product' => $product,
                        'approvedRetailer' => $approvedRetailer,
                        'wishlisted' => in_array($product->id, $wishlistedIds, true),
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($products->links()); ?>

        <?php endif; ?>
    </section>

    <?php if (! ($approvedRetailer || (config('features.retailer_maintenance') && ! auth()->user()?->hasRole('admin')))): ?>
        <section class="catalogue-callout">
            <div>
                <p class="eyebrow">Dla sklepów i profesjonalistów</p>
                <h2>Chcesz poznać<br><em>warunki hurtowe?</em></h2>
            </div>
            <div class="catalogue-callout-copy">
                <p>Ceny partnerskie udostępniamy wyłącznie zweryfikowanym firmom. Zaloguj się i zgłoś swoją firmę do weryfikacji.</p>
                <a class="button button-light" href="<?php echo e(auth()->check() && auth()->user()->hasVerifiedEmail() ? route('retailer.application') : route('register')); ?>">Informacje o współpracy <span aria-hidden="true">↗</span></a>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/products/index.blade.php ENDPATH**/ ?>