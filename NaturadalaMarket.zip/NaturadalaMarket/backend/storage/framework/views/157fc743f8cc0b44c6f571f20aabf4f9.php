

<?php $__env->startSection('title', $state === 'confirmed' ? 'Subskrypcja potwierdzona' : 'Wypisano z newslettera'); ?>

<?php $__env->startSection('content'); ?>
    <p class="eyebrow"><span class="eyebrow-line"></span> Newsletter</p>
    <?php if($state === 'confirmed'): ?>
        <h1 class="auth-title">Dziękujemy,<br><em>zapisano.</em></h1>
        <p class="auth-description">Subskrypcja jest potwierdzona. Będziemy informować Cię o nowych produktach. Zniżka <?php echo e(config('features.subscriber_discount_percent')); ?>% na wszystkie produkty działa po zalogowaniu na konto z tym adresem e-mail.</p>
    <?php else: ?>
        <h1 class="auth-title">Wypisano<br><em>z newslettera.</em></h1>
        <p class="auth-description">Nie będziemy już wysyłać Ci wiadomości o nowych produktach, a zniżka dla subskrybentów przestaje obowiązywać.</p>
    <?php endif; ?>
    <a class="button button-dark" href="<?php echo e(route('products.index')); ?>">Przejdź do produktów <span aria-hidden="true">↗</span></a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/subscription/result.blade.php ENDPATH**/ ?>