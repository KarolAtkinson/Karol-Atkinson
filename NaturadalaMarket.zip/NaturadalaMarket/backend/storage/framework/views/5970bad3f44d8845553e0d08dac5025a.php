<?php
    $accountItems = auth()->check() && auth()->user()->hasVerifiedEmail()
        ? (auth()->user()->basket()->with('items.product')->first()?->items ?? collect())
        : collect();
    $accountCount = $accountItems->sum('quantity');
?>
<div class="cart-backdrop" hidden></div>
<aside class="cart-panel" id="basket-popup" role="dialog" aria-modal="true" aria-labelledby="cart-title" aria-hidden="true" data-account-count="<?php echo e($accountCount); ?>">
    <div class="cart-header">
        <div>
            <p class="eyebrow">Twój koszyk</p>
            <h2 id="cart-title">Koszyk <span class="cart-count"><?php echo e($accountCount); ?></span></h2>
        </div>
        <button class="cart-close" type="button" aria-label="Zamknij koszyk">×</button>
    </div>
    <p class="cart-intro">Wybrane produkty. Cenę i dostępność potwierdzi nasz zespół — to nie jest zamówienie.</p>

    <?php if($accountItems->isNotEmpty()): ?>
        <div class="cart-account">
            <p class="cart-section-title">Na Twoim koncie</p>
            <?php $__currentLoopData = $accountItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart-line">
                    <strong><?php echo e($item->product->name); ?></strong>
                    <div class="cart-line-actions"><span><?php echo e($item->quantity); ?> szt.</span></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a class="text-link cart-manage" href="<?php echo e(route('basket.show')); ?>">Zarządzaj koszykiem <span aria-hidden="true">↗</span></a>
        </div>
    <?php endif; ?>

    <div class="cart-items" aria-live="polite"></div>
    <p class="cart-empty">Twój koszyk jest jeszcze pusty.<br>Dodaj produkt, aby zapytać o współpracę.</p>
    <a class="button button-dark cart-inquiry" href="<?php echo e(route('contact')); ?>">Wyślij zapytanie <span aria-hidden="true">↗</span></a>
    <p class="cart-disclaimer">To zapytanie nie jest zamówieniem. Cenę i dostępność potwierdzi nasz zespół.</p>
</aside>
<p class="sr-only" role="status" aria-live="polite" id="announcement-status"></p>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/shared/basket-panel.blade.php ENDPATH**/ ?>