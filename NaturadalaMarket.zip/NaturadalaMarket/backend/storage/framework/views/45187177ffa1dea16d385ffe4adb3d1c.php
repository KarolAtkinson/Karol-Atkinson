<h1>Nowe zapytanie hurtowe #<?php echo e($inquiry->getKey()); ?></h1>

<p><strong>Kontakt:</strong> <?php echo e($inquiry->name); ?> &lt;<?php echo e($inquiry->email); ?>&gt;</p>
<?php if($inquiry->company_name): ?>
    <p><strong>Firma:</strong> <?php echo e($inquiry->company_name); ?></p>
<?php endif; ?>
<?php if($inquiry->phone): ?>
    <p><strong>Telefon:</strong> <?php echo e($inquiry->phone); ?></p>
<?php endif; ?>

<?php if($inquiry->products): ?>
    <h2>Produkty</h2>
    <ul>
        <?php $__currentLoopData = $inquiry->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($product['name'] ?? 'Produkt'); ?> — <?php echo e($product['quantity'] ?? 0); ?> szt.</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<?php if($inquiry->message): ?>
    <h2>Wiadomość</h2>
    <p><?php echo nl2br(e($inquiry->message)); ?></p>
<?php endif; ?>

<p><a href="<?php echo e(route('admin.inquiries.index')); ?>">Otwórz skrzynkę zapytań</a></p>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/emails/inquiries/new.blade.php ENDPATH**/ ?>