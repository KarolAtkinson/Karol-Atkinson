

<?php $__env->startSection('title', 'Resetowanie hasła'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Odzyskaj<br><em>dostęp.</em></h1>
    <p class="auth-description">Podaj adres e-mail powiązany z kontem. Jeśli konto istnieje i może korzystać z usługi, otrzymasz link do ustawienia nowego hasła.</p>
    <?php if(session('status') === 'password-link-requested'): ?>
        <p class="status-message">Jeśli konto istnieje, wysłaliśmy wiadomość z dalszymi instrukcjami.</p>
    <?php endif; ?>
    <form class="auth-form" method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">Adres e-mail</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button class="button button-dark auth-submit" type="submit">Wyślij link resetujący <span aria-hidden="true">↗</span></button>
    </form>
    <p class="auth-switch"><a href="<?php echo e(route('login')); ?>">Wróć do logowania</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>