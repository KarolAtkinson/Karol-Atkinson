

<?php $__env->startSection('title', 'Przerwa techniczna'); ?>

<?php $__env->startSection('content'); ?>
    <p class="eyebrow"><span class="eyebrow-line"></span> Strefa partnera</p>
    <h1 class="auth-title">Przerwa<br><em>techniczna.</em></h1>
    <div class="notice-panel" role="status">
        <strong>Strefa dla partnerów handlowych jest chwilowo niedostępna.</strong>
        <p>Pracujemy nad jej rozwojem i wrócimy z nią wkrótce. Ceny hurtowe oraz wnioski firm są na ten czas wstrzymane.</p>
        <p>Pytania dotyczące współpracy: <a class="text-link" href="mailto:kontakt@naturadala.pl">kontakt@naturadala.pl</a></p>
        <a class="button button-dark" href="<?php echo e(route('products.index')); ?>">Przejdź do produktów <span aria-hidden="true">↗</span></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/retailer/maintenance.blade.php ENDPATH**/ ?>