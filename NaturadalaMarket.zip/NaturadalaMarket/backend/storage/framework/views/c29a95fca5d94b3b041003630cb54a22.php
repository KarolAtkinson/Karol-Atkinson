

<?php $__env->startSection('title', 'Zapytania hurtowe'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja</p>
            <h1 class="auth-title">Zapytania<br><em>hurtowe.</em></h1>
        </div>
    </div>

    <?php if(session('status') === 'inquiry-updated'): ?>
        <p class="status-message">Status zapytania został zaktualizowany.</p>
    <?php endif; ?>

    <form class="inquiry-filters" method="GET" action="<?php echo e(route('admin.inquiries.index')); ?>">
        <label>
            <span class="sr-only">Szukaj zapytań</span>
            <input type="search" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" maxlength="120" placeholder="Szukaj osoby, firmy lub e-maila">
        </label>
        <label>
            <span class="sr-only">Filtruj według statusu</span>
            <select name="status">
                <option value="">Wszystkie statusy</option>
                <option value="new" <?php if(($filters['status'] ?? '') === 'new'): echo 'selected'; endif; ?>>Nowe</option>
                <option value="contacted" <?php if(($filters['status'] ?? '') === 'contacted'): echo 'selected'; endif; ?>>Kontaktowane</option>
                <option value="closed" <?php if(($filters['status'] ?? '') === 'closed'): echo 'selected'; endif; ?>>Zamknięte</option>
            </select>
        </label>
        <button class="button button-outline button-small" type="submit">Filtruj</button>
        <?php if(($filters['q'] ?? '') !== '' || ($filters['status'] ?? '') !== ''): ?>
            <a class="text-link" href="<?php echo e(route('admin.inquiries.index')); ?>">Wyczyść</a>
        <?php endif; ?>
    </form>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Kontakt</th>
                    <th>Firma</th>
                    <th>Produkty</th>
                    <th>Wiadomość</th>
                    <th>Status</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $products = $inquiry->products;
                        if (is_string($products)) {
                            $products = json_decode($products, true) ?: [];
                        }
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo e($inquiry->name); ?></strong><br>
                            <a href="mailto:<?php echo e($inquiry->email); ?>"><?php echo e($inquiry->email); ?></a>
                            <?php if($inquiry->phone): ?>
                                <br><a href="tel:<?php echo e($inquiry->phone); ?>"><?php echo e($inquiry->phone); ?></a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($inquiry->company_name ?: '—'); ?></td>
                        <td>
                            <?php if(! empty($products)): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><?php echo e($product['name'] ?? 'Produkt'); ?> · <?php echo e($product['quantity'] ?? 0); ?> szt.</div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <span>—</span>
                            <?php endif; ?>
                        </td>
                        <td class="inquiry-message">
                            <?php if($inquiry->message): ?>
                                <?php echo e($inquiry->message); ?>

                            <?php else: ?>
                                <span>Brak dodatkowej wiadomości</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.inquiries.update', $inquiry)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="filter_status" value="<?php echo e($filters['status'] ?? ''); ?>">
                                <input type="hidden" name="filter_q" value="<?php echo e($filters['q'] ?? ''); ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="new" <?php if($inquiry->status === 'new'): echo 'selected'; endif; ?>>Nowe</option>
                                    <option value="contacted" <?php if($inquiry->status === 'contacted'): echo 'selected'; endif; ?>>Kontaktowane</option>
                                    <option value="closed" <?php if($inquiry->status === 'closed'): echo 'selected'; endif; ?>>Zamknięte</option>
                                </select>
                            </form>
                        </td>
                        <td><?php echo e($inquiry->created_at->format('d.m.Y H:i')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Brak zapytań hurtowych.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($inquiries->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/inquiries/index.blade.php ENDPATH**/ ?>