

<?php $__env->startSection('title', 'Kontakt'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Zapytaj<br><em>o ofertę.</em></h1>
    <p class="auth-description">Wypełnij formularz, a nasz zespół odpowie w sprawie współpracy hurtowej, logistyki i cen.</p>

    <?php if(session('status') === 'inquiry-sent'): ?>
        <p class="status-message" data-inquiry-sent>Zapytanie zostało wysłane. Odpowiemy na adres podany w formularzu.</p>
    <?php endif; ?>

    <form class="auth-form" id="inquiry-form" method="POST" action="<?php echo e(route('contact.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="inquiry-products" name="products" value="<?php echo e(old('products', json_encode($initialProducts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))); ?>">

        <label for="name">Imię i nazwisko</label>
        <input id="name" name="name" type="text" value="<?php echo e(old('name', $contactDefaults['name'])); ?>" required maxlength="190">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="email">Adres e-mail</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email', $contactDefaults['email'])); ?>" required maxlength="190">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="company_name">Nazwa firmy <span class="field-optional">(opcjonalnie)</span></label>
        <input id="company_name" name="company_name" type="text" value="<?php echo e(old('company_name', $contactDefaults['company_name'])); ?>" maxlength="190">

        <label for="phone">Telefon <span class="field-optional">(opcjonalnie)</span></label>
        <input id="phone" name="phone" type="tel" value="<?php echo e(old('phone', $contactDefaults['phone'])); ?>" maxlength="32">

        <div class="inquiry-product-summary" id="inquiry-product-summary" aria-live="polite">
            <strong>Produkty z Twojej listy</strong>
            <p>Możesz wysłać także ogólne zapytanie bez wybranych produktów.</p>
        </div>

        <label for="product_details">Produkty lub szczegóły zapytania <span class="field-optional">(opcjonalnie)</span></label>
        <textarea id="product_details" name="product_details" rows="3" maxlength="2000" placeholder="Opisz dodatkowe produkty lub ilości, o które chcesz zapytać."><?php echo e(old('product_details')); ?></textarea>
        <?php $__errorArgs = ['products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['product_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="message">Dodatkowe informacje</label>
        <textarea id="message" name="message" rows="5" maxlength="2000" placeholder="Opisz wymagania, planowane zamówienie lub zakres współpracy."><?php echo e(old('message')); ?></textarea>
        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="button button-dark auth-submit" type="submit">Wyślij zapytanie <span aria-hidden="true">↗</span></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/contact.blade.php ENDPATH**/ ?>