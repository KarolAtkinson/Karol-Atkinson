

<?php $__env->startSection('title', 'Moje konto'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Witaj,<br><em><?php echo e($user->name); ?>.</em></h1>
    <?php if(session('status') === 'email-verified'): ?>
        <p class="status-message">Adres e-mail został potwierdzony.</p>
    <?php elseif(session('status') === 'profile-updated'): ?>
        <p class="status-message">Dane konta zostały zaktualizowane.</p>
    <?php elseif(session('status') === 'password-updated'): ?>
        <p class="status-message">Hasło zostało zmienione. Tokeny „zapamiętaj mnie” zostały unieważnione.</p>
    <?php endif; ?>
    <p class="auth-description">Zarządzaj dostępem do katalogu i ustawieniami konta. Zamówienia online zostaną dodane w kolejnym etapie.</p>
    <?php if(session('status') === 'retailer-application-submitted'): ?>
        <p class="status-message">Wniosek firmy zapisano. Zespół Naturadała zweryfikuje dane przed przyznaniem dostępu hurtowego.</p>
    <?php endif; ?>
    <div class="account-summary">
        <div>
            <span>Adres e-mail</span>
            <strong><?php echo e($user->email); ?></strong>
        </div>
        <div>
            <span>Status konta</span>
            <strong>Aktywne</strong>
        </div>
        <div>
            <span>Dodatkowa ochrona</span>
            <strong><?php echo e($user->two_factor_confirmed_at ? 'Włączona' : 'Wyłączona'); ?></strong>
        </div>
        <?php if($user->retailerProfile): ?>
            <div>
                <span>Weryfikacja firmy</span>
                <strong>
                    <?php if($user->retailerProfile->verification_status === 'approved'): ?>
                        Zatwierdzona
                    <?php elseif($user->retailerProfile->verification_status === 'rejected'): ?>
                        Wymaga uzupełnienia
                    <?php else: ?>
                        Oczekuje na weryfikację
                    <?php endif; ?>
                </strong>
            </div>
        <?php endif; ?>
    </div>
    <?php if($user->retailerProfile?->verification_status === 'pending'): ?>
        <p class="notice-panel">Wniosek firmy nie daje jeszcze dostępu do cen hurtowych. Oczekuje na weryfikację.</p>
    <?php elseif($user->retailerProfile?->verification_status === 'rejected'): ?>
        <div class="notice-panel">
            <strong>Wniosek wymaga uzupełnienia.</strong>
            <?php if($user->retailerProfile->review_notes): ?>
                <p><?php echo e($user->retailerProfile->review_notes); ?></p>
            <?php endif; ?>
            <a class="text-link" href="<?php echo e(route('retailer.application')); ?>">Popraw i wyślij wniosek ponownie <span aria-hidden="true">↗</span></a>
        </div>
    <?php endif; ?>
    <div class="account-action-links">
        <a class="button button-outline" href="<?php echo e(route('account.profile.edit')); ?>">Dane konta <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('account.password.edit')); ?>">Zmień hasło <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('account.security-events.index')); ?>">Historia bezpieczeństwa <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('products.index')); ?>">Przeglądaj produkty <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('wishlist.index')); ?>">Moje ulubione <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('basket.show')); ?>">Mój koszyk <span aria-hidden="true">↗</span></a>
        <a class="button button-outline" href="<?php echo e(route('addresses.index')); ?>">Moje adresy <span aria-hidden="true">↗</span></a>
        <?php if(config('features.retailer_maintenance') && ! $user->hasRole('admin')): ?>
            <span class="button button-outline is-disabled" aria-disabled="true">Strefa partnera: przerwa techniczna</span>
        <?php elseif(! $user->retailerProfile || $user->retailerProfile->verification_status !== 'approved'): ?>
            <a class="button button-outline" href="<?php echo e(route('retailer.application')); ?>"><?php echo e($user->retailerProfile?->verification_status === 'pending' ? 'Zobacz wniosek firmy' : 'Zgłoś firmę do weryfikacji'); ?> <span aria-hidden="true">↗</span></a>
        <?php else: ?>
            <a class="button button-dark" href="<?php echo e(route('retailer.workspace')); ?>">Otwórz przestrzeń partnera <span aria-hidden="true">↗</span></a>
        <?php endif; ?>
        <?php if($user->hasRole('admin') && $user->two_factor_confirmed_at): ?>
            <a class="button button-dark" href="<?php echo e(route('admin.retailers.index')); ?>">Wnioski firm <span aria-hidden="true">↗</span></a>
            <a class="button button-outline" href="<?php echo e(route('admin.retailers.directory')); ?>">Baza partnerów <span aria-hidden="true">↗</span></a>
            <a class="button button-outline" href="<?php echo e(route('admin.retailers.contracts.index')); ?>">Rejestr umów <span aria-hidden="true">↗</span></a>
        <?php endif; ?>
    </div>
    <a class="button button-outline auth-submit" href="<?php echo e(route('mfa.show')); ?>">Ustawienia uwierzytelniania <span aria-hidden="true">↗</span></a>
    <form class="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="button button-dark auth-submit" type="submit">Wyloguj się</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/show.blade.php ENDPATH**/ ?>