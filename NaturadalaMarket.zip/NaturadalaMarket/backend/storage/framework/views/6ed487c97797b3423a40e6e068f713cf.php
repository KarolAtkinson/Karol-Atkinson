<?php
    $announcements = collect(config('announcements.messages', []))
        ->sortBy(fn ($message) => mb_strtolower(\Illuminate\Support\Str::ascii($message['text'])))
        ->values();
    $announcementInterval = max(5, (int) config('announcements.interval_seconds', 20)) * 1000;
?>
<?php if($announcements->isNotEmpty()): ?>
    <div class="announcement" data-announcement-slider data-interval="<?php echo e($announcementInterval); ?>" role="region" aria-roledescription="carousel" aria-label="Komunikaty">
        <div class="announcement-track">
            <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="announcement-slide<?php echo e($loop->first ? ' is-active' : ''); ?>" <?php if (! ($loop->first)): ?> inert <?php endif; ?>>
                    <p><?php echo e($message['text']); ?></p>
                    <?php if(! empty($message['url']) && ! empty($message['label'])): ?>
                        <a href="<?php echo e($message['url']); ?>"><?php echo e($message['label']); ?> <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($announcements->count() > 1): ?>
            <button class="announcement-toggle" type="button" data-announcement-toggle aria-label="Wstrzymaj komunikaty">
                <span aria-hidden="true">❚❚</span>
            </button>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/shared/announcement.blade.php ENDPATH**/ ?>