<form class="language-switch-form" method="POST" action="<?php echo e(route('language.update')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="locale" value="<?php echo e(app()->getLocale() === 'pl' ? 'en' : 'pl'); ?>">
    <button class="language-switch" type="submit" lang="<?php echo e(app()->getLocale() === 'pl' ? 'en' : 'pl'); ?>" aria-label="<?php echo e(app()->getLocale() === 'pl' ? 'Przełącz język na angielski' : 'Switch language to Polish'); ?>" title="<?php echo e(app()->getLocale() === 'pl' ? 'Przełącz język na angielski' : 'Switch language to Polish'); ?>">
        <span aria-hidden="true"><?php echo e(app()->getLocale() === 'pl' ? '🇬🇧' : '🇵🇱'); ?></span>
    </button>
</form>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/shared/language-switcher.blade.php ENDPATH**/ ?>