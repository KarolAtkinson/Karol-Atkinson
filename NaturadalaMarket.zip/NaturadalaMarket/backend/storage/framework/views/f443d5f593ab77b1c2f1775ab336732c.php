<article class="catalogue-card">
    <a class="catalogue-card-image" href="<?php echo e(route('products.show', $product)); ?>">
        <?php if($product->image_url): ?>
            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
        <?php else: ?>
            <span class="product-image-placeholder">Naturadała</span>
        <?php endif; ?>
        <span class="catalogue-card-link" aria-hidden="true">↗</span>
    </a>
    <div class="catalogue-card-copy">
        <p class="eyebrow"><?php echo e($product->sku); ?></p>
        <h3><a href="<?php echo e(route('products.show', $product)); ?>"><?php echo e($product->name); ?></a></h3>
        <p><?php echo e($product->short_description); ?></p>
        <?php if($product->stock_quantity !== null): ?>
            <p class="catalogue-availability <?php echo e($product->stock_quantity >= $product->minimum_order_quantity ? 'is-available' : 'is-unavailable'); ?>">
                <?php echo e($product->stock_quantity >= $product->minimum_order_quantity ? 'Dostępny' : 'Brak dostępnej ilości minimalnej'); ?>

            </p>
        <?php endif; ?>
        <div class="catalogue-price">
            <?php if($approvedRetailer && $product->wholesalePrices->isNotEmpty()): ?>
                <span>Cena partnerska od</span>
                <strong><?php echo e(number_format((float) $product->wholesalePrices->first()->unit_price, 2, ',', ' ')); ?> zł</strong>
                <small>netto · min. <?php echo e($product->wholesalePrices->first()->minimum_quantity); ?> szt.</small>
            <?php elseif(! $approvedRetailer && $product->retail_price !== null): ?>
                <?php if(auth()->user()?->isSubscriber()): ?>
                    <span>Cena dla subskrybenta (−<?php echo e(config('features.subscriber_discount_percent')); ?>%)</span>
                    <strong><?php echo e(number_format($product->subscriberPrice(), 2, ',', ' ')); ?> zł <s class="price-was"><?php echo e(number_format((float) $product->retail_price, 2, ',', ' ')); ?> zł</s></strong>
                <?php else: ?>
                    <span>Cena detaliczna</span>
                    <strong><?php echo e(number_format((float) $product->retail_price, 2, ',', ' ')); ?> zł</strong>
                    <small class="price-hint"><a href="#newsletter">Zapisz się do newslettera: −<?php echo e(config('features.subscriber_discount_percent')); ?>%</a></small>
                <?php endif; ?>
            <?php else: ?>
                <span>Warunki sprzedaży</span>
                <strong>Zapytaj o ofertę</strong>
            <?php endif; ?>
        </div>
        <div class="catalogue-card-actions">
            <a class="button button-dark" href="<?php echo e(route('products.show', $product)); ?>">Szczegóły produktu <span aria-hidden="true">↗</span></a>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->hasVerifiedEmail()): ?>
                    <form method="POST" action="<?php echo e($wishlisted ? route('wishlist.destroy', $product) : route('wishlist.store', $product)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php if($wishlisted): ?> <?php echo method_field('DELETE'); ?> <?php endif; ?>
                        <button class="icon-button" type="submit" aria-label="<?php echo e($wishlisted ? 'Usuń z ulubionych' : 'Dodaj do ulubionych'); ?>"><?php echo e($wishlisted ? '♥' : '♡'); ?></button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</article>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/products/card.blade.php ENDPATH**/ ?>