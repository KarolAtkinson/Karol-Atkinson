

<?php $__env->startSection('title', 'Weryfikacja firmy'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Współpracuj<br><em>z Naturadałą.</em></h1>
    <?php if($profile?->verification_status === 'approved'): ?>
        <p class="auth-description">Ta firma została już zweryfikowana. Konto ma dostęp do warunków partnerskich.</p>
    <?php elseif($profile?->verification_status === 'pending'): ?>
        <p class="auth-description">Otrzymaliśmy wniosek z <?php echo e($profile->legal_business_name); ?>. Weryfikacja jest w toku. Ceny hurtowe pojawią się po zatwierdzeniu firmy.</p>
        <div class="account-summary">
            <div><span>Nazwa firmy</span><strong><?php echo e($profile->legal_business_name); ?></strong></div>
            <div><span>Status</span><strong>Oczekuje na weryfikację</strong></div>
            <?php if($profile->submitted_at): ?>
                <div><span>Wysłano</span><strong><?php echo e($profile->submitted_at->format('d.m.Y')); ?></strong></div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <?php if($profile?->verification_status === 'rejected'): ?>
            <div class="notice-panel">
                <strong>Poprzedni wniosek wymagał uzupełnienia.</strong>
                <?php if($profile->review_notes): ?>
                    <p><?php echo e($profile->review_notes); ?></p>
                <?php endif; ?>
                <?php if($profile->reviewed_at): ?>
                    <p>Rozpatrzono: <?php echo e($profile->reviewed_at->format('d.m.Y')); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <p class="auth-description">Podaj dane firmy, aby złożyć wniosek o dostęp do warunków hurtowych. Wniosek przejdzie ręczną weryfikację i nie przyznaje cen partnerskich automatycznie.</p>
        <form class="auth-form" method="POST" action="<?php echo e(route('retailer.application.store')); ?>">
            <?php echo csrf_field(); ?>
            <label for="legal_business_name">Pełna nazwa firmy</label>
            <input id="legal_business_name" name="legal_business_name" type="text" value="<?php echo e(old('legal_business_name', $profile?->legal_business_name)); ?>" autocomplete="organization" maxlength="190" required>
            <?php $__errorArgs = ['legal_business_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="tax_identifier">NIP <span class="field-optional">(opcjonalnie)</span></label>
            <input id="tax_identifier" name="tax_identifier" type="text" value="<?php echo e(old('tax_identifier', $profile?->tax_identifier)); ?>" autocomplete="off" maxlength="32">
            <?php $__errorArgs = ['tax_identifier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="business_phone">Telefon firmowy <span class="field-optional">(opcjonalnie)</span></label>
            <input id="business_phone" name="business_phone" type="tel" value="<?php echo e(old('business_phone', $profile?->business_phone)); ?>" maxlength="32">

            <label for="website">Strona internetowa firmy <span class="field-optional">(opcjonalnie)</span></label>
            <input id="website" name="website" type="url" value="<?php echo e(old('website', $profile?->website)); ?>" autocomplete="url" maxlength="255">
            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button class="button button-dark auth-submit" type="submit"><?php echo e($profile ? 'Wyślij wniosek ponownie' : 'Wyślij do weryfikacji'); ?> <span aria-hidden="true">↗</span></button>
        </form>
    <?php endif; ?>
    <p class="auth-switch"><a href="<?php echo e(route('account.show')); ?>">Wróć do konta</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/retailer/application.blade.php ENDPATH**/ ?>