

<?php $__env->startSection('title', 'Weryfikacja firm'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Weryfikacja<br><em>partnerów.</em></h1>
    <p class="auth-description">Dostęp administracyjny jest chroniony rolą administratora i aktywnym uwierzytelnianiem dwuetapowym.</p>
    <?php if(session('status') === 'retailer-application-reviewed'): ?>
        <p class="status-message">Decyzja została zapisana w historii bezpieczeństwa konta.</p>
    <?php endif; ?>

    <form class="inquiry-filters retailer-filters" method="GET" action="<?php echo e(route('admin.retailers.index')); ?>">
        <label>
            <span class="sr-only">Szukaj wniosków</span>
            <input type="search" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" maxlength="120" placeholder="Szukaj firmy, NIP-u, osoby lub e-maila">
        </label>
        <button class="button button-outline button-small" type="submit">Szukaj</button>
        <?php if(($filters['q'] ?? '') !== ''): ?>
            <a class="text-link" href="<?php echo e(route('admin.retailers.index')); ?>">Wyczyść</a>
        <?php endif; ?>
    </form>

    <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="retailer-review-card">
            <p class="eyebrow">Wniosek · <?php echo e($profile->submitted_at?->format('d.m.Y H:i') ?? 'brak daty'); ?></p>
            <h2><?php echo e($profile->legal_business_name); ?></h2>
            <dl>
                <div><dt>Osoba kontaktowa</dt><dd><?php echo e($profile->user->name); ?></dd></div>
                <div><dt>E-mail</dt><dd><?php echo e($profile->user->email); ?></dd></div>
                <div><dt>Adres potwierdzony</dt><dd><?php echo e($profile->user->hasVerifiedEmail() ? 'Tak' : 'Nie'); ?></dd></div>
                <div><dt>NIP</dt><dd><?php echo e($profile->tax_identifier ?: 'Nie podano'); ?></dd></div>
                <div><dt>Telefon</dt><dd><?php echo e($profile->business_phone ?: $profile->user->phone ?: 'Nie podano'); ?></dd></div>
                <?php if($profile->website): ?><div><dt>Strona</dt><dd><a href="<?php echo e($profile->website); ?>" target="_blank" rel="noreferrer"><?php echo e($profile->website); ?></a></dd></div><?php endif; ?>
            </dl>
            <?php if($profile->user->status !== 'active' || ! $profile->user->hasVerifiedEmail()): ?>
                <p class="notice-panel">Nie można podjąć decyzji: konto jest nieaktywne lub e-mail nie został potwierdzony.</p>
            <?php else: ?>
                <form class="review-form" method="POST" action="<?php echo e(route('admin.retailers.update', $profile)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="filter_q" value="<?php echo e($filters['q'] ?? ''); ?>">
                    <label for="notes-<?php echo e($profile->id); ?>">Notatka wewnętrzna / powód decyzji</label>
                    <textarea id="notes-<?php echo e($profile->id); ?>" name="review_notes" rows="3" maxlength="2000"><?php echo e(old('review_notes')); ?></textarea>
                    <?php $__errorArgs = ['review_notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div class="review-actions">
                        <button class="button button-dark" name="decision" value="approve" type="submit">Zatwierdź firmę</button>
                        <button class="button button-outline" name="decision" value="reject" type="submit">Odrzuć wniosek</button>
                    </div>
                </form>
            <?php endif; ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notice-panel">
            <?php if(($filters['q'] ?? '') !== ''): ?>
                <strong>Nie znaleziono pasujących wniosków.</strong>
                <p>Sprawdź pisownię lub wyczyść wyszukiwanie.</p>
            <?php else: ?>
                <strong>Brak wniosków do rozpatrzenia.</strong>
                <p>Nowe wnioski zweryfikowanych adresem e-mail firm pojawią się tutaj.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php echo e($applications->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/retailers/index.blade.php ENDPATH**/ ?>