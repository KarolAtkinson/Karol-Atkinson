

<?php $__env->startSection('title', 'Panel administracyjny'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja</p>
            <h1 class="auth-title">Panel<br><em>administracyjny.</em></h1>
        </div>
    </div>

    <div class="admin-dashboard-grid">
        <article class="stat-card">
            <span class="stat-label">Produkty</span>
            <strong><?php echo e($productsCount); ?></strong>
            <small><?php echo e($activeProductsCount); ?> aktywnych</small>
        </article>
        <article class="stat-card">
            <span class="stat-label">Sprzedawcy</span>
            <strong><?php echo e($retailersCount); ?></strong>
            <small><?php echo e($approvedApplicationsCount); ?> zatwierdzonych</small>
        </article>
        <article class="stat-card stat-card-warning">
            <span class="stat-label">Wnioski</span>
            <strong><?php echo e($pendingApplicationsCount); ?></strong>
            <small>oczekujących na decyzję</small>
        </article>
        <article class="stat-card">
            <span class="stat-label">Zapytania</span>
            <strong><?php echo e($newInquiriesCount); ?></strong>
            <small>nowych zapytań hurtowych</small>
        </article>
    </div>

    <div class="admin-dashboard-actions">
        <a class="button button-dark" href="<?php echo e(route('admin.products.index')); ?>">Zarządzaj katalogiem</a>
        <a class="button button-outline" href="<?php echo e(route('admin.retailers.index')); ?>">Weryfikacja firm</a>
        <a class="button button-outline" href="<?php echo e(route('admin.retailers.directory')); ?>">Baza partnerów</a>
        <a class="button button-outline" href="<?php echo e(route('admin.retailers.contracts.index')); ?>">Rejestr umów</a>
        <a class="button button-outline" href="<?php echo e(route('admin.inquiries.index')); ?>">Zapytania hurtowe</a>
    </div>

    <?php if($recentInquiries->isNotEmpty()): ?>
        <section class="dashboard-inquiries" aria-labelledby="dashboard-inquiries-title">
            <div class="dashboard-section-heading">
                <div>
                    <p class="eyebrow"><span class="eyebrow-line"></span> Wymagają kontaktu</p>
                    <h2 id="dashboard-inquiries-title">Nowe zapytania</h2>
                </div>
                <a class="text-link" href="<?php echo e(route('admin.inquiries.index', ['status' => 'new'])); ?>">Otwórz skrzynkę <span aria-hidden="true">↗</span></a>
            </div>
            <div class="dashboard-inquiry-list">
                <?php $__currentLoopData = $recentInquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="dashboard-inquiry">
                        <div>
                            <strong><?php echo e($inquiry->name); ?></strong>
                            <span><?php echo e($inquiry->company_name ?: $inquiry->email); ?></span>
                        </div>
                        <span><?php echo e($inquiry->created_at->format('d.m.Y H:i')); ?></span>
                        <a href="mailto:<?php echo e($inquiry->email); ?>" aria-label="Napisz do <?php echo e($inquiry->name); ?>"><?php echo e($inquiry->email); ?></a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if($pendingApplicationsCount > 0 || $newInquiriesCount > 0): ?>
        <div class="notice-panel">
            <strong>Do rozpatrzenia są nowe zgłoszenia.</strong>
            <p>Sprawdź listę wniosków firmowych i zapytań hurtowych przed udostępnieniem cen lub dalszą obsługą klienta.</p>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>