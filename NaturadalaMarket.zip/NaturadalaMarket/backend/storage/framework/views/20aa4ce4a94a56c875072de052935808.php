

<?php $__env->startSection('title', $product->exists ? 'Edytowanie produktu' : 'Nowy produkt'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja</p>
            <h1 class="auth-title"><?php echo e($product->exists ? 'Edytuj' : 'Dodaj'); ?><br><em>produkt.</em></h1>
        </div>
        <a class="text-link" href="<?php echo e(route('admin.products.index')); ?>">Powrót do listy</a>
    </div>

    <form class="auth-form" method="POST" action="<?php echo e($product->exists ? route('admin.products.update', $product) : route('admin.products.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php if($product->exists): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="form-grid two-col">
            <label>
                SKU
                <input type="text" name="sku" value="<?php echo e(old('sku', $product->sku)); ?>" required>
                <?php $__errorArgs = ['sku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Slug
                <input type="text" name="slug" value="<?php echo e(old('slug', $product->slug)); ?>" required>
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="full-width">
                Nazwa produktu
                <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="full-width">
                Krótki opis
                <textarea name="short_description" rows="3" required><?php echo e(old('short_description', $product->short_description)); ?></textarea>
                <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="full-width">
                Opis produktu
                <textarea name="description" rows="6" required><?php echo e(old('description', $product->description)); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Rozmiar / etykieta
                <input type="text" name="size_label" value="<?php echo e(old('size_label', $product->size_label)); ?>">
                <?php $__errorArgs = ['size_label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                URL obrazka
                <input type="url" name="image_url" value="<?php echo e(old('image_url', $product->image_url)); ?>">
                <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Cena detaliczna (zł)
                <input type="number" step="0.01" min="0" name="retail_price" value="<?php echo e(old('retail_price', $product->retail_price)); ?>">
                <?php $__errorArgs = ['retail_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Stan magazynowy
                <input type="number" min="0" name="stock_quantity" value="<?php echo e(old('stock_quantity', $product->stock_quantity)); ?>">
                <?php $__errorArgs = ['stock_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Min. ilość zamówienia
                <input type="number" min="1" name="minimum_order_quantity" value="<?php echo e(old('minimum_order_quantity', $product->minimum_order_quantity)); ?>" required>
                <?php $__errorArgs = ['minimum_order_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label>
                Kolejność sortowania
                <input type="number" min="0" name="sort_order" value="<?php echo e(old('sort_order', $product->sort_order ?? 0)); ?>" required>
                <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>
            <label class="checkbox-row">
                <input type="checkbox" name="active" value="1" <?php echo e(old('active', $product->active) ? 'checked' : ''); ?>>
                Produkt aktywny i widoczny w katalogu
            </label>
        </div>

        <fieldset class="price-tier-fieldset">
            <legend>Ceny hurtowe</legend>
            <?php ($rows = old('wholesale_prices', $wholesalePrices)); ?>
            <?php $__errorArgs = ['wholesale_prices'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="price-tier-list" data-price-tier-list>
                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="price-tier-row">
                        <input type="hidden" name="wholesale_prices[<?php echo e($index); ?>][id]" value="<?php echo e($price['id'] ?? ''); ?>">
                        <label>
                            Min. ilość
                            <input type="number" min="<?php echo e(old('minimum_order_quantity', $product->minimum_order_quantity ?? 1)); ?>" name="wholesale_prices[<?php echo e($index); ?>][minimum_quantity]" value="<?php echo e(old('wholesale_prices.' . $index . '.minimum_quantity', $price['minimum_quantity'] ?? 1)); ?>">
                            <?php $__errorArgs = ['wholesale_prices.' . $index . '.minimum_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label>
                            Cena netto (zł)
                            <input type="number" step="0.01" min="0" name="wholesale_prices[<?php echo e($index); ?>][unit_price]" value="<?php echo e(old('wholesale_prices.' . $index . '.unit_price', $price['unit_price'] ?? '')); ?>">
                            <?php $__errorArgs = ['wholesale_prices.' . $index . '.unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label>
                            Od dnia
                            <input type="date" name="wholesale_prices[<?php echo e($index); ?>][starts_at]" value="<?php echo e(old('wholesale_prices.' . $index . '.starts_at', $price['starts_at'] ?? '')); ?>">
                            <?php $__errorArgs = ['wholesale_prices.' . $index . '.starts_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label>
                            Do dnia
                            <input type="date" name="wholesale_prices[<?php echo e($index); ?>][ends_at]" value="<?php echo e(old('wholesale_prices.' . $index . '.ends_at', $price['ends_at'] ?? '')); ?>">
                            <?php $__errorArgs = ['wholesale_prices.' . $index . '.ends_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <button class="button button-outline button-small" type="button" data-remove-price-tier hidden>Usuń próg</button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <template data-price-tier-template>
                <div class="price-tier-row">
                    <input type="hidden" name="wholesale_prices[__INDEX__][id]" value="">
                    <label>
                        Min. ilość
                        <input type="number" min="<?php echo e(old('minimum_order_quantity', $product->minimum_order_quantity ?? 1)); ?>" name="wholesale_prices[__INDEX__][minimum_quantity]" value="<?php echo e($product->minimum_order_quantity ?? 1); ?>">
                    </label>
                    <label>
                        Cena netto (zł)
                        <input type="number" step="0.01" min="0" name="wholesale_prices[__INDEX__][unit_price]" value="">
                    </label>
                    <label>
                        Od dnia
                        <input type="date" name="wholesale_prices[__INDEX__][starts_at]" value="">
                    </label>
                    <label>
                        Do dnia
                        <input type="date" name="wholesale_prices[__INDEX__][ends_at]" value="">
                    </label>
                    <button class="button button-outline button-small" type="button" data-remove-price-tier>Usuń próg</button>
                </div>
            </template>
            <button class="button button-outline button-small" type="button" data-add-price-tier hidden>Dodaj próg cenowy</button>
        </fieldset>

        <div class="form-actions">
            <button class="button button-dark" type="submit"><?php echo e($product->exists ? 'Zapisz zmiany' : 'Dodaj produkt'); ?></button>
            <a class="button button-outline" href="<?php echo e(route('admin.products.index')); ?>">Anuluj</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/products/form.blade.php ENDPATH**/ ?>