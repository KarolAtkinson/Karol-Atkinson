

<?php $__env->startSection('title', $product->name); ?>
<?php $__env->startSection('description', $product->short_description); ?>

<?php $__env->startSection('content'); ?>
    <section class="product-detail-section">
        <a class="text-link product-breadcrumb" href="<?php echo e(route('products.index')); ?>">← Wszystkie produkty</a>
        <article class="product-detail-card">
            <div class="product-image-wrap product-detail-image">
                <?php if($product->image_url): ?>
                    <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>">
                <?php else: ?>
                    <span class="product-image-placeholder">Naturadała</span>
                <?php endif; ?>
            </div>
            <div class="product-details">
                <p class="eyebrow">Produkt Naturadała · <?php echo e($product->sku); ?></p>
                <h1 class="product-detail-title"><?php echo e($product->name); ?></h1>
                <p class="product-description"><?php echo e($product->description); ?></p>
                <ul class="product-facts">
                    <?php if($product->size_label): ?>
                        <li><span>Opakowanie</span><strong><?php echo e($product->size_label); ?></strong></li>
                    <?php endif; ?>
                    <li><span>Forma</span><strong>Żel / galareta</strong></li>
                    <li><span>Minimalna ilość</span><strong><?php echo e($product->minimum_order_quantity); ?> szt.</strong></li>
                    <?php if($product->stock_quantity !== null): ?>
                        <li><span>Dostępność</span><strong><?php echo e($product->stock_quantity >= $product->minimum_order_quantity ? 'Dostępny' : 'Brak dostępnej ilości minimalnej'); ?></strong></li>
                    <?php endif; ?>
                </ul>
                <div class="catalogue-price detail-price">
                    <?php if($approvedRetailer && $product->wholesalePrices->isNotEmpty()): ?>
                        <span>Cena partnerska</span>
                        <?php $__currentLoopData = $product->wholesalePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong><?php echo e(number_format((float) $price->unit_price, 2, ',', ' ')); ?> zł <small>netto · od <?php echo e($price->minimum_quantity); ?> szt.</small></strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php elseif(! $approvedRetailer && $product->retail_price !== null): ?>
                        <?php if(auth()->user()?->isSubscriber()): ?>
                            <span>Cena dla subskrybenta (−<?php echo e(config('features.subscriber_discount_percent')); ?>%)</span>
                            <strong><?php echo e(number_format($product->subscriberPrice(), 2, ',', ' ')); ?> zł <s class="price-was"><?php echo e(number_format((float) $product->retail_price, 2, ',', ' ')); ?> zł</s></strong>
                        <?php else: ?>
                            <span>Cena detaliczna</span>
                            <strong><?php echo e(number_format((float) $product->retail_price, 2, ',', ' ')); ?> zł</strong>
                            <small class="price-hint"><a href="#newsletter">Zapisz się do newslettera: −<?php echo e(config('features.subscriber_discount_percent')); ?>% na wszystkie produkty</a></small>
                        <?php endif; ?>
                    <?php else: ?>
                        <span>Warunki sprzedaży</span>
                        <strong>Cena dostępna po kontakcie</strong>
                    <?php endif; ?>
                </div>
                <div class="product-detail-actions">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->hasVerifiedEmail()): ?>
                            <?php if($product->stock_quantity === null || $product->stock_quantity >= $product->minimum_order_quantity): ?>
                                <form method="POST" action="<?php echo e(route('basket.store', $product)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <label class="quantity-label" for="quantity">Ilość</label>
                                    <input class="quantity-input" id="quantity" name="quantity" type="number" min="<?php echo e($product->minimum_order_quantity); ?>" max="<?php echo e(min(999, $product->stock_quantity ?? 999)); ?>" value="<?php echo e($product->minimum_order_quantity); ?>" required>
                                    <button class="button button-dark" type="submit">Dodaj do koszyka <span aria-hidden="true">+</span></button>
                                </form>
                            <?php else: ?>
                                <p class="form-hint">Obecny stan nie pozwala zrealizować minimalnej ilości zamówienia.</p>
                            <?php endif; ?>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <form method="POST" action="<?php echo e($wishlisted ? route('wishlist.destroy', $product) : route('wishlist.store', $product)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if($wishlisted): ?> <?php echo method_field('DELETE'); ?> <?php endif; ?>
                                <button class="button button-outline" type="submit"><?php echo e($wishlisted ? 'Usuń z ulubionych' : 'Dodaj do ulubionych'); ?></button>
                            </form>
                        <?php else: ?>
                            <p class="form-hint">Potwierdź adres e-mail, aby korzystać z koszyka i listy ulubionych.</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <a class="button button-dark" href="<?php echo e(route('login')); ?>">Zaloguj się, aby dodać do koszyka <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                    <?php if(! $approvedRetailer && (! config('features.retailer_maintenance') || auth()->user()?->hasRole('admin'))): ?>
                        <a class="text-link" href="<?php echo e(auth()->check() && auth()->user()->hasVerifiedEmail() ? route('retailer.application') : route('register')); ?>">Zapytaj o współpracę hurtową <span aria-hidden="true">↗</span></a>
                    <?php endif; ?>
                </div>
                <p class="product-note">Informacje handlowe i aktualna dostępność wymagają potwierdzenia. Skład, porcjowanie i sposób użycia sprawdź na oficjalnym opakowaniu produktu.</p>
            </div>
        </article>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('products.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/products/show.blade.php ENDPATH**/ ?>