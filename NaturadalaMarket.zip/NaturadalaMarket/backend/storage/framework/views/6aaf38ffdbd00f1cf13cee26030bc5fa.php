

<?php $__env->startSection('title', 'Zmień hasło'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Moje konto</p>
            <h1 class="auth-title">Zmień<br><em>hasło.</em></h1>
        </div>
        <a class="text-link" href="<?php echo e(route('account.show')); ?>">Powrót do konta</a>
    </div>

    <p class="auth-description">Podaj obecne hasło, a następnie wybierz nowe, unikalne hasło.</p>

    <form class="auth-form" method="POST" action="<?php echo e(route('account.password.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="current_password">Obecne hasło</label>
        <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>
        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password">Nowe hasło</label>
        <input id="password" name="password" type="password" autocomplete="new-password" required>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="password_confirmation">Powtórz nowe hasło</label>
        <input id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password" required>

        <button class="button button-dark auth-submit" type="submit">Zapisz nowe hasło</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/password.blade.php ENDPATH**/ ?>