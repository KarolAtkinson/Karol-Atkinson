

<?php $__env->startSection('title', 'Baza partnerów'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja · baza danych</p>
            <h1 class="auth-title">Baza<br><em>partnerów.</em></h1>
        </div>
        <a class="button button-outline button-small" href="<?php echo e(route('admin.retailers.index')); ?>">Wnioski do weryfikacji</a>
    </div>
    <p class="auth-description">Wyszukuj firmy, przeglądaj statusy kont i zarządzaj dostępem do przestrzeni hurtowej. Zmiany są zapisywane w historii bezpieczeństwa.</p>

    <?php if(session('status') === 'retailer-access-updated'): ?>
        <p class="status-message">Dostęp partnera został zaktualizowany.</p>
    <?php endif; ?>

    <form class="inquiry-filters retailer-filters" method="GET" action="<?php echo e(route('admin.retailers.directory')); ?>">
        <label>
            <span class="sr-only">Szukaj firm</span>
            <input type="search" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" maxlength="120" placeholder="Szukaj firmy, NIP-u, kontaktu lub e-maila">
        </label>
        <label>
            <span class="sr-only">Status weryfikacji</span>
            <select name="status">
                <option value="">Wszystkie wnioski</option>
                <option value="pending" <?php if(($filters['status'] ?? '') === 'pending'): echo 'selected'; endif; ?>>Oczekujące</option>
                <option value="approved" <?php if(($filters['status'] ?? '') === 'approved'): echo 'selected'; endif; ?>>Zatwierdzone</option>
                <option value="rejected" <?php if(($filters['status'] ?? '') === 'rejected'): echo 'selected'; endif; ?>>Odrzucone</option>
            </select>
        </label>
        <label>
            <span class="sr-only">Status konta</span>
            <select name="account">
                <option value="">Wszystkie konta</option>
                <option value="active" <?php if(($filters['account'] ?? '') === 'active'): echo 'selected'; endif; ?>>Aktywne</option>
                <option value="suspended" <?php if(($filters['account'] ?? '') === 'suspended'): echo 'selected'; endif; ?>>Zawieszone</option>
            </select>
        </label>
        <button class="button button-outline button-small" type="submit">Filtruj</button>
    </form>

    <?php $__empty_1 = true; $__currentLoopData = $retailers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="retailer-review-card">
            <div class="retailer-directory-heading">
                <div>
                    <p class="eyebrow">Rekord #<?php echo e($profile->id); ?> · <?php echo e($profile->created_at->format('d.m.Y')); ?></p>
                    <h2><?php echo e($profile->legal_business_name); ?></h2>
                </div>
                <span class="retailer-status-badge"><?php echo e($profile->verification_status === 'approved' ? 'Zatwierdzona' : ($profile->verification_status === 'pending' ? 'Oczekuje' : 'Odrzucona')); ?> · <?php echo e($profile->user->status === 'active' ? 'konto aktywne' : 'konto zawieszone'); ?></span>
            </div>
            <dl>
                <div><dt>Kontakt</dt><dd><?php echo e($profile->user->name); ?> · <a href="mailto:<?php echo e($profile->user->email); ?>"><?php echo e($profile->user->email); ?></a></dd></div>
                <div><dt>NIP / identyfikator</dt><dd><?php echo e($profile->tax_identifier ?: 'Nie podano'); ?></dd></div>
                <div><dt>Telefon</dt><dd><?php echo e($profile->business_phone ?: $profile->user->phone ?: 'Nie podano'); ?></dd></div>
                <div><dt>Strona internetowa</dt><dd><?php echo e($profile->website ?: 'Nie podano'); ?></dd></div>
                <div><dt>E-mail potwierdzony</dt><dd><?php echo e($profile->user->hasVerifiedEmail() ? 'Tak' : 'Nie'); ?></dd></div>
                <div><dt>Data zgłoszenia</dt><dd><?php echo e($profile->submitted_at?->format('d.m.Y H:i') ?: '—'); ?></dd></div>
            </dl>
            <?php if($profile->verification_status === 'approved'): ?>
                <div class="retailer-admin-actions">
                    <?php if($profile->user->status === 'active'): ?>
                        <form class="review-form" method="POST" action="<?php echo e(route('admin.retailers.access.update', $profile)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="action" value="suspend">
                            <label for="suspend-reason-<?php echo e($profile->id); ?>">Powód zawieszenia</label>
                            <input id="suspend-reason-<?php echo e($profile->id); ?>" name="reason" required maxlength="2000">
                            <button class="button button-outline button-small" type="submit">Zawieś konto</button>
                        </form>
                        <form class="review-form" method="POST" action="<?php echo e(route('admin.retailers.access.update', $profile)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="action" value="revoke">
                            <label for="revoke-reason-<?php echo e($profile->id); ?>">Powód odebrania dostępu hurtowego</label>
                            <input id="revoke-reason-<?php echo e($profile->id); ?>" name="reason" required maxlength="2000">
                            <button class="button button-outline button-small" type="submit">Odbierz dostęp hurtowy</button>
                        </form>
                    <?php else: ?>
                        <form method="POST" action="<?php echo e(route('admin.retailers.access.update', $profile)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="action" value="reactivate">
                            <button class="button button-dark button-small" type="submit" <?php if(! $profile->user->hasVerifiedEmail()): echo 'disabled'; endif; ?>>Przywróć konto</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php elseif($profile->verification_status === 'pending'): ?>
                <p class="notice-panel">Aby przyznać dostęp, otwórz wniosek do weryfikacji. Zatwierdzenie wymaga aktywnego konta i potwierdzonego adresu e-mail.</p>
                <a class="text-link" href="<?php echo e(route('admin.retailers.index', ['q' => $profile->legal_business_name])); ?>">Otwórz proces weryfikacji <span aria-hidden="true">↗</span></a>
            <?php else: ?>
                <p class="retailer-disclaimer">Ten rekord zachowano do historii. Firma może ponownie przesłać wniosek po uzupełnieniu danych.</p>
            <?php endif; ?>
            <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notice-panel"><strong>Brak firm spełniających kryteria.</strong><p>Usuń część filtrów lub sprawdź pisownię.</p></div>
    <?php endif; ?>

    <?php echo e($retailers->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/retailers/directory.blade.php ENDPATH**/ ?>