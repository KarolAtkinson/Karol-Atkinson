<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <title><?php echo $__env->yieldContent('title'); ?> | Naturadała</title>
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <script src="<?php echo e(asset('image-fallback.js')); ?>"></script>
    <script src="<?php echo e(asset('en-translations.js')); ?>" defer></script>
    <script src="<?php echo e(asset('cookie-consent.js')); ?>" defer></script>
    <script src="<?php echo e(asset('app.js')); ?>" defer></script>
</head>
<body class="auth-page">
    <a class="skip-link" href="#main">Przejdź do treści</a>
    <header class="auth-header">
        <div class="brand-language-group">
            <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="Naturadała — strona główna">
                <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
            </a>
            <?php echo $__env->make('shared.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
        <a class="text-link" href="<?php echo e(route('home')); ?>">Powrót do sklepu <span aria-hidden="true">↗</span></a>
    </header>
    <main class="auth-main" id="main">
        <section class="auth-card">
            <p class="eyebrow"><span class="eyebrow-line"></span> Naturadała · konto</p>
            <?php if($errors->any()): ?>
                <div class="form-errors" role="alert">
                    <p>Sprawdź dane w formularzu:</p>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </section>
    </main>
    <footer class="auth-footer">
        <a href="mailto:kontakt@naturadala.pl">Potrzebujesz pomocy? Napisz do nas</a>
        <span>© <?php echo e(now()->year); ?> Naturadała</span>
        <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button>
    </footer>
    <?php echo $__env->make('shared.cookie-consent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/auth/layout.blade.php ENDPATH**/ ?>