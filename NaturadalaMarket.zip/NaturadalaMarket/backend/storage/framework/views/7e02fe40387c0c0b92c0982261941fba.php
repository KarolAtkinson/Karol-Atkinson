

<?php $__env->startSection('title', 'Uwierzytelnianie dwuetapowe'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Dodatkowa<br><em>ochrona.</em></h1>
    <p class="auth-description">Aplikacja uwierzytelniająca generuje jednorazowe, sześciocyfrowe kody. Kod jest wymagany przy każdym nowym logowaniu.</p>

    <?php if(session('status') === 'mfa-disabled'): ?>
        <p class="status-message">Uwierzytelnianie dwuetapowe zostało wyłączone.</p>
    <?php endif; ?>

    <?php if(session()->has('recoveryCodes')): ?>
        <div class="recovery-panel" role="status">
            <strong>Zapisz kody odzyskiwania</strong>
            <p>Każdy kod można wykorzystać tylko raz. Ta lista nie zostanie ponownie wyświetlona.</p>
            <ul>
                <?php $__currentLoopData = session('recoveryCodes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><code><?php echo e($code); ?></code></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($enabled): ?>
        <div class="notice-panel mfa-enabled">
            <strong>Uwierzytelnianie jest włączone.</strong>
            <p>Zachowaj kody odzyskiwania w bezpiecznym miejscu. Możesz wygenerować nowy zestaw, a poprzednie kody przestaną działać.</p>
        </div>
        <form class="auth-form" method="POST" action="<?php echo e(route('mfa.recovery-codes.regenerate')); ?>">
            <?php echo csrf_field(); ?>
            <label for="recovery_current_password">Bieżące hasło</label>
            <input id="recovery_current_password" name="current_password" type="password" autocomplete="current-password" required>
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label for="recovery_code">Aktualny kod z aplikacji</label>
            <input id="recovery_code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required>
            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button class="button button-outline auth-submit" type="submit">Wygeneruj nowe kody odzyskiwania</button>
        </form>
        <form class="auth-form" method="POST" action="<?php echo e(route('mfa.destroy')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <label for="password">Bieżące hasło</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
            <label for="code">Aktualny kod z aplikacji</label>
            <input id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required>
            <button class="button button-outline auth-submit" type="submit">Wyłącz dodatkową ochronę</button>
        </form>
    <?php else: ?>
        <ol class="mfa-steps">
            <li>Otwórz aplikację uwierzytelniającą na telefonie i dodaj nowe konto.</li>
            <li>Wybierz ręczne wpisanie klucza i wpisz poniższy klucz jako konto czasowe (TOTP).</li>
            <li>Wpisz wygenerowany kod, aby potwierdzić konfigurację.</li>
        </ol>
        <div class="mfa-secret-wrap">
            <span>Klucz do aplikacji uwierzytelniającej</span>
            <code class="mfa-secret"><?php echo e($secret); ?></code>
            <p>Nie udostępniaj tego klucza. Jest tymczasowy i wygaśnie po 10 minutach.</p>
        </div>
        <form class="auth-form" method="POST" action="<?php echo e(route('mfa.store')); ?>">
            <?php echo csrf_field(); ?>
            <label for="password">Potwierdź bieżącym hasłem</label>
            <input id="password" name="password" type="password" autocomplete="current-password" required>
            <label for="code">Sześciocyfrowy kod z aplikacji</label>
            <input id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required>
            <button class="button button-dark auth-submit" type="submit">Włącz dodatkową ochronę <span aria-hidden="true">↗</span></button>
        </form>
    <?php endif; ?>

    <p class="auth-switch"><a href="<?php echo e(route('account.show')); ?>">Wróć do konta</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/auth/two-factor-settings.blade.php ENDPATH**/ ?>