

<?php $__env->startSection('title', 'Koszyk'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Twój<br><em>koszyk.</em></h1>
    <?php if(session('status') === 'basket-item-added'): ?>
        <p class="status-message">Produkt dodano do koszyka.</p>
    <?php elseif(session('status') === 'basket-updated'): ?>
        <p class="status-message">Ilość produktu została zaktualizowana.</p>
    <?php elseif(session('status') === 'basket-item-removed'): ?>
        <p class="status-message">Produkt został usunięty z koszyka.</p>
    <?php endif; ?>
    <?php if($errors->has('basket')): ?>
        <p class="field-error" role="alert"><?php echo e($errors->first('basket')); ?></p>
    <?php endif; ?>
    <p class="auth-description">Zawartość koszyka jest zapisana na Twoim koncie. Ceny oraz dostępność wymagają potwierdzenia.</p>
    <?php if($items->isEmpty()): ?>
        <div class="notice-panel">
            <strong>Koszyk jest pusty.</strong>
            <p>Wróć do katalogu, aby wybrać produkt.</p>
            <a class="button button-dark" href="<?php echo e(route('products.index')); ?>">Przejdź do produktów <span aria-hidden="true">↗</span></a>
        </div>
    <?php else: ?>
        <div class="saved-product-list">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="saved-product">
                    <a class="saved-product-image" href="<?php echo e(route('products.show', $item->product)); ?>">
                        <?php if($item->product->image_url): ?><img src="<?php echo e($item->product->image_url); ?>" alt="" loading="lazy"><?php endif; ?>
                    </a>
                    <div>
                        <h2>
                            <?php if($item->product->active): ?>
                                <a href="<?php echo e(route('products.show', $item->product)); ?>"><?php echo e($item->product->name); ?></a>
                            <?php else: ?>
                                <?php echo e($item->product->name); ?>

                            <?php endif; ?>
                        </h2>
                        <p><?php echo e($item->product->short_description); ?></p>
                        <?php if($item->product->priceFor(auth()->user()) !== null): ?>
                            <p class="basket-line-price"><?php echo e(number_format($item->product->priceFor(auth()->user()), 2, ',', ' ')); ?> zł / szt. · razem <?php echo e(number_format($item->product->priceFor(auth()->user()) * $item->quantity, 2, ',', ' ')); ?> zł</p>
                        <?php endif; ?>
                        <?php if(! $item->product->active): ?>
                            <p class="basket-item-unavailable">Produkt nie jest obecnie dostępny w katalogu. Usuń go z koszyka, aby kontynuować.</p>
                        <?php else: ?>
                            <?php if($item->product->stock_quantity !== null && $item->quantity > $item->product->stock_quantity): ?>
                                <p class="basket-item-unavailable">Dostępna ilość uległa zmianie. Zaktualizuj koszyk lub usuń produkt.</p>
                            <?php endif; ?>
                            <form class="basket-quantity-form" method="POST" action="<?php echo e(route('basket.update', $item)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <label for="quantity-<?php echo e($item->id); ?>">Ilość</label>
                                <input id="quantity-<?php echo e($item->id); ?>" name="quantity" type="number" min="<?php echo e($item->product->minimum_order_quantity); ?>" max="<?php echo e(min(999, $item->product->stock_quantity ?? 999)); ?>" value="<?php echo e($item->quantity); ?>" required>
                                <button class="text-link" type="submit">Zmień ilość</button>
                            </form>
                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                    </div>
                    <form method="POST" action="<?php echo e(route('basket.destroy', $item)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="remove-button" type="submit" aria-label="Usuń <?php echo e($item->product->name); ?> z koszyka">Usuń</button>
                    </form>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php
            $basketTotal = $items->sum(fn ($i) => $i->product->active ? ($i->product->priceFor(auth()->user()) ?? 0) * $i->quantity : 0);
        ?>
        <div class="basket-next-step">
            <?php if($basketTotal > 0): ?>
                <p class="basket-total"><strong>Suma: <?php echo e(number_format($basketTotal, 2, ',', ' ')); ?> zł</strong><?php if(auth()->user()->isSubscriber()): ?> <small>(w tym zniżka subskrybenta −<?php echo e(config('features.subscriber_discount_percent')); ?>%)</small><?php endif; ?></p>
            <?php endif; ?>
            <p>Składanie zamówień i płatności online nie są jeszcze aktywne.</p>
            <form method="POST" action="<?php echo e(route('basket.inquiry')); ?>">
                <?php echo csrf_field(); ?>
                <button class="button button-dark" type="submit">Zapytaj o produkty <span aria-hidden="true">↗</span></button>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/basket.blade.php ENDPATH**/ ?>