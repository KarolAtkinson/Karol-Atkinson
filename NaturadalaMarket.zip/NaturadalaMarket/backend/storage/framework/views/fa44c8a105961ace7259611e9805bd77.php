

<?php $__env->startSection('title', 'Dane konta'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Moje konto</p>
            <h1 class="auth-title">Dane<br><em>konta.</em></h1>
        </div>
        <a class="text-link" href="<?php echo e(route('account.show')); ?>">Powrót do konta</a>
    </div>

    <p class="auth-description">Zaktualizuj imię i nazwisko lub numer telefonu. Zmiana adresu e-mail wymaga potwierdzenia nowego adresu.</p>
    <?php if(session('status') === 'email-unchanged'): ?>
        <p class="status-message">Ten adres e-mail jest już przypisany do konta.</p>
    <?php endif; ?>

    <form class="auth-form" method="POST" action="<?php echo e(route('account.profile.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="name">Imię i nazwisko</label>
        <input id="name" name="name" type="text" value="<?php echo e(old('name', $user->name)); ?>" maxlength="190" autocomplete="name" required>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="email">Adres e-mail</label>
        <input id="email" type="email" value="<?php echo e($user->email); ?>" autocomplete="email" disabled>
        <span class="field-hint">Aby zmienić adres, użyj osobnego formularza poniżej. Dostęp do konta będzie wymagał potwierdzenia nowego adresu.</span>

        <label for="phone">Telefon <span class="field-optional">(opcjonalnie)</span></label>
        <input id="phone" name="phone" type="tel" value="<?php echo e(old('phone', $user->phone)); ?>" maxlength="32" autocomplete="tel">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="button button-dark auth-submit" type="submit">Zapisz dane</button>
    </form>

    <form class="auth-form" method="POST" action="<?php echo e(route('account.profile.email.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <p class="eyebrow">Zmiana adresu e-mail</p>
        <label for="new_email">Nowy adres e-mail</label>
        <input id="new_email" name="email" type="email" value="<?php echo e(old('email')); ?>" maxlength="255" autocomplete="email" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="email_current_password">Potwierdź bieżącym hasłem</label>
        <input id="email_current_password" name="current_password" type="password" autocomplete="current-password" required>
        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button class="button button-dark auth-submit" type="submit">Zmień adres i wyślij link weryfikacyjny</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/profile.blade.php ENDPATH**/ ?>