

<?php $__env->startSection('title', 'Przestrzeń partnera'); ?>

<?php $__env->startSection('content'); ?>
    <section class="retailer-welcome">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Naturadała · konto partnera</p>
            <h1>Przestrzeń<br><em>handlowa.</em></h1>
            <p>Witaj, <?php echo e($profile->legal_business_name); ?>. Tutaj znajdziesz katalog, warunki partnerskie i przypisane informacje o współpracy.</p>
        </div>
        <span class="retailer-status-badge">Konto zatwierdzone</span>
    </section>

    <section class="retailer-record-grid" aria-label="Podsumowanie firmy">
        <article class="retailer-record-card">
            <span>Firma</span>
            <strong><?php echo e($profile->legal_business_name); ?></strong>
            <small><?php echo e($profile->tax_identifier ?: 'Identyfikator firmy nieuzupełniony'); ?></small>
        </article>
        <article class="retailer-record-card">
            <span>Osoba kontaktowa</span>
            <strong><?php echo e(auth()->user()->name); ?></strong>
            <small><?php echo e(auth()->user()->email); ?></small>
        </article>
        <article class="retailer-record-card">
            <span>Rekordy umów</span>
            <strong><?php echo e($profile->contracts->count()); ?></strong>
            <small>Metadane umów, nie dokumenty prawne</small>
        </article>
    </section>

    <section class="retailer-data-section" aria-labelledby="retailer-catalogue-heading">
        <div class="retailer-section-heading">
            <div>
                <p class="eyebrow"><span class="eyebrow-line"></span> Baza produktów</p>
                <h2 id="retailer-catalogue-heading">Katalog hurtowy</h2>
            </div>
            <a class="button button-dark" href="<?php echo e(route('basket.show')); ?>">Otwórz zapytanie <span aria-hidden="true">↗</span></a>
        </div>
        <form class="retailer-search" method="GET" action="<?php echo e(route('retailer.workspace')); ?>">
            <label for="retailer-search">Szukaj po nazwie, SKU lub opisie</label>
            <input id="retailer-search" type="search" name="q" value="<?php echo e($search); ?>" maxlength="120" placeholder="Nazwa produktu lub SKU">
            <button class="button button-outline button-small" type="submit">Szukaj</button>
            <?php if($search !== ''): ?>
                <a class="text-link" href="<?php echo e(route('retailer.workspace')); ?>">Wyczyść</a>
            <?php endif; ?>
        </form>
        <?php $__errorArgs = ['q'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error" role="alert"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="retailer-table-wrap">
            <table class="retailer-table">
                <caption class="sr-only">Aktywne produkty i hurtowe warunki handlowe dla zatwierdzonej firmy</caption>
                <thead>
                    <tr>
                        <th scope="col">Produkt</th>
                        <th scope="col">SKU</th>
                        <th scope="col">Minimalne zamówienie</th>
                        <th scope="col">Cena partnerska</th>
                        <th scope="col">Dostępność</th>
                        <th scope="col">Działanie</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row">
                                <a href="<?php echo e(route('products.show', $product)); ?>"><?php echo e($product->name); ?></a>
                                <small><?php echo e($product->short_description); ?></small>
                            </th>
                            <td><code><?php echo e($product->sku); ?></code></td>
                            <td><?php echo e($product->minimum_order_quantity); ?> szt.</td>
                            <td>
                                <?php $__empty_2 = true; $__currentLoopData = $product->wholesalePrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <span class="retailer-price"><?php echo e(number_format((float) $price->unit_price, 2, ',', ' ')); ?> zł</span>
                                    <small>netto · od <?php echo e($price->minimum_quantity); ?> szt.</small>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <span>Zapytaj o ofertę</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->stock_quantity === null ? 'Potwierdź przed zamówieniem' : $product->stock_quantity.' szt.'); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('basket.store', $product)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="quantity" value="<?php echo e($product->minimum_order_quantity); ?>">
                                    <button class="button button-outline button-small" type="submit">Dodaj do zapytania</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">Brak produktów pasujących do wyszukiwania.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($products->links()); ?>

    </section>

    <section class="retailer-data-section" aria-labelledby="retailer-contract-heading">
        <div class="retailer-section-heading">
            <div>
                <p class="eyebrow"><span class="eyebrow-line"></span> Rejestr współpracy</p>
                <h2 id="retailer-contract-heading">Umowy i ustalenia</h2>
            </div>
        </div>
        <p class="retailer-disclaimer">Widoczne są wyłącznie metadane przypisane do Twojej firmy. Treść umów i warunki prawne nie są przechowywane ani tworzone w tym module.</p>
        <div class="retailer-table-wrap">
            <table class="retailer-table">
                <caption class="sr-only">Metadane umów przypisanych do tej firmy</caption>
                <thead><tr><th scope="col">Numer</th><th scope="col">Tytuł / typ</th><th scope="col">Właściciel po stronie Naturadała</th><th scope="col">Okres</th><th scope="col">Status</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $profile->contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><code><?php echo e($contract->reference); ?></code></th>
                            <td><?php echo e($contract->title); ?><small><?php echo e($contract->contract_type); ?></small></td>
                            <td><?php echo e($contract->internalOwner?->name ?: 'Nieprzypisany'); ?></td>
                            <td><?php echo e($contract->effective_date?->format('d.m.Y') ?: '—'); ?> – <?php echo e($contract->expiry_date?->format('d.m.Y') ?: '—'); ?></td>
                            <td><?php echo e(ucfirst($contract->status)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5">Nie przypisano jeszcze rekordów umów do tej firmy.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('retailer.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/retailer/workspace.blade.php ENDPATH**/ ?>