

<?php $__env->startSection('title', 'Moje adresy'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Moje konto</p>
            <h1 class="auth-title">Zapisane<br><em>adresy.</em></h1>
        </div>
        <a class="button button-dark" href="<?php echo e(route('addresses.create')); ?>">Dodaj adres</a>
    </div>

    <?php if(session('status') === 'address-saved'): ?>
        <p class="status-message">Adres został zapisany.</p>
    <?php elseif(session('status') === 'address-deleted'): ?>
        <p class="status-message">Adres został usunięty.</p>
    <?php endif; ?>

    <p class="auth-description">Zarządzaj zapisanymi adresami. Zakupy online nie są jeszcze dostępne.</p>

    <?php $__empty_1 = true; $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="address-card">
            <div class="address-card-heading">
                <div>
                    <h2><?php echo e($address->label ?: $address->recipient_name); ?></h2>
                    <div class="address-badges">
                        <?php if($address->is_default_billing): ?><span class="audience-badge">Domyślny rozliczeniowy</span><?php endif; ?>
                        <?php if($address->is_default_shipping): ?><span class="audience-badge">Domyślny dostawy</span><?php endif; ?>
                    </div>
                </div>
                <div class="admin-actions">
                    <a class="button button-outline button-small" href="<?php echo e(route('addresses.edit', $address)); ?>">Edytuj</a>
                    <form method="POST" action="<?php echo e(route('addresses.destroy', $address)); ?>" onsubmit="return confirm('Usunąć zapisany adres?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="button button-danger button-small" type="submit">Usuń</button>
                    </form>
                </div>
            </div>
            <p>
                <strong><?php echo e($address->recipient_name); ?></strong>
                <?php if($address->company_name): ?><br><?php echo e($address->company_name); ?><?php endif; ?>
                <br><?php echo e($address->street_line_1); ?>

                <?php if($address->street_line_2): ?><br><?php echo e($address->street_line_2); ?><?php endif; ?>
                <br><?php echo e($address->postal_code); ?> <?php echo e($address->city); ?>

                <?php if($address->region): ?><br><?php echo e($address->region); ?><?php endif; ?>
                <br><?php echo e($address->country_code); ?>

                <?php if($address->phone): ?><br><?php echo e($address->phone); ?><?php endif; ?>
            </p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notice-panel">
            <strong>Nie masz jeszcze zapisanych adresów.</strong>
            <p>Dodaj adres, aby mieć go pod ręką przy przyszłych zamówieniach.</p>
            <a class="button button-dark" href="<?php echo e(route('addresses.create')); ?>">Dodaj adres</a>
        </div>
    <?php endif; ?>

    <a class="text-link" href="<?php echo e(route('account.show')); ?>">Powrót do konta</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/addresses/index.blade.php ENDPATH**/ ?>