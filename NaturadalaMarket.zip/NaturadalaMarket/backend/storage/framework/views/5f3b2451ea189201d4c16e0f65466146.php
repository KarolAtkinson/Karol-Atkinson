

<?php $__env->startSection('title', 'Historia bezpieczeństwa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Moje konto</p>
            <h1 class="auth-title">Historia<br><em>bezpieczeństwa.</em></h1>
        </div>
        <a class="text-link" href="<?php echo e(route('account.show')); ?>">Powrót do konta</a>
    </div>

    <p class="auth-description">Ostatnie zdarzenia związane z logowaniem i ochroną konta. Historia zawiera maksymalnie 20 zdarzeń na stronie.</p>

    <?php if(session('status') === 'other-sessions-revoked'): ?>
        <p class="status-message">Wylogowano inne urządzenia. To urządzenie pozostaje zalogowane.</p>
    <?php endif; ?>

    <form class="auth-form" method="POST" action="<?php echo e(route('account.security-events.revoke-other-sessions')); ?>">
        <?php echo csrf_field(); ?>
        <p>Możesz wylogować swoje konto na innych urządzeniach. Bieżąca sesja pozostanie aktywna.</p>
        <label for="current_password">Potwierdź bieżącym hasłem</label>
        <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>
        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button class="button button-outline auth-submit" type="submit">Wyloguj inne urządzenia</button>
    </form>

    <?php
        $eventLabels = [
            'account_registered' => 'Utworzono konto',
            'email_verified' => 'Potwierdzono adres e-mail',
            'email_change_requested' => 'Rozpoczęto zmianę adresu e-mail',
            'other_sessions_revoked' => 'Wylogowano inne urządzenia',
            'login_succeeded' => 'Udane logowanie',
            'login_failed' => 'Nieudana próba logowania',
            'login_blocked' => 'Zablokowano próbę logowania',
            'logout' => 'Wylogowano się',
            'password_changed' => 'Zmieniono hasło',
            'password_reset' => 'Zresetowano hasło',
            'mfa_enabled' => 'Włączono uwierzytelnianie dwuetapowe',
            'mfa_disabled' => 'Wyłączono uwierzytelnianie dwuetapowe',
            'mfa_recovery_codes_regenerated' => 'Wygenerowano nowe kody odzyskiwania',
            'mfa_challenge_succeeded' => 'Pomyślnie potwierdzono uwierzytelnianie dwuetapowe',
            'mfa_challenge_failed' => 'Nie udało się potwierdzić uwierzytelniania dwuetapowego',
            'retailer_application_submitted' => 'Wysłano wniosek firmy',
            'retailer_application_approved' => 'Zatwierdzono wniosek firmy',
            'retailer_application_rejected' => 'Wniosek firmy wymaga uzupełnienia',
        ];
    ?>

    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="address-card security-event-card">
            <div class="address-card-heading">
                <strong><?php echo e($eventLabels[$event->event_type] ?? 'Zdarzenie bezpieczeństwa konta'); ?></strong>
                <time datetime="<?php echo e($event->created_at->toIso8601String()); ?>"><?php echo e($event->created_at->format('Y-m-d H:i')); ?></time>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="notice-panel">
            <strong>Brak zapisanych zdarzeń bezpieczeństwa.</strong>
            <p>Zdarzenia związane z logowaniem i ochroną konta pojawią się tutaj.</p>
        </div>
    <?php endif; ?>

    <?php echo e($events->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/account/security-events.blade.php ENDPATH**/ ?>