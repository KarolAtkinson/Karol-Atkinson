<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f0">
    <meta name="description" content="Poznaj ofertę hurtową Naturadała. Naturalny koncentrat kolagenowy dla sklepów, gabinetów i partnerów biznesowych.">
    <title>Oferta hurtowa | Naturadała</title>
    <link rel="preconnect" href="https://naturadala.pl">
    <link rel="stylesheet" href="<?php echo e(asset('styles.css')); ?>">
    <script src="<?php echo e(asset('image-fallback.js')); ?>"></script>
    <script src="<?php echo e(asset('en-translations.js')); ?>" defer></script>
    <script src="<?php echo e(asset('cookie-consent.js')); ?>" defer></script>
    <script src="<?php echo e(asset('app.js')); ?>" defer></script>
  </head>
  <body>
    <a class="skip-link" href="#main">Przejdź do treści</a>

    <?php echo $__env->make('shared.announcement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <header class="site-header">
      <div class="brand-language-group">
        <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="Naturadała — strona główna">
          <img src="https://naturadala.pl/wp-content/uploads/2026/02/logopoziomztm.png" alt="Naturadała">
        </a>
        <?php echo $__env->make('shared.language-switcher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </div>

      <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">
        <span class="menu-toggle-label">Menu</span>
        <span class="menu-icon" aria-hidden="true"><i></i><i></i></span>
      </button>

      <nav class="primary-navigation" id="primary-navigation" aria-label="Nawigacja główna">
        <a href="<?php echo e(route('products.index')); ?>">Produkty</a>
        <a href="#wspolpraca">Współpraca</a>
        <a href="#o-nas">O Naturadale</a>
        <a href="#kontakt">Kontakt</a>
      </nav>

      <div class="header-actions">
        <?php if(auth()->guard()->guest()): ?>
          <a class="account-link" href="<?php echo e(route('login')); ?>">Zaloguj się</a>
          <?php if(config('marketplace.registration_enabled')): ?>
            <a class="button button-small button-outline" href="<?php echo e(route('register')); ?>">Zarejestruj się</a>
          <?php endif; ?>
        <?php else: ?>
          <a class="account-link" href="<?php echo e(route('account.show')); ?>">Moje konto</a>
        <?php endif; ?>
        <a class="button button-small button-dark" href="<?php echo e(route('products.index')); ?>">Oferta <span aria-hidden="true">↗</span></a>
        <?php echo $__env->make('shared.basket-button', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      </div>
    </header>

    <main id="main">
      <section class="hero" id="top">
        <div class="hero-copy">
          <p class="eyebrow"><span class="eyebrow-line"></span> Oferta dla partnerów</p>
          <h1>Naturalnie<br>dobry <em>wybór.</em></h1>
          <p class="hero-lede">Wprowadź do swojej oferty wyjątkowy koncentrat kolagenowy Naturadała — produkt, który powstaje z troską o skład i dobry rytm codzienności.</p>
          <div class="hero-actions">
            <a class="button button-dark" href="#oferta">Poznaj ofertę <span aria-hidden="true">↓</span></a>
            <a class="text-link" href="#wspolpraca">Jak zacząć współpracę <span aria-hidden="true">↗</span></a>
          </div>
          <div class="hero-proof">
            <span class="proof-mark" aria-hidden="true">✳</span>
            <span>Polski produkt<br><strong>Prosty skład</strong></span>
          </div>
        </div>
        <div class="hero-art" aria-label="Koncentrat kolagenowy Naturadała">
          <div class="hero-art-wash"></div>
          <div class="hero-art-note">Codzienna porcja<br>dobrego wyboru</div>
          <img class="hero-product" src="https://naturadala.pl/wp-content/uploads/2026/08/naturadala-sloik.webp" alt="Słoik koncentratu kolagenowego Naturadała, 320 g">
          <span class="hero-spark hero-spark-one" aria-hidden="true">✳</span>
          <span class="hero-spark hero-spark-two" aria-hidden="true">✳</span>
          <span class="hero-caption">Naturadała · koncentrat kolagenowy</span>
        </div>
        <a class="hero-scroll" href="#wspolpraca" aria-label="Przewiń do informacji o współpracy"><span></span> Odkryj Naturadała</a>
      </section>

      <section class="intro-band" id="wspolpraca">
        <p class="eyebrow"><span class="eyebrow-line"></span> Dla sklepów i profesjonalistów</p>
        <div class="intro-content">
          <h2>Produkty, za którymi<br><em>stoi dobra historia.</em></h2>
          <div class="intro-description">
            <p>Naturadała łączy prostą recepturę, staranny proces przygotowania i wygodną formę żelu. Szukamy partnerów, którzy chcą opowiadać o świadomych wyborach po swojemu.</p>
            <a class="text-link" href="#o-nas">Poznaj naszą historię <span aria-hidden="true">↗</span></a>
          </div>
        </div>
        <div class="values-row" aria-label="Cechy produktu">
          <article class="value-item">
            <span class="value-number">01</span>
            <span class="value-icon" aria-hidden="true">✳</span>
            <h3>Prosty skład</h3>
            <p>Bez konserwantów i zbędnych dodatków.</p>
          </article>
          <article class="value-item">
            <span class="value-number">02</span>
            <span class="value-icon" aria-hidden="true">◌</span>
            <h3>Tradycyjna receptura</h3>
            <p>Koncentrat przygotowywany w niskiej temperaturze.</p>
          </article>
          <article class="value-item">
            <span class="value-number">03</span>
            <span class="value-icon" aria-hidden="true">⌁</span>
            <h3>Polska produkcja</h3>
            <p>Marka i produkt tworzone w Polsce.</p>
          </article>
          <article class="value-item">
            <span class="value-number">04</span>
            <span class="value-icon" aria-hidden="true">◎</span>
            <h3>Badania laboratoryjne</h3>
            <p>Produkt badany przez laboratorium GBO Polska.</p>
          </article>
        </div>
      </section>

      <section class="benefits-section" aria-labelledby="partner-benefits-title">
        <div class="section-heading">
          <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Dla partnerów</p>
            <h2 id="partner-benefits-title">Współpraca, która<br><em>ma sens.</em></h2>
          </div>
          <p class="section-heading-note">Dzięki jasnym warunkom i prostemu procesowi łatwiej wprowadzić produkt do oferty i prowadzić sprzedaż z większym spokojem.</p>
        </div>

        <div class="benefits-grid">
          <article class="benefit-card">
            <span class="benefit-number">01</span>
            <h3>Naturalna oferta</h3>
            <p>Produkt oparty na prostym składzie, z którego można budować spójny przekaz dla klientów i partnerów handlowych.</p>
          </article>
          <article class="benefit-card">
            <span class="benefit-number">02</span>
            <h3>Prosty proces</h3>
            <p>Wystarczy kontakt, rozmowa i dopasowanie warunków, by rozpocząć współpracę bez zbędnych formalności.</p>
          </article>
          <article class="benefit-card">
            <span class="benefit-number">03</span>
            <h3>Dobry dobór</h3>
            <p>Produkt sprawdza się w punktach sprzedaży, gabinetach i kanałach online, gdzie liczy się jakość i wartość dla klienta.</p>
          </article>
        </div>
      </section>

      <section class="product-section" id="oferta">
        <div class="section-heading">
          <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Poznaj produkt</p>
            <h2>Dobry początek<br><em>współpracy.</em></h2>
          </div>
          <p class="section-heading-note">Poznaj nasz produkt i zapytaj o warunki dopasowane do Twojego biznesu.</p>
        </div>

        <article class="product-card">
          <div class="product-image-wrap">
            <span class="product-stamp">Naturadała<br>od środka</span>
            <img src="https://naturadala.pl/wp-content/uploads/2026/08/naturadala-sloik.webp" alt="Koncentrat kolagenowy Naturadała w słoiku 320 g">
          </div>
          <div class="product-details">
            <p class="eyebrow">Nasza propozycja</p>
            <h3>Koncentrat<br>kolagenowy</h3>
            <p class="product-description">Wyjątkowy koncentrat kolagenowy w formie żelu. Opakowanie 320 g zawiera dwie porcje dzienne, zalecane do spożycia jako przekąska.</p>
            <ul class="product-facts">
              <li><span>Forma</span><strong>Żel / galareta</strong></li>
              <li><span>Opakowanie</span><strong>320 g · 2 porcje</strong></li>
              <li><span>Warunki hurtowe</span><strong>Po kontakcie z zespołem</strong></li>
            </ul>
            <div class="product-actions">
              <a class="button button-dark" href="<?php echo e(route('products.show', 'koncentrat-kolagenowy')); ?>">Szczegóły produktu <span aria-hidden="true">↗</span></a>
              <button class="button button-dark add-to-cart" type="button" data-product="Koncentrat kolagenowy Naturadała · 320 g">
                Dodaj do zapytania <span aria-hidden="true">+</span>
              </button>
              <a class="text-link" href="https://naturadala.pl/" target="_blank" rel="noreferrer">Informacje o produkcie <span aria-hidden="true">↗</span></a>
            </div>
            <p class="product-note">Cennik partnerski i dostępność potwierdzamy indywidualnie.</p>
          </div>
        </article>
      </section>

      <section class="broth-showcase" id="bulion" aria-labelledby="broth-title">
        <div class="section-heading">
          <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Nowa linia</p>
            <h2 id="broth-title">Bulion kolagenowy<br><em>w trzech smakach.</em></h2>
          </div>
          <a class="button button-outline" href="<?php echo e(route('products.index')); ?>">Zobacz całą ofertę <span aria-hidden="true">↗</span></a>
        </div>
        <div class="broth-grid">
          <a class="broth-card broth-beef" href="<?php echo e(route('products.show', 'bulion-wolowo-cielecy')); ?>">
            <img src="<?php echo e(asset('images/products/bulion-wolowo-cielecy.png')); ?>" alt="Bulion kolagenowy wołowo-cielęcy Naturadała, słoiki 400 ml i 250 ml" loading="lazy">
            <span class="broth-label">Wołowo-cielęcy <span aria-hidden="true">↗</span></span>
          </a>
          <a class="broth-card broth-omega" href="<?php echo e(route('products.show', 'bulion-omega-3')); ?>">
            <img src="<?php echo e(asset('images/products/bulion-omega-3.png')); ?>" alt="Bulion kolagenowy z Omega 3 Naturadała, słoiki 400 ml i 250 ml" loading="lazy">
            <span class="broth-label">Z Omega 3 <span aria-hidden="true">↗</span></span>
          </a>
          <a class="broth-card broth-poultry" href="<?php echo e(route('products.show', 'bulion-drobiowo-warzywny')); ?>">
            <img src="<?php echo e(asset('images/products/bulion-drobiowo-warzywny.png')); ?>" alt="Bulion kolagenowy drobiowo-warzywny Naturadała, słoiki 400 ml i 250 ml" loading="lazy">
            <span class="broth-label">Drobiowo-warzywny <span aria-hidden="true">↗</span></span>
          </a>
        </div>
      </section>

      <section class="story-section" id="o-nas">
        <div class="story-image">
          <img src="https://naturadala.pl/wp-content/uploads/2026/03/Honorata_naturadala.jpg" alt="Przedstawicielka marki Naturadała">
          <span class="image-caption">Tworzymy z myślą o naturze i codzienności.</span>
        </div>
        <div class="story-copy">
          <p class="eyebrow"><span class="eyebrow-line"></span> O Naturadale</p>
          <h2>Codzienne wsparcie,<br><em>tak jak natura dała.</em></h2>
          <p>Naturadała powstała z potrzeby połączenia nowoczesnej suplementacji z poszanowaniem naturalnego rytmu organizmu. Wierzymy w uważne podejście, prostotę i rozwiązania, które dobrze wpisują się w codzienne życie.</p>
          <a class="text-link" href="https://naturadala.pl/" target="_blank" rel="noreferrer">Odwiedź stronę Naturadała <span aria-hidden="true">↗</span></a>
        </div>
      </section>

      <section class="steps-section">
        <div class="section-heading">
          <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Prosto i po partnersku</p>
            <h2>Jak zacząć<br><em>współpracę?</em></h2>
          </div>
          <a class="button button-outline" href="#kontakt">Porozmawiajmy <span aria-hidden="true">↗</span></a>
        </div>
        <div class="steps-grid">
          <article class="step-card">
            <span>01</span>
            <h3>Opowiedz nam o swoim miejscu</h3>
            <p>Napisz, czym zajmuje się Twoja firma i jakiej współpracy szukasz.</p>
          </article>
          <article class="step-card">
            <span>02</span>
            <h3>Porozmawiajmy o możliwościach</h3>
            <p>Wspólnie omówimy produkt, dostępność i warunki partnerskie.</p>
          </article>
          <article class="step-card">
            <span>03</span>
            <h3>Dobierzmy dobry początek</h3>
            <p>Ustalimy szczegóły zamówienia i sposób dostawy.</p>
          </article>
        </div>
      </section>

      <section class="faq-section" id="faq">
        <div class="section-heading">
          <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Najczęstsze pytania</p>
            <h2>Odpowiedzi,<br><em>na ważne kwestie.</em></h2>
          </div>
        </div>
        <div class="faq-list">
          <article class="faq-item is-open">
            <button class="faq-question" type="button" aria-expanded="true">
              <span>Jak wygląda współpraca hurtowa?</span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="faq-answer">
              <p>Na start wystarczy, że rozepniesz z nami kontakt. Omawiamy produkt, oczekiwania co do partnerstwa i dobieramy warunki, które odpowiadają Twojemu modelowi sprzedaży.</p>
            </div>
          </article>
          <article class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              <span>Czy produkt jest dostępny do sprzedaży w sieci?</span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="faq-answer">
              <p>Tak. Produkt jest przygotowany z myślą o partnerach, którzy chcą wprowadzić do oferty naturalne rozwiązanie o wyrazistej, nowoczesnej komunikacji i prostym składzie.</p>
            </div>
          </article>
          <article class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              <span>Czy cennik jest indywidualny?</span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="faq-answer">
              <p>Tak. Warunki partnerskie i dostępność są indywidualnie dopasowane do formatu sprzedaży, wolumenu i sposobu współpracy z konkretnym partnerem.</p>
            </div>
          </article>
          <article class="faq-item">
            <button class="faq-question" type="button" aria-expanded="false">
              <span>Czy mogę wysłać zapytanie bez zobowiązań?</span>
              <span class="faq-icon" aria-hidden="true">+</span>
            </button>
            <div class="faq-answer">
              <p>Tak. Wysyłając zapytanie o współpracę, nie wchodzisz w żadne zobowiązania. Wystarczy, że opiszesz swoje potrzeby i od razu prześlemy odpowiedź.</p>
            </div>
          </article>
        </div>
      </section>

      <section class="contact-section" id="kontakt">
        <div class="contact-mark" aria-hidden="true">✳</div>
        <p class="eyebrow">Porozmawiajmy</p>
        <h2>Współpraca zaczyna się<br>od <em>dobrego kontaktu.</em></h2>
        <p>Chętnie odpowiemy na pytania o produkt i możliwości współpracy.</p>
        <a class="button button-light" href="<?php echo e(route('contact')); ?>">Wyślij zapytanie <span aria-hidden="true">↗</span></a>
        <a class="contact-email" href="mailto:kontakt@naturadala.pl">kontakt@naturadala.pl</a>
      </section>
    </main>

    <?php echo $__env->make('shared.newsletter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <footer class="site-footer">
      <a class="footer-brand" href="<?php echo e(route('home')); ?>" aria-label="Wróć na górę">
        <img src="https://naturadala.pl/wp-content/uploads/2026/02/Logo_NaturaDala.png" alt="Naturadała">
      </a>
      <p>Codzienne wsparcie organizmu<br>tak jak natura dała.</p>
      <nav aria-label="Nawigacja w stopce">
        <a href="<?php echo e(route('products.index')); ?>">Produkty</a>
        <a href="#wspolpraca">Współpraca</a>
        <a href="#o-nas">O nas</a>
        <a href="#kontakt">Kontakt</a>
      </nav>
      <span class="copyright">© <span id="current-year">2026</span> Naturadała <button class="cookie-settings-link" type="button" data-cookie-settings>Ustawienia cookies</button></span>
    </footer>
    <?php echo $__env->make('shared.cookie-consent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('shared.basket-panel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  </body>
</html>
<?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/storefront.blade.php ENDPATH**/ ?>