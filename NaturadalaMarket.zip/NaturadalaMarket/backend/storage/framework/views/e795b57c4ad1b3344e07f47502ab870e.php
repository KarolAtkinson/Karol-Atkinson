

<?php $__env->startSection('title', 'Potwierdź adres e-mail'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Jeszcze<br><em>jeden krok.</em></h1>
    <p class="auth-description">Wysłaliśmy wiadomość z linkiem weryfikacyjnym na adres <strong><?php echo e(auth()->user()->email); ?></strong>. Otwórz link, aby potwierdzić adres i uzyskać dostęp do konta.</p>
    <?php if(session('status') === 'verification-link-sent'): ?>
        <p class="status-message">Wysłaliśmy nowy link weryfikacyjny.</p>
    <?php endif; ?>
    <?php if(session('status') === 'email-change-verification-sent'): ?>
        <p class="status-message">Wysłaliśmy link weryfikacyjny na nowy adres e-mail. Potwierdź go, aby ponownie uzyskać dostęp do konta.</p>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('verification.send')); ?>">
        <?php echo csrf_field(); ?>
        <button class="button button-dark auth-submit" type="submit">Wyślij link ponownie <span aria-hidden="true">↗</span></button>
    </form>
    <form class="logout-form" method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="text-link" type="submit">Wyloguj się</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>