

<?php $__env->startSection('title', 'Zaloguj się'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="auth-title">Miło Cię<br><em>widzieć.</em></h1>
    <p class="auth-description">Zaloguj się do swojego konta Naturadała.</p>
    <?php if(session('status') === 'passwords.sent'): ?>
        <p class="status-message">Jeśli konto istnieje, wysłaliśmy wiadomość z dalszymi instrukcjami.</p>
    <?php elseif(session('status')): ?>
        <p class="status-message"><?php echo e(session('status')); ?></p>
    <?php endif; ?>
    <form class="auth-form" method="POST" action="<?php echo e(route('login.store')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">Adres e-mail</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="password">Hasło</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="checkbox-label">
            <input name="remember" type="checkbox" value="1">
            <span>Nie wylogowuj mnie</span>
        </label>
        <button class="button button-dark auth-submit" type="submit">Zaloguj się <span aria-hidden="true">↗</span></button>
    </form>
    <div class="auth-links">
        <a href="<?php echo e(route('password.request')); ?>">Nie pamiętasz hasła?</a>
        <a href="<?php echo e(route('register')); ?>">Załóż konto</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>