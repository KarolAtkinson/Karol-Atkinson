

<?php $__env->startSection('title', 'Wypisz się z newslettera'); ?>

<?php $__env->startSection('content'); ?>
    <p class="eyebrow"><span class="eyebrow-line"></span> Newsletter</p>
    <h1 class="auth-title">Wypisz się<br><em>z newslettera.</em></h1>
    <p class="auth-description">Czy na pewno chcesz przestać otrzymywać wiadomości o nowych produktach? Utracisz też zniżkę dla subskrybentów.</p>
    <form class="auth-form" method="POST" action="<?php echo e(request()->fullUrl()); ?>">
        <?php echo csrf_field(); ?>
        <button class="button button-dark auth-submit" type="submit">Tak, wypisz mnie</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/subscription/unsubscribe.blade.php ENDPATH**/ ?>