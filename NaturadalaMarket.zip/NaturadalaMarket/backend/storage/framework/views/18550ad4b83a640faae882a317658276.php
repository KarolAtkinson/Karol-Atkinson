

<?php $__env->startSection('title', 'Zarządzanie katalogiem'); ?>

<?php $__env->startSection('content'); ?>
    <div class="admin-header-row">
        <div>
            <p class="eyebrow"><span class="eyebrow-line"></span> Administracja</p>
            <h1 class="auth-title">Katalog<br><em>produktów.</em></h1>
        </div>
        <a class="button button-dark" href="<?php echo e(route('admin.products.create')); ?>">Dodaj produkt</a>
    </div>

    <?php if(session('status') === 'product-saved'): ?>
        <p class="status-message">Zmiany katalogu zostały zapisane.</p>
    <?php elseif(session('status') === 'product-deleted'): ?>
        <p class="status-message">Produkt został usunięty.</p>
    <?php elseif(session('status') === 'product-in-use'): ?>
        <p class="status-message" role="alert">Produkt znajduje się w koszykach lub na listach życzeń. Dezaktywuj go zamiast usuwać, aby zachować zapisane pozycje klientów.</p>
    <?php endif; ?>

    <form class="inquiry-filters" method="GET" action="<?php echo e(route('admin.products.index')); ?>">
        <label>
            <span class="sr-only">Szukaj produktów</span>
            <input type="search" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" maxlength="120" placeholder="Szukaj nazwy, SKU lub sluga">
        </label>
        <label>
            <span class="sr-only">Filtruj według widoczności</span>
            <select name="active">
                <option value="">Wszystkie produkty</option>
                <option value="1" <?php if(($filters['active'] ?? '') === '1'): echo 'selected'; endif; ?>>Aktywne</option>
                <option value="0" <?php if(($filters['active'] ?? '') === '0'): echo 'selected'; endif; ?>>Nieaktywne</option>
            </select>
        </label>
        <button class="button button-outline button-small" type="submit">Filtruj</button>
        <?php if(($filters['q'] ?? '') !== '' || ($filters['active'] ?? '') !== ''): ?>
            <a class="text-link" href="<?php echo e(route('admin.products.index')); ?>">Wyczyść</a>
        <?php endif; ?>
    </form>

    <p class="catalogue-results" role="status">Wyświetlono <?php echo e($products->firstItem() ?? 0); ?>–<?php echo e($products->lastItem() ?? 0); ?> z <?php echo e($products->total()); ?> produktów</p>

    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Produkt</th>
                    <th>Aktywny</th>
                    <th>Hurtowe</th>
                    <th>Cena</th>
                    <th>Akcje</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <strong><?php echo e($product->name); ?></strong><br>
                            <span><?php echo e($product->sku); ?></span>
                        </td>
                        <td><?php echo e($product->active ? 'Tak' : 'Nie'); ?></td>
                        <td><?php echo e($product->wholesalePrices->count()); ?></td>
                        <td><?php echo e($product->retail_price !== null ? number_format((float) $product->retail_price, 2, ',', ' ') . ' zł' : '—'); ?></td>
                        <td class="admin-actions">
                            <a class="button button-outline" href="<?php echo e(route('admin.products.edit', $product)); ?>">Edytuj</a>
                            <?php if($product->basket_items_count === 0 && $product->wishlist_items_count === 0): ?>
                                <form method="POST" action="<?php echo e(route('admin.products.destroy', $product)); ?>" onsubmit="return confirm('Trwale usunąć produkt z katalogu?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="button button-danger" type="submit">Usuń</button>
                                </form>
                            <?php else: ?>
                                <span class="field-error">Zapisany przez klientów — dezaktywuj zamiast usuwać</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">Nie znaleziono produktów spełniających kryteria.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\karol\OneDrive\Documents\GitHub\NaturadalaMarket\backend\resources\views/admin/products/index.blade.php ENDPATH**/ ?>