<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        Product::query()->firstOrCreate(
            ['sku' => 'NAT-COLLAGEN-320'],
            [
                'slug' => 'koncentrat-kolagenowy',
                'name' => 'Koncentrat kolagenowy Naturadała',
                'short_description' => 'Koncentrat kolagenowy w formie żelu / galarety, przygotowywany w niskiej temperaturze.',
                'description' => 'Naturadała to wyjątkowy koncentrat kolagenowy w formie żelu / galarety. Produkt powstaje w procesie wolnego warzenia w niskiej temperaturze. Opakowanie zawiera dwie porcje dzienne; nie należy doprowadzać produktu do wrzenia.',
                'size_label' => '320 g · 2 porcje',
                'image_url' => 'https://naturadala.pl/wp-content/uploads/2026/08/naturadala-sloik.webp',
                'retail_price' => 21.99,
                'stock_quantity' => null,
                'minimum_order_quantity' => 1,
                'active' => true,
                'sort_order' => 1,
            ]
        );

        $broths = [
            ['NAT-BROTH-BEEF-250', 'bulion-wolowo-cielecy', 'Bulion kolagenowy wołowo-cielęcy Naturadała', 'Bogaty smak i naturalny kolagen. Wołowo-cielęcy bulion kolagenowy w formie galarety.', 'Wołowo-cielęcy bulion kolagenowy w formie galarety, suplement diety. Bogaty smak i naturalny kolagen: naturalny kolagen, wsparcie mięśni, zdrowe kości. Dostępne opakowania 250 ml i 400 ml.', '/images/products/bulion-wolowo-cielecy.png', 2],
            ['NAT-BROTH-OMEGA3-250', 'bulion-omega-3', 'Bulion kolagenowy z Omega 3 Naturadała', 'Kolagen i Omega 3 w naturalnej formie, w formie galarety.', 'Bulion kolagenowy z Omega 3 w formie galarety, suplement diety. Kolagen i Omega 3 w naturalnej formie: prawidłowa praca mózgu, zdrowe serce, wsparcie układu krążenia. Dostępne opakowania 250 ml i 400 ml.', '/images/products/bulion-omega-3.png', 3],
            ['NAT-BROTH-POULTRY-250', 'bulion-drobiowo-warzywny', 'Bulion kolagenowy drobiowo-warzywny Naturadała', 'Naturalne wsparcie dla stawów, skóry i odporności, w formie galarety.', 'Drobiowo-warzywny bulion kolagenowy w formie galarety, suplement diety. Naturalne wsparcie dla stawów, skóry i odporności: wsparcie stawów, piękna skóra, silna odporność. Dostępne opakowania 250 ml i 400 ml.', '/images/products/bulion-drobiowo-warzywny.png', 4],
        ];

        foreach ($broths as [$sku, $slug, $name, $short, $description, $image, $order]) {
            Product::query()->firstOrCreate(
                ['sku' => $sku],
                [
                    'slug' => $slug,
                    'name' => $name,
                    'short_description' => $short,
                    'description' => $description,
                    'size_label' => '250 ml · galareta',
                    'image_url' => $image,
                    'retail_price' => 21.99,
                    'stock_quantity' => null,
                    'minimum_order_quantity' => 1,
                    'active' => true,
                    'sort_order' => $order,
                    'announced_at' => now(),
                ]
            );
        }
    }
}
