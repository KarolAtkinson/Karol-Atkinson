<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LanguageController extends Controller
{
    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'locale' => ['required', Rule::in(['pl', 'en'])],
        ]);

        $request->session()->put('locale', $validated['locale']);

        $previousUrl = url()->previous();
        $previousHost = parse_url($previousUrl, PHP_URL_HOST);

        if (is_string($previousHost) && strcasecmp($previousHost, $request->getHost()) === 0) {
            return redirect()->to($previousUrl);
        }

        return redirect()->route('home');
    }
}
