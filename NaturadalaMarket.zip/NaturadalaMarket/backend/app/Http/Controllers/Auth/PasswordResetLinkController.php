<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\View\View;

class PasswordResetLinkController extends Controller
{
    public function create(): View
    {
        return view('auth.forgot-password');
    }

    public function store(Request $request): RedirectResponse
    {
        $request->merge([
            'email' => mb_strtolower(trim((string) $request->input('email'))),
        ]);

        $request->validate(['email' => ['required', 'email:rfc']]);

        $email = $request->string('email')->toString();
        $user = User::query()->where('email', $email)->first();

        if ($user?->status === 'active') {
            Password::sendResetLink(['email' => $email]);
        }

        return back()->with('status', 'password-link-requested');
    }
}
