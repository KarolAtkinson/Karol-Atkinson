<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LanguageSwitchTest extends TestCase
{
    use RefreshDatabase;

    public function test_language_selection_persists_across_storefront_and_auth_pages(): void
    {
        $this->get(route('home'))
            ->assertOk()
            ->assertSee('🇬🇧');

        $this->post(route('language.update'), ['locale' => 'en'])
            ->assertRedirect(route('home'))
            ->assertSessionHas('locale', 'en');

        $this->get(route('home'))
            ->assertOk()
            ->assertSee('<html lang="en">', false)
            ->assertSee('/en-translations.js')
            ->assertSee('🇵🇱');

        $this->get(route('login'))
            ->assertOk()
            ->assertSee('<html lang="en">', false)
            ->assertSee('/en-translations.js');

        $this->post(route('language.update'), ['locale' => 'pl'])
            ->assertRedirect(route('login'))
            ->assertSessionHas('locale', 'pl');

        $this->get(route('products.index'))
            ->assertOk()
            ->assertSee('<html lang="pl">', false)
            ->assertSee('🇬🇧');
    }

    public function test_only_supported_languages_can_be_selected(): void
    {
        $this->from(route('home'))
            ->post(route('language.update'), ['locale' => 'fr'])
            ->assertSessionHasErrors('locale');
    }
}
