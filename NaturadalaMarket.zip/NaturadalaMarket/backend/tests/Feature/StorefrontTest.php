<?php

namespace Tests\Feature;

use Tests\TestCase;

class StorefrontTest extends TestCase
{
    public function test_the_homepage_renders_the_marketplace_storefront_and_assets(): void
    {
        $this->get('/')
            ->assertOk()
            ->assertSee('Oferta hurtowa | Naturadała')
            ->assertSee('Naturalnie')
            ->assertSee('/styles.css')
            ->assertSee('/app.js');
    }

    public function test_announcement_messages_come_from_config_sorted_alphabetically(): void
    {
        config()->set('announcements.messages', [
            ['text' => 'Zebra message'],
            ['text' => 'Łódź message'],
            ['text' => 'Alpha message'],
        ]);

        $this->get('/')
            ->assertOk()
            ->assertSeeInOrder(['Alpha message', 'Łódź message', 'Zebra message'])
            ->assertSee('data-interval="20000"', false);
    }
}
