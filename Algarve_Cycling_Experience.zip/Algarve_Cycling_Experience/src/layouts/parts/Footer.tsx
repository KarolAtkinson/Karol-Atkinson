import { Link, useParams } from "react-router";
import { useTranslation } from 'react-i18next';
export default function Footer() {
  const currentYear = new Date().getFullYear();
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  const {
    t
  } = useTranslation();
  const navItems = [{
    href: `/${lang}/tours`,
    label: t('nav.tours')
  }, {
    href: `/${lang}/accommodation`,
    label: t('nav.accommodation')
  }, {
    href: `/${lang}/about`,
    label: t('nav.about')
  }, {
    href: `/${lang}/rent-a-bike`,
    label: t('rent_bike.nav_label')
  }, {
    href: `/${lang}/contact`,
    label: t('nav.contact')
  }];
  return <footer className="bg-foreground text-background">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link to={`/${lang}`} className="inline-block mb-5">
              <img src="/airo-assets/images/logo/horizontal" alt="Algarve Cycling Experience" className="h-10 w-auto object-contain shrink-0 brightness-0 invert" />
              
            </Link>
            <p className="text-background/70 text-sm leading-relaxed max-w-xs mb-6">{t('footer.description')}</p>
            {/* Social Icons */}
            <div className="flex items-center gap-4">
              <a href="https://instagram.com/algarvecyclingexperience" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="w-10 h-10 rounded-full border border-background/20 flex items-center justify-center hover:bg-primary hover:border-primary transition-all duration-200">
                
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <circle cx="12" cy="12" r="4" />
                  <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
                </svg>
              </a>
              <a href="mailto:hello@algarvecycling.com" aria-label="Email" className="w-10 h-10 rounded-full border border-background/20 flex items-center justify-center hover:bg-primary hover:border-primary transition-all duration-200">
                
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-background font-semibold text-sm uppercase tracking-widest mb-5 opacity-50">
              {t('footer.explore')}
            </h3>
            <nav aria-label="Footer navigation" className="flex flex-col gap-3">
              {navItems.map(item => <Link key={item.href} to={item.href} className="text-sm text-background/70 hover:text-primary transition-colors">
                
                  {item.label}
                </Link>)}
            </nav>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-background font-semibold text-sm uppercase tracking-widest mb-5 opacity-50">
              {t('footer.contact')}
            </h3>
            <div className="flex flex-col gap-3 text-sm text-background/70">
              <p>{t('footer.location')}</p>
              <a href="mailto:hello@algarvecycling.com" className="hover:text-primary transition-colors">info@algarvecycling.com

              </a>
              <a href="tel:+351911826188" className="hover:text-primary transition-colors">+351 911 826 188</a>
              <a href="tel:+48602634209" className="hover:text-primary transition-colors">+48 602 634 209

              </a>
              <p className="mt-2 whitespace-pre-line text-background/50 text-xs leading-relaxed">{t('footer.availability')}</p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-background/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-background/40 text-xs">
            © {currentYear} Algarve Cycling Experience. {t('footer.copyright')}
          </p>
          <div className="flex gap-6">
            <Link to={`/${lang}/privacy`} className="text-xs text-background/40 hover:text-background/70 transition-colors">
              {t('footer.privacy')}
            </Link>
            <Link to={`/${lang}/terms`} className="text-xs text-background/40 hover:text-background/70 transition-colors">
              {t('footer.terms')}
            </Link>
          </div>
        </div>
      </div>
    </footer>;
}
