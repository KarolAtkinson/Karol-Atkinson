import { Link, useLocation, useParams } from "react-router";
import { Menu, X, Globe } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { supportedLanguages, getLanguage } from '@/lib/i18n/config';
export default function Header() {
  const location = useLocation();
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  const {
    t,
    i18n
  } = useTranslation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Detect current language direction
  const currentLang = getLanguage(lang);
  const isRtl = currentLang?.dir === 'rtl';
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll, {
      passive: true
    });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  const navItems = [{
    href: `/${lang}/about`,
    label: t('nav.about')
  }, {
    href: `/${lang}/cycling-camp`,
    label: t('cycling_camp.nav_label')
  }, {
    href: `/${lang}/ironman-training`,
    label: t('ironman.nav_label')
  }, {
    href: `/${lang}/tours`,
    label: t('nav.tours')
  }, {
    href: `/${lang}/accommodation`,
    label: t('nav.accommodation')
  },
  { href: `/${lang}/rent-a-bike`, label: t('rent_bike.nav_label') }, {
    href: `/${lang}/contact`,
    label: t('nav.contact')
  }];
  const handleLangSwitch = (code: string) => {
    const currentPath = location.pathname;
    const newPath = currentPath.replace(`/${lang}`, `/${code}`);
    i18n.changeLanguage(code);
    const newLang = getLanguage(code);
    if (newLang) {
      document.documentElement.dir = newLang.dir;
      document.documentElement.lang = code;
    }
    window.location.href = newPath;
  };
  const isActive = (href: string) => location.pathname === href;
  return <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-background/95 backdrop-blur-md shadow-sm border-b border-border' : 'bg-transparent border-b border-transparent'}`}>
      <div className="container mx-auto px-6">
        <div className={`flex h-24 items-center justify-between ${isRtl ? 'flex-row-reverse' : ''}`}>
          {/* Logo */}
          <Link to={`/${lang}`} className="flex items-center shrink-0">
            <img src="/airo-assets/images/logo/horizontal/dark" alt="Algarve Cycling Portugal" className="h-auto max-h-10 md:max-h-12 w-auto max-w-[200px] object-contain shrink-0" />
          </Link>

          {/* Desktop Nav */}
          <nav aria-label="Main navigation" className={`hidden md:flex items-center gap-8 ${isRtl ? 'flex-row-reverse' : ''}`}>
            {navItems.map(item => <Link key={item.href} to={item.href} className={`relative text-sm font-medium tracking-wide transition-colors group ${isActive(item.href) ? 'text-[#F5C87A]' : scrolled ? 'text-foreground/80 hover:text-foreground' : 'text-white/80 hover:text-white'}`}>
                {item.label}
                <span className={`absolute -bottom-0.5 h-px bg-primary transition-all duration-300 ${isRtl ? 'right-0' : 'left-0'} ${isActive(item.href) ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </Link>)}
          </nav>

          {/* CTA + Lang + Mobile Toggle */}
          <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            {/* Language switcher */}
            <div className="hidden md:flex items-center gap-1">
              <Globe size={14} className={scrolled ? 'text-foreground/60' : 'text-white/60'} />
              {supportedLanguages.map((l, i) => <span key={l.code} className="flex items-center">
                  {i > 0 && <span className={`mx-1 text-xs ${scrolled ? 'text-foreground/30' : 'text-white/30'}`}>|</span>}
                  <button onClick={() => handleLangSwitch(l.code)} className={`text-xs font-semibold tracking-wide transition-colors ${lang === l.code ? scrolled ? 'text-foreground' : 'text-white' : scrolled ? 'text-foreground/50 hover:text-foreground/80' : 'text-white/50 hover:text-white/80'}`}>
                    {l.code.toUpperCase()}
                  </button>
                </span>)}
            </div>

            <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className={`md:hidden p-2 rounded-md transition-colors ${scrolled ? 'text-foreground hover:bg-foreground/10' : 'text-white hover:bg-white/10'}`} aria-label="Toggle menu">
              {isMobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && <div className="md:hidden border-t border-white/10 py-4">
            <nav aria-label="Mobile navigation" className={`flex flex-col gap-1 ${isRtl ? 'items-end text-right' : ''}`}>
              {navItems.map(item => <Link key={item.href} to={item.href} className={`text-sm font-medium transition-colors py-3 px-2 rounded-md hover:bg-white/10 w-full ${isActive(item.href) ? 'text-[#C8622A]' : 'text-white/80 hover:text-white'} ${isRtl ? 'text-right' : ''}`} onClick={() => setIsMobileMenuOpen(false)}>
                  {item.label}
                </Link>)}
              <Link to={`/${lang}/camp`} className="mt-3 inline-flex items-center justify-center px-5 py-3 bg-primary text-white text-sm font-semibold rounded-full hover:bg-primary/90 transition-colors" onClick={() => setIsMobileMenuOpen(false)}>
                {t('nav.bookNow')}
              </Link>
              {/* Mobile lang switcher */}
              <div className={`flex items-center gap-3 mt-4 px-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Globe size={14} className="text-white/50" />
                {supportedLanguages.map(l => <button key={l.code} onClick={() => handleLangSwitch(l.code)} className={`text-sm font-semibold ${lang === l.code ? 'text-white' : 'text-white/40 hover:text-white/70'}`}>
                    {l.name}
                  </button>)}
              </div>
            </nav>
          </div>}
      </div>
    </header>;
}
