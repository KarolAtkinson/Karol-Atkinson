import { RouteObject, Navigate, Outlet } from "react-router";
import { lazy } from 'react';
import HomePage from './pages/index';
import ToursPage from './pages/tours';
import AboutPage from './pages/about';
import AccommodationPage from './pages/accommodation';
import ContactPage from './pages/contact';
import IronmanTrainingPage from './pages/ironman-training';
import CampPage from './pages/camp';
import CyclingCampPage from './pages/cycling-camp';
import CartPage from './pages/cart';
import RentABikePage from './pages/rent-a-bike';
import RentABikeDetailPage from './pages/rent-a-bike-detail';
import CheckoutSuccess from './pages/checkout/success';
import CheckoutCancel from './pages/checkout/cancel';
import PrivacyPage from './pages/privacy';
import TermsPage from './pages/terms';
import LanguageWrapper from './components/LanguageWrapper';
import ProdNotFoundPage from './pages/_404';
import { defaultLanguage } from './lib/i18n/config';
const NotFoundPage = ProdNotFoundPage;
export const routes: RouteObject[] = [{
  path: '/',
  element: <Navigate to={`/${defaultLanguage}`} replace />
}, {
  path: '/:lang',
  element: <LanguageWrapper>
        <Outlet />
      </LanguageWrapper>,
  children: [{
    index: true,
    element: <HomePage />
  }, {
    path: 'tours',
    element: <ToursPage />
  }, {
    path: 'about',
    element: <AboutPage />
  }, {
    path: 'accommodation',
    element: <AccommodationPage />
  },
  { path: 'rent-a-bike', element: <RentABikePage /> },
  { path: 'rent-a-bike/:bikeId', element: <RentABikeDetailPage /> },
  {
    path: 'contact',
    element: <ContactPage />
  }, {
    path: 'ironman-training',
    element: <IronmanTrainingPage />
  }, {
    path: 'camp',
    element: <CampPage />
  }, {
    path: 'cycling-camp',
    element: <CyclingCampPage />
  }, {
    path: 'cart',
    element: <CartPage />
  }, {
    path: 'checkout/success',
    element: <CheckoutSuccess />
  }, {
    path: 'checkout/cancel',
    element: <CheckoutCancel />
  }, {
    path: 'privacy',
    element: <PrivacyPage />
  }, {
    path: 'terms',
    element: <TermsPage />
  }]
}, {
  path: '*',
  element: <NotFoundPage />
}];
export type Path = '/' | '/tours' | '/about' | '/accommodation';
export type Params = Record<string, string | undefined>;
