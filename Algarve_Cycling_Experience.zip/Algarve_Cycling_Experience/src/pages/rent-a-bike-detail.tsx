import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams, Navigate } from 'react-router';
import { Bike, ChevronLeft, CheckCircle2, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { rent_a_bike } from 'virtual:content';

const site = 'https://algarveexperience.pl';

type BikeRental = {
  id: string;
  image: string;
  available?: number;
  brand: string;
  price_from?: number;
  price_1day?: number;
  price_3days?: number;
  price_7days?: number;
  price_15days?: number;
  name?: string;
  description?: string;
};

const acDescriptions: Record<string, { tagline: string; details: string[] }> = {
  'road-aluminium': {
    tagline: 'Best for riders chasing speed and aerodynamics on fast-paced roads.',
    details: [
      'Lightweight aluminium frame for responsive handling',
      'Shimano groupset for smooth, reliable shifting',
      'Ideal for coastal routes and village roads',
      'Available in multiple frame sizes',
    ],
  },
  'road-carbon': {
    tagline: 'Full-carbon road bike: stiff, fast and responsive for maximum performance.',
    details: [
      'Full-carbon frame — stiff, light and fast',
      'Performance groupset for confident climbing',
      'Ideal for longer rides and demanding routes',
      'Available in multiple frame sizes',
    ],
  },
  gravel: {
    tagline: 'Best for riders seeking a versatile and comfortable gravel bike for mixed terrain.',
    details: [
      'Handles tarmac, gravel tracks and dirt paths',
      'Relaxed geometry for all-day comfort',
      'Wide tyre clearance for varied Algarve terrain',
      'Available in multiple frame sizes',
    ],
  },
  'mtb-hardtail': {
    tagline: 'Best for riders who prefer a fast and stable hardtail for varied terrain.',
    details: [
      'Front suspension fork for trail comfort',
      'Reliable hydraulic disc brakes',
      'Built for Serra de Monchique trails and climbs',
      'Available in multiple frame sizes',
    ],
  },
  'ebike-city': {
    tagline: 'Easy, comfortable electric bike for city and coastal explorations.',
    details: [
      'Pedal-assist motor for effortless riding',
      'Step-through or standard frame options',
      'Ideal for mixed-ability groups and families',
      'Long battery range for full-day rides',
    ],
  },
  'ebike-mountain': {
    tagline: 'Powerful electric mountain bike to take on Algarve climbs with confidence.',
    details: [
      '500W motor for serious off-road power',
      'Full suspension for rough terrain comfort',
      'Ideal for challenging trails and steep climbs',
      'Long-range battery for extended adventures',
    ],
  },
  'trek-di2': {
    tagline: 'Top-of-the-range road bike with Shimano Di2 electronic shifting.',
    details: [
      'Shimano Di2 electronic groupset — precise and effortless',
      'Premium carbon frame for speed and comfort',
      'Ideal for riders who want the very best',
      'Available in multiple frame sizes',
    ],
  },
  'giant-propel-advanced-2': {
    tagline: 'Best for riders chasing speed and aerodynamics. Perfect for fast-paced roads.',
    details: [
      'Advanced composite aero frame',
      'Integrated cockpit for clean aerodynamics',
      'Shimano 105 groupset for reliable performance',
      'Available in multiple frame sizes',
    ],
  },
  'ridley-kanzo-fast-2': {
    tagline: 'Ideal for riders seeking aerodynamic speed on gravel and technically demanding terrain.',
    details: [
      'Race-ready aero gravel geometry',
      'Confident control on fast and technical terrain',
      'Shimano GRX Di2 electronic shifting',
      'Available in multiple frame sizes',
    ],
  },
  'giant-revolt-e-plus': {
    tagline: 'Best for adventurous riders tackling mixed terrain with electric support.',
    details: [
      'SyncDrive Sport motor with Di2 integration',
      'EnergyPak 500Wh battery for long range',
      'Versatile geometry for road and gravel',
      'Available in multiple frame sizes',
    ],
  },
  'mmr-x-beat-00': {
    tagline: 'Explore without limits — electric gravel with the new Mahle X20 system.',
    details: [
      'Mahle X20 lightweight e-system',
      'Minimal, integrated motor design',
      'Ideal for exploring beyond the tarmac',
      'Available in multiple frame sizes',
    ],
  },
  'merida-esilex-400': {
    tagline: 'Best for riders wanting a lightweight e-gravel bike with an extra boost when needed.',
    details: [
      'Lightweight e-gravel design',
      'Shimano GRX groupset',
      'Extra boost for challenging Algarve climbs',
      'Available in multiple frame sizes',
    ],
  },
  'giant-revolt-adv-2': {
    tagline: 'Best for riders seeking a fast, versatile gravel bike with endurance comfort.',
    details: [
      'Advanced composite frame for speed and comfort',
      'Endurance geometry for long days in the saddle',
      'Shimano 105 groupset',
      'Available in multiple frame sizes',
    ],
  },
  'giant-revolt-1': {
    tagline: 'Best for riders seeking a versatile and comfortable gravel bike for mixed terrain.',
    details: [
      'Aluminium frame with carbon fork',
      'Shimano Tiagra groupset',
      'Wide tyre clearance for Algarve backroads',
      'Available in multiple frame sizes',
    ],
  },
  'giant-talon-e-plus-junior': {
    tagline: 'Ideal for young riders aged 8–11 (130–150 cm) who want to explore trails with more confidence.',
    details: [
      'SyncDrive Life motor for smooth electric support',
      'Lightweight junior-specific frame',
      'Hydraulic disc brakes for safe stopping',
      'Perfect for family cycling adventures',
    ],
  },
  'swift-grom-24': {
    tagline: 'Best for young riders aged 9–13 (135–155 cm) ready to take on real trails.',
    details: [
      '24" wheels for confident trail riding',
      'Front suspension fork for trail comfort',
      'Hydraulic disc brakes',
      'Lightweight frame for easy handling',
    ],
  },
  'swift-grom-20': {
    tagline: 'Best for young riders aged 6–9 (120–140 cm) ready to build confidence on real trails.',
    details: [
      '20" wheels for smaller riders',
      'Front suspension for trail comfort',
      'Mechanical disc brakes',
      'Lightweight and easy to control',
    ],
  },
};

export default function RentABikeDetailPage() {
  const { lang = 'en', bikeId } = useParams<{ lang: string; bikeId: string }>();
  const { t } = useTranslation();
  const bikes = rent_a_bike.bikes as BikeRental[];

  const bike = bikes.find((b) => b.id === bikeId);
  if (!bike) return <Navigate to={`/${lang}/rent-a-bike`} replace />;

  const idKey = bike.id === 'road-aluminium' ? 'road_alu' : bike.id.replaceAll('-', '_');
  const bikeName = t(`rent_bike.bikes.${idKey}.name`, { defaultValue: bike.name ?? bike.id });
  const bikeDesc = t(`rent_bike.bikes.${idKey}.description`, { defaultValue: bike.description ?? '' });

  const extra = acDescriptions[bike.id];
  const price = (value?: number) => value === undefined ? t('rent_bike.price_on_request') : `€${value}`;
  const priceDisplay = price(bike.price_from ?? bike.price_1day);

  const url = `${site}/${lang}/rent-a-bike/${bike.id}`;
  const title = `${bikeName} | Rent a Bike | Algarve Cycling Experience`;
  const description = bikeDesc;

  const idx = bikes.findIndex((b) => b.id === bikeId);
  const prevBike = idx > 0 ? bikes[idx - 1] : null;
  const nextBike = idx < bikes.length - 1 ? bikes[idx + 1] : null;
  const prevName = prevBike ? t(`rent_bike.bikes.${prevBike.id === 'road-aluminium' ? 'road_alu' : prevBike.id.replaceAll('-', '_')}.name`, { defaultValue: prevBike.name ?? prevBike.id }) : '';
  const nextName = nextBike ? t(`rent_bike.bikes.${nextBike.id === 'road-aluminium' ? 'road_alu' : nextBike.id.replaceAll('-', '_')}.name`, { defaultValue: nextBike.name ?? nextBike.id }) : '';

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: bikeName,
    description: bikeDesc,
    image: `${site}${bike.image}`,
    brand: { '@type': 'Brand', name: bike.brand },
    offers: {
      '@type': 'Offer',
      priceCurrency: 'EUR',
      price: bike.price_from ?? bike.price_1day ?? 0,
      availability: 'https://schema.org/InStock',
      url,
    },
  };

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:type" content="product" />
        <meta property="og:url" content={url} />
        <meta property="og:image" content={`${site}${bike.image}`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={`${site}${bike.image}`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\\u003c')}</script>
      </Helmet>

      <main>
        <div className="bg-muted border-b border-border">
          <div className="container mx-auto px-6 py-3">
            <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-sm text-muted-foreground">
              <Link to={`/${lang}/rent-a-bike`} className="flex items-center gap-1 hover:text-foreground transition-colors">
                <ChevronLeft size={14} />
                <span>{t('rent_bike.nav_label')}</span>
              </Link>
              <span>/</span>
              <span className="text-foreground font-medium">{bikeName}</span>
            </nav>
          </div>
        </div>

        <section className="bg-background py-12 md:py-20">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-16 items-start">
              <div className="rounded-2xl overflow-hidden bg-muted border border-border">
                <img
                  src={bike.image}
                  alt={bikeName}
                  className="w-full aspect-[4/3] object-contain p-8"
                  loading="eager"
                  fetchPriority="high"
                  width={1200}
                  height={900}
                />
              </div>

              <div>
                <p className="text-sm font-semibold text-primary mb-2">{bike.brand}</p>
                <h1 className="font-heading text-3xl font-bold text-foreground md:text-4xl leading-tight">{bikeName}</h1>

                {extra ? (
                  <p className="mt-4 text-muted-foreground leading-relaxed">{extra.tagline}</p>
                ) : (
                  <p className="mt-4 text-muted-foreground leading-relaxed">{bikeDesc}</p>
                )}

                <div className="mt-6 inline-flex items-baseline gap-2 rounded-xl bg-muted px-5 py-3 border border-border">
                  <span className="text-sm text-muted-foreground">{t('rent_bike.from')}</span>
                  <span className="font-heading text-3xl font-bold text-foreground">{priceDisplay}</span>
                  <span className="text-sm text-muted-foreground">{t('rent_bike.per_day')}</span>
                </div>

                {bike.available !== undefined && (
                  <p className="mt-4 flex items-center gap-2 text-sm font-medium text-foreground">
                    <CheckCircle2 size={16} className="text-primary" />
                    {bike.available} {t('rent_bike.available')}
                  </p>
                )}

                {extra && (
                  <ul className="mt-6 space-y-3">
                    {extra.details.map((detail, i) => (
                      <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                        <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-primary" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                )}

                {(bike.price_1day || bike.price_3days || bike.price_7days || bike.price_15days) && (
                  <div className="mt-8 rounded-xl border border-border overflow-hidden">
                    <table className="w-full text-sm">
                      <thead className="bg-muted">
                        <tr>
                          <th className="px-4 py-3 text-left font-semibold text-foreground">{t('rent_bike.columns.one_day')}</th>
                          <th className="px-4 py-3 text-left font-semibold text-foreground">{t('rent_bike.columns.three_days')}</th>
                          <th className="px-4 py-3 text-left font-semibold text-foreground">{t('rent_bike.columns.seven_days')}</th>
                          <th className="px-4 py-3 text-left font-semibold text-foreground">{t('rent_bike.columns.fifteen_days')}</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-t border-border">
                          <td className="px-4 py-3 text-muted-foreground">{price(bike.price_1day)}</td>
                          <td className="px-4 py-3 text-muted-foreground">{price(bike.price_3days)}</td>
                          <td className="px-4 py-3 text-muted-foreground">{price(bike.price_7days)}</td>
                          <td className="px-4 py-3 text-muted-foreground">{price(bike.price_15days)}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}

                <p className="mt-6 flex items-start gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-primary" />
                  {t('rent_bike.equipment_included')}
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  <Link
                    to={`/${lang}/contact`}
                    className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                  >
                    {t('rent_bike.cta_button')}
                    <ChevronRight size={16} />
                  </Link>
                  <Link
                    to={`/${lang}/rent-a-bike`}
                    className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-muted"
                  >
                    <Bike size={16} />
                    {t('rent_bike.nav_label')}
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {(prevBike || nextBike) && (
          <section className="border-t border-border bg-muted py-8">
            <div className="container mx-auto px-6">
              <div className="flex items-center justify-between gap-4">
                {prevBike ? (
                  <Link
                    to={`/${lang}/rent-a-bike/${prevBike.id}`}
                    className="group flex items-center gap-3 rounded-xl border border-border bg-card px-5 py-4 text-sm transition-shadow hover:shadow-md"
                  >
                    <ChevronLeft size={18} className="shrink-0 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">Previous</p>
                      <p className="font-semibold text-foreground group-hover:text-primary transition-colors">{prevName}</p>
                    </div>
                  </Link>
                ) : <div />}

                {nextBike ? (
                  <Link
                    to={`/${lang}/rent-a-bike/${nextBike.id}`}
                    className="group flex items-center gap-3 rounded-xl border border-border bg-card px-5 py-4 text-sm transition-shadow hover:shadow-md text-right"
                  >
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">Next</p>
                      <p className="font-semibold text-foreground group-hover:text-primary transition-colors">{nextName}</p>
                    </div>
                    <ChevronRight size={18} className="shrink-0 text-primary" />
                  </Link>
                ) : <div />}
              </div>
            </div>
          </section>
        )}
      </main>
    </>
  );
}
