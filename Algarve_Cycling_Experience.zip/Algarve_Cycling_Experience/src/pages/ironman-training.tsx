import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from "react-router";
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { ironman_training } from 'virtual:content';
import { Bike, UtensilsCrossed, MapPin, Star, Users, Clock, TrendingUp, Shield, ChevronRight, Plane, Building2 } from 'lucide-react';
const site = 'https://algarveexperience.pl';
const fadeUp = {
  hidden: {
    opacity: 0,
    y: 28
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: 'easeOut' as const
    }
  }
} as const;
const stagger = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1
    }
  }
} as const;
export default function IronmanTrainingPage() {
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  const {
    t
  } = useTranslation();
  const isRtl = lang === 'ar';
  const url = `${site}/${lang}/ironman-training`;
  const title = lang === 'pl' ? 'Obóz Treningowy IRONMAN 70.3 Vilamoura Portugal 2027 — Algarve Cycling Experience' : lang === 'ar' ? 'معسكر تدريب IRONMAN 70.3 Vilamoura البرتغال 2027 — Algarve Cycling Experience' : 'IRONMAN 70.3 Vilamoura Training Camp Portugal 2027 — Algarve Cycling Experience';
  const description = lang === 'pl' ? '8-dniowy luksusowy obóz treningowy na oficjalnej trasie rowerowej IRONMAN 70.3 Vilamoura w Algarve. Prywatna willa 300m², szef kuchni, certyfikowany trener triathlonu i lokalny przewodnik rowerowy.' : lang === 'ar' ? 'معسكر تدريبي فاخر 8 أيام على مسار الدراجات الرسمي لـ IRONMAN 70.3 Vilamoura في الغارف. فيلا خاصة 300م²، طاهٍ، مدرب ترياثلون معتمد ومرشد دراجات محلي.' : '8-day luxury training camp on the official IRONMAN 70.3 Vilamoura bike course in Algarve. Private 300m² villa, personal chef, certified triathlon coach and local cycling guide.';
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    '@id': `${url}#event`,
    name: title,
    url,
    description,
    sport: 'Triathlon',
    startDate: '2026-11-06',
    endDate: '2026-11-13',
    eventStatus: 'https://schema.org/EventScheduled',
    eventAttendanceMode: 'https://schema.org/OfflineEventAttendanceMode',
    maximumAttendeeCapacity: 8,
    location: {
      '@type': 'Place',
      name: 'Vilamoura, Algarve, Portugal',
      address: {
        '@type': 'PostalAddress',
        addressLocality: 'Vilamoura',
        addressRegion: 'Algarve',
        addressCountry: 'PT'
      }
    },
    organizer: {
      '@id': `${site}/#organization`
    },
    offers: {
      '@type': 'Offer',
      price: '2900',
      priceCurrency: 'EUR',
      availability: 'https://schema.org/LimitedAvailability',
      validFrom: '2026-10-01',
      url,
    },
    image: `${site}/airo-assets/images/pages/ironman/hero`,
    isPartOf: { '@id': `${site}/#website` },
  };
  const days = [{
    num: 1,
    title: t('ironman.programme.day_1_title'),
    desc: t('ironman.programme.day_1_desc'),
    icon: '🏡'
  }, {
    num: 2,
    title: t('ironman.programme.day_2_title'),
    desc: t('ironman.programme.day_2_desc'),
    icon: '🏊'
  }, {
    num: 3,
    title: t('ironman.programme.day_3_title'),
    desc: t('ironman.programme.day_3_desc'),
    icon: '🚴'
  }, {
    num: 4,
    title: t('ironman.programme.day_4_title'),
    desc: t('ironman.programme.day_4_desc'),
    icon: '🌊'
  }, {
    num: 5,
    title: t('ironman.programme.day_5_title'),
    desc: t('ironman.programme.day_5_desc'),
    icon: '🏃'
  }, {
    num: 6,
    title: t('ironman.programme.day_6_title'),
    desc: t('ironman.programme.day_6_desc'),
    icon: '🔄'
  }, {
    num: 7,
    title: t('ironman.programme.day_7_title'),
    desc: t('ironman.programme.day_7_desc'),
    icon: '🏆'
  }, {
    num: 8,
    title: t('ironman.programme.day_8_title'),
    desc: t('ironman.programme.day_8_desc'),
    icon: '✈️'
  }];
  const included = [{
    icon: MapPin,
    title: t('ironman.included.villa_title'),
    desc: t('ironman.included.villa_desc'),
    img: '/airo-assets/images/pages/ironman/villa-pool'
  }, {
    icon: UtensilsCrossed,
    title: t('ironman.included.chef_title'),
    desc: t('ironman.included.chef_desc'),
    img: '/airo-assets/images/pages/ironman/private-chef'
  }, {
    icon: Bike,
    title: t('ironman.included.guide_title'),
    desc: t('ironman.included.guide_desc'),
    img: '/airo-assets/images/pages/ironman/bike-route'
  }, {
    icon: Star,
    title: t('ironman.included.concierge_title'),
    desc: t('ironman.included.concierge_desc'),
    img: '/airo-assets/images/pages/ironman/concierge'
  }, {
    icon: Plane,
    title: t('ironman.included.airport_transfer_title'),
    desc: t('ironman.included.airport_transfer_desc'),
    img: '/airo-assets/images/pages/ironman/airport-transfer'
  }, {
    icon: Star,
    title: t('ironman.included.racesuit_title'),
    desc: t('ironman.included.racesuit_desc'),
    img: '/airo-assets/images/pages/ironman/mbo-triathlon-racesuit'
  }];
  const notIncluded = [{
    icon: TrendingUp,
    title: t('ironman.included.bikes_title'),
    desc: t('ironman.included.bikes_desc'),
    img: '/airo-assets/images/pages/ironman/bikes-available'
  }, {
    icon: Star,
    title: t('ironman.included.yoga_title'),
    desc: t('ironman.included.yoga_desc'),
    img: '/airo-assets/images/pages/ironman/yoga-mobility-stretching'
  }];
  const stats = [{
    label: t('ironman.race_info.stat_1_label'),
    value: t('ironman.race_info.stat_1_value')
  }, {
    label: t('ironman.race_info.stat_2_label'),
    value: t('ironman.race_info.stat_2_value')
  }, {
    label: t('ironman.race_info.stat_3_label'),
    value: t('ironman.race_info.stat_3_value')
  }, {
    label: t('ironman.race_info.stat_4_label'),
    value: t('ironman.race_info.stat_4_value')
  }];
  return <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/ironman/hero`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/ironman/hero`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main dir={isRtl ? 'rtl' : 'ltr'}>

        {/* ── HERO ── */}
        <section className="relative min-h-[90vh] flex items-center overflow-hidden">
          
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/80 pointer-events-none" />

          {/* Red Ironman-style accent bar */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-[#E8621A]" />

          <div className="relative z-10 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
            <motion.div variants={stagger} initial="hidden" animate="visible" className="max-w-3xl">
              <motion.div variants={fadeUp} className="flex items-center gap-3 mb-6">
                <span className="bg-[#E8621A] text-white text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
                  {t('ironman.hero.eyebrow')}
                </span>
              </motion.div>

              <motion.h1 variants={fadeUp} className="text-4xl font-bold text-white font-[var(--font-heading)] leading-tight mb-6">
                {t('ironman.hero.title').split('\n').map((line, index) =>
              <span key={line} className={index === 1 ? 'block text-[1.4625rem]' : 'block'}>
                    {line}
                  </span>
              )}
              </motion.h1>

              <motion.p variants={fadeUp} className="text-2xl text-white/80 max-w-2xl mb-10 leading-relaxed">
                {t('ironman.hero.subtitle')}
              </motion.p>

              <motion.div variants={fadeUp} className="flex flex-wrap items-center gap-4">
                <a href="#included" className="inline-flex items-center gap-2 border-2 border-white/40 hover:border-white text-white font-semibold px-8 py-4 rounded-full transition text-base backdrop-blur-sm">
                  {t('ironman.hero.cta_included')}
                </a>
              </motion.div>
            </motion.div>

            {/* Stats bar */}
            <motion.div variants={fadeUp} initial="hidden" animate="visible" className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-px bg-white/10 rounded-2xl overflow-hidden backdrop-blur-sm border border-white/10">
              {stats.map((s) => <div key={s.label} className="bg-black/30 px-6 py-5 text-center">
                  <p className="text-2xl md:text-3xl font-bold text-[#E8621A] font-[var(--font-heading)]">{s.value}</p>
                  <p className="text-xs text-white/60 mt-1 uppercase tracking-wide">{s.label}</p>
                </div>)}
            </motion.div>
          </div>
        </section>

        {/* ── RACE INFO ── */}
        <section className="py-20 bg-[#1A1A2E] text-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
              once: true
            }}>
                <motion.p variants={fadeUp} className="text-[#E8621A] text-sm font-semibold uppercase tracking-widest mb-3">
                  {t('ironman.race_info.label')}
                </motion.p>
                <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold font-[var(--font-heading)] mb-6">
                  {t('ironman.race_info.title')}
                </motion.h2>
                <motion.p variants={fadeUp} className="text-white/70 text-lg leading-relaxed">
                  {t('ironman.race_info.description')}
                </motion.p>

                {/* Course highlights */}
                <motion.div variants={fadeUp} className="mt-8 space-y-3">
                  {[lang === 'pl' ? 'Portimão → Lagos → Sagres → Monchique → Portimão' : lang === 'ar' ? 'بورتيماو ← لاغوس ← ساغريش ← مونشيك ← بورتيماو' : 'Portimão → Lagos → Sagres → Monchique → Portimão', lang === 'pl' ? 'Kluczowe podjazdy: Serra de Monchique, Caldas de Monchique' : lang === 'ar' ? 'التسلقات الرئيسية: سيرا دي مونشيك، كالداس دي مونشيك' : 'Key climbs: Serra de Monchique, Caldas de Monchique', lang === 'pl' ? 'Ta sama trasa rowerowa, którą pokonują zawodnicy IRONMAN 70.3 Vilamoura' : lang === 'ar' ? 'نفس مسار الدراجات الذي يسلكه متسابقو IRONMAN 70.3 Vilamoura' : 'The same bike course raced by IRONMAN 70.3 Vilamoura athletes'].map((item) => <div key={item} className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full bg-[#E8621A]/20 flex items-center justify-center shrink-0 mt-0.5">
                        <div className="w-2 h-2 rounded-full bg-[#E8621A]" />
                      </div>
                      <span className="text-white/80 text-sm">{item}</span>
                    </div>)}
                </motion.div>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              scale: 0.97
            }} whileInView={{
              opacity: 1,
              scale: 1
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.7,
              ease: 'easeOut' as const
            }} className="relative rounded-2xl overflow-hidden aspect-[4/3]">
                <img src="/airo-assets/images/pages/ironman/bike-route" alt="Ironman Portugal bike course" className="w-full h-full object-cover" loading="lazy" width={900} height={600} />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A2E]/60 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-black/60 backdrop-blur-sm rounded-xl px-4 py-3 border border-white/10">
                    <p className="text-white text-sm font-semibold">
                      {lang === 'pl' ? '🚴 Oficjalna trasa rowerowa triathlonu w Algarve' : lang === 'ar' ? '🚴 مسار الدراجات الرسمي لترياثلون الغارف' : '🚴 Official triathlon bike course in Algarve'}
                    </p>
                    <p className="text-white/60 text-xs mt-0.5">{ironman_training.course.location}</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── 7-DAY PROGRAMME ── */}
        <section id="programme" className="hidden">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
            once: true
          }} className="text-center mb-16">
              <motion.p variants={fadeUp} className="text-primary text-sm font-semibold uppercase tracking-widest mb-3">
                {t('ironman.programme.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-3xl md:text-5xl font-bold text-foreground font-[var(--font-heading)] mb-4">
                {t('ironman.programme.title')}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground text-lg max-w-2xl mx-auto">
                <span>{t('ironman.programme.subtitle').split('(MTrainingLab)')[0]}</span>
                <a href={ironman_training.coach.trainingLabUrl} target="_blank" rel="noopener noreferrer" className="text-primary font-semibold hover:underline">{ironman_training.coach.trainingLabName}</a>
                <span>{t('ironman.programme.subtitle').split('(MTrainingLab)')[1]}</span>
              </motion.p>
            </motion.div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-border hidden sm:block" />

              <div className="space-y-8">
                {days.map((day, i) => <motion.div key={day.num} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{
                once: true
              }} className={`relative flex flex-col sm:flex-row gap-6 ${i % 2 === 0 ? 'sm:flex-row' : 'sm:flex-row-reverse'}`}>
                    {/* Content */}
                    <div className={`flex-1 ${i % 2 === 0 ? 'sm:text-right sm:pr-12' : 'sm:text-left sm:pl-12'}`}>
                      <div className={`bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-md transition ${i % 2 === 0 ? 'sm:ml-auto' : 'sm:mr-auto'} max-w-lg`}>
                        <div className={`flex items-center gap-3 mb-3 ${i % 2 === 0 ? 'sm:flex-row-reverse' : ''}`}>
                          <span className="text-2xl">{day.icon}</span>
                          <span className="text-xs font-bold text-[#E8621A] uppercase tracking-wider">
                            {lang === 'pl' ? `Dzień ${day.num}` : lang === 'ar' ? `اليوم ${day.num}` : `Day ${day.num}`}
                          </span>
                        </div>
                        <h3 className="text-base font-bold text-foreground font-[var(--font-heading)] mb-2">
                          {day.title.replace(/^Day \d+ — |^Dzień \d+ — |^اليوم \d+ — /, '')}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">{day.desc}</p>
                      </div>
                    </div>

                    {/* Center dot */}
                    <div className="hidden sm:flex absolute left-1/2 -translate-x-1/2 top-6 w-10 h-10 rounded-full bg-[#E8621A] text-white font-bold text-sm items-center justify-center z-10 shadow-lg">
                      {day.num}
                    </div>

                    {/* Spacer */}
                    <div className="flex-1" />
                  </motion.div>)}
              </div>
            </div>
          </div>
        </section>

        {/* ── WHAT'S INCLUDED ── */}
        <section id="included" className="py-20 md:py-28 bg-muted/30">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
            once: true
          }} className="mb-6 text-left">
              <motion.h2 variants={fadeUp} className="text-3xl font-bold text-foreground font-[var(--font-heading)] md:text-5xl">
                {t('ironman.included.label')}
              </motion.h2>
              <motion.p variants={fadeUp} className="mt-3 text-sm text-muted-foreground">
                {t('ironman.included.additional_services')}
              </motion.p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {included.map((item, i) => <motion.div key={item.title} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{
              once: true
            }} transition={{
              delay: i * 0.07
            }} className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition group">
                  {item.img && <div className="aspect-[16/9] overflow-hidden">
                      <img src={item.img} alt={item.title} className={`w-full h-full ${item.img === '/airo-assets/images/pages/ironman/bikes-available' ? 'object-contain bg-muted' : 'object-cover group-hover:scale-105'} transition duration-500`} loading="lazy" width={900} height={506} />
                    </div>}
                  <div className="p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-foreground font-[var(--font-heading)] text-base">{item.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>)}
            </div>

            <section className="mt-10" aria-labelledby="not-included-heading">
              <p id="not-included-heading" className="text-lg mb-4 font-semibold text-muted-foreground" style={{ color: "#f5f5f5" }}>
                Not Included
              </p>
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                {notIncluded.map((item, i) => <motion.div key={item.title} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.07 }} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition hover:shadow-md">
                    <div className="aspect-[16/9] overflow-hidden">
                      <img src={item.img} alt={item.title} className={`h-full w-full transition duration-500 ${item.img === '/airo-assets/images/pages/ironman/bikes-available' ? 'bg-muted object-contain' : 'object-cover group-hover:scale-105'}`} loading="lazy" width={900} height={506} />
                    </div>
                    <div className="p-6">
                      <div className="mb-3 flex items-center gap-3">
                        <h3 className="font-[var(--font-heading)] text-base text-foreground">{item.title}</h3>
                      </div>
                      <p className="text-sm leading-relaxed text-muted-foreground">{item.desc}</p>
                    </div>
                  </motion.div>)}
              </div>
            </section>
          </div>
        </section>

        {/* ── COACH ── */}
        <section className="py-20 md:py-28 bg-background">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
            once: true
          }} className="text-center mb-16">
              <motion.p variants={fadeUp} className="text-[#E8621A] text-sm font-semibold uppercase tracking-widest mb-3">
                {lang === 'pl' ? 'Twój trener' : lang === 'ar' ? 'مدربك' : 'Your coach'}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-3xl md:text-5xl font-bold text-foreground font-[var(--font-heading)] mb-4">
                {lang === 'pl' ? 'Trenuj z ekspertem' : lang === 'ar' ? 'تدرب مع خبير' : 'Train with an expert'}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground text-lg max-w-2xl mx-auto">
                {lang === 'pl' ? 'Nasz obóz prowadzi certyfikowany trener triathlonu z wieloletnim doświadczeniem w przygotowaniu zawodników do IRONMAN 70.3 i innych zawodów triathlonowych.' : lang === 'ar' ? 'يقود معسكرنا مدرب ترياثلون معتمد يتمتع بخبرة واسعة في تحضير الرياضيين لسباقات IRONMAN 70.3 وغيرها من سباقات الترياثلون.' : 'Our camp is led by a certified triathlon coach with extensive experience preparing athletes for IRONMAN 70.3 and other triathlon races.'}
              </motion.p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              {/* Photo + credentials */}
              <motion.div initial={{
              opacity: 0,
              x: -24
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.7,
              ease: 'easeOut' as const
            }} className="flex flex-col gap-6">
                {/* CV download */}
                <a href="/data/CV Giacomo Giovenali coach.pdf" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline max-w-sm mx-auto lg:mx-0">
                  <Shield className="w-4 h-4" />
                  {lang === 'pl' ? 'Pobierz CV trenera (PDF)' : lang === 'ar' ? 'تحميل السيرة الذاتية للمدرب (PDF)' : 'Download coach CV (PDF)'}
                </a>
              </motion.div>

              {/* Bio + what you get */}
              <motion.div initial={{
              opacity: 0,
              x: 24
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.7,
              ease: 'easeOut' as const,
              delay: 0.1
            }} className="flex flex-col gap-8">
                {/* Bio */}
                <div>
                  <h3 className="text-2xl font-bold text-foreground font-[var(--font-heading)] mb-4">
                    {lang === 'pl' ? 'Kim jest Giacomo?' : lang === 'ar' ? 'من هو جياكومو؟' : 'Who is Giacomo?'}
                  </h3>
                  <div className="space-y-4 text-muted-foreground leading-relaxed">
                    <p>
                      {lang === 'pl' ? 'Giacomo Giovenali to włoski trener sportów wytrzymałościowych oraz IRONMAN Certified Coach. Posiada dyplom ISEF i tytuł z zakresu nauk o sporcie.' : lang === 'ar' ? 'Giacomo Giovenali مدرب إيطالي لرياضات التحمل ومدرب IRONMAN معتمد. يحمل دبلوم ISEF ودرجة في علوم الرياضة.' : 'Giacomo Giovenali is an Italian endurance coach and an IRONMAN Certified Coach. He holds an ISEF diploma and a degree in Sports Science.'}
                    </p>
                    <p>
                      {lang === 'pl' ? 'Z ponad 30-letnim doświadczeniem w triathlonie Giacomo ukończył ponad 80 zawodów IRONMAN 70.3 i ponad 17 pełnych dystansów IRONMAN. Startował także w pięciu Mistrzostwach Świata IRONMAN 70.3 oraz trzech Mistrzostwach Świata IRONMAN: dwa razy w Konie i raz w Nicei.' : lang === 'ar' ? 'مع أكثر من 30 عاماً من الخبرة في الترياثلون، أكمل Giacomo أكثر من 80 سباق IRONMAN 70.3 وأكثر من 17 سباق IRONMAN كامل المسافة. كما شارك في خمس بطولات عالمية لـ IRONMAN 70.3 وثلاث بطولات عالمية لـ IRONMAN: اثنتان في كونا وواحدة في نيس.' : 'With more than 30 years of experience in triathlon, Giacomo has completed over 80 IRONMAN 70.3 races and more than 17 full-distance IRONMAN events. He has also competed in five IRONMAN 70.3 World Championships and three IRONMAN World Championships: two in Kona and one in Nice.'}
                    </p>
                    <p>
                      <span>{lang === 'pl' ? 'Poprzez ' : lang === 'ar' ? 'من خلال ' : 'Through '}</span><a href={ironman_training.coach.trainingLabUrl} target="_blank" rel="noopener noreferrer" className="text-primary font-semibold hover:underline">{ironman_training.coach.trainingLabName}</a><span>{lang === 'pl' ? ', Giacomo pracuje z zawodnikami na różnych poziomach, łącząc bogate doświadczenie startowe z ustrukturyzowanym treningiem, analizą mocy i tętna, rozwojem siły, regeneracją oraz strategią wyścigową.' : lang === 'ar' ? '، يعمل Giacomo مع رياضيين من مستويات مختلفة، جامعاً بين خبرة السباقات الواسعة والتدريب المنظم وتحليل القوة ومعدل ضربات القلب وتطوير القوة والتعافي واستراتيجية السباق.' : ', Giacomo works with athletes of different levels, combining extensive racing experience with structured training, power and heart-rate analysis, strength development, recovery and race strategy.'}</span>
                    </p>
                  </div>
                </div>

                {/* What you get */}
                <div>
                  <h3 className="text-lg font-bold text-foreground font-[var(--font-heading)] mb-4">
                    {lang === 'pl' ? 'Co otrzymujesz od trenera?' : lang === 'ar' ? 'ماذا تحصل من المدرب؟' : 'What you get from the coach'}
                  </h3>
                  <div className="space-y-3">
                    {(lang === 'pl' ? ['Indywidualna analiza Twoich słabych i mocnych stron przed obozem', 'Codzienne sesje na trasie z informacją zwrotną w czasie rzeczywistym', 'Trening oparty na mocy (power meter) i tętnie', 'Wskazówki dotyczące strategii wyścigu i zarządzania tempem'] : lang === 'ar' ? ['تحليل فردي لنقاط قوتك وضعفك قبل المعسكر', 'جلسات يومية على المسار مع تغذية راجعة فورية', 'تدريب مبني على عداد القوة ومعدل ضربات القلب', 'إرشادات حول استراتيجية السباق وإدارة الوتيرة'] : ['Individual analysis of your strengths and weaknesses before the camp', 'Daily on-course sessions with real-time feedback', 'Power meter and heart-rate based training', 'Race strategy and pacing guidance']).map((item) => <div key={item} className="flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
                          <div className="w-2 h-2 rounded-full bg-primary" />
                        </div>
                        <span className="text-sm text-foreground leading-relaxed">{item}</span>
                      </div>)}
                    <p className="text-sm text-muted-foreground leading-relaxed pt-2">
                      <span>{lang === 'pl' ? 'Spersonalizowane prowadzenie po obozie jest dostępne jako osobna usługa przez ' : lang === 'ar' ? 'التدريب الشخصي بعد المعسكر متاح كخدمة منفصلة عبر ' : 'Personalised coaching after the camp is available as a separate service through '}</span><a href={ironman_training.coach.trainingLabUrl} target="_blank" rel="noopener noreferrer" className="text-primary font-semibold hover:underline">{ironman_training.coach.trainingLabName}</a><span>{lang === 'pl' ? ', z miesięcznymi programami od 350 €.' : lang === 'ar' ? '، مع برامج تدريب شهرية تبدأ من €350.' : ', with monthly coaching programmes starting from €350.'}</span>
                    </p>
                  </div>
                </div>

                {/* For whom */}
                <div className="bg-[#1A1A2E] rounded-2xl p-6">
                  <p className="text-[#E8621A] text-xs font-bold uppercase tracking-widest mb-3">
                    {lang === 'pl' ? 'Dla kogo?' : lang === 'ar' ? 'لمن هذا؟' : 'Who is this for?'}
                  </p>
                  <div className="space-y-2">
                    {(lang === 'pl' ? ['🏁 Przygotowujesz się do pierwszego IRONMAN lub IRONMAN 70.3', '⏱ Chcesz osiągnąć rekord życiowy na dystansie IRONMAN lub IRONMAN 70.3', '🚴 Chcesz opanować oficjalną trasę rowerową IRONMAN Portugal', '🏆 Celujesz w kwalifikację do Mistrzostw Świata IRONMAN lub IRONMAN 70.3', '💪 Szukasz intensywnego, profesjonalnie prowadzonego obozu'] : lang === 'ar' ? ['🏁 تستعد لأول IRONMAN أو IRONMAN 70.3', '⏱ تسعى لتحقيق أفضل رقم شخصي في مسافة IRONMAN أو IRONMAN 70.3', '🚴 تريد إتقان مسار الدراجات الرسمي لـ IRONMAN Portugal', '🏆 تهدف للتأهل إلى بطولة العالم IRONMAN أو IRONMAN 70.3', '💪 تبحث عن معسكر مكثف يديره محترفون'] : ['🏁 Preparing for your first IRONMAN or IRONMAN 70.3', '⏱ Looking to achieve a personal best at IRONMAN or IRONMAN 70.3 distance', '🚴 Wanting to master the official IRONMAN Portugal bike course', '🏆 Aiming to qualify for the IRONMAN or IRONMAN 70.3 World Championship', '💪 Seeking an intensive, professionally coached training camp']).map((item) => <p key={item} className="text-white/80 text-sm">{item}</p>)}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section className="py-20 md:py-28 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
            once: true
          }} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-[#E8621A] text-sm font-semibold uppercase tracking-widest mb-3">
                {t('ironman.pricing.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold text-foreground font-[var(--font-heading)]">
                {t('ironman.pricing.title')}
              </motion.h2>
            </motion.div>

            <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{
            once: true
          }} className="relative bg-[#1A1A2E] rounded-3xl overflow-hidden">
              {/* Top accent bar */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#E8621A] via-[#D4A820] to-[#E8621A]" />

              {/* VIP badge */}
              <div className="absolute top-6 right-6 bg-[#E8621A] text-white text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full">
                VIP
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
                {/* Price */}
                <div className="p-10 md:p-12 flex flex-col justify-center border-b md:border-b-0 md:border-r border-white/10">
                  <p className="text-white/50 text-sm uppercase tracking-wider mb-2">{t('ironman.pricing.price_from')}</p>
                  <div className="flex items-end gap-2 mb-2">
                    <span className="text-5xl md:text-6xl font-bold text-white font-[var(--font-heading)]">
                      {t('ironman.pricing.price_value')}
                    </span>
                  </div>
                  <p className="text-white/50 text-sm mb-5">{t('ironman.pricing.price_per')}</p>
                  <div className="mb-8 rounded-2xl border border-white/15 bg-white/10 p-5">
                    <div className="flex items-start gap-3">
                      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                        <Building2 className="size-5" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-white">{t('contact.payment.transfer_title')}</h3>
                        <p className="mt-1 text-2xl font-bold text-white">€500</p>
                        <p className="text-sm font-medium text-white/90">{t('cycling_camp.pricing.deposit_title')}</p>
                      </div>
                    </div>
                    <p className="mt-4 text-sm text-white/70">{t('contact.payment.transfer_desc')}</p>
                    <p className="mt-3 text-sm leading-relaxed text-white/70">{t('cycling_camp.pricing.deposit_desc')}</p>
                  </div>

                  <div className="flex items-center gap-2 text-primary text-sm font-semibold">
                    <Users className="w-4 h-4" />
                    <span>{t('ironman.pricing.spots_note')}</span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-10 md:p-12 flex flex-col justify-between">
                  <p className="text-white/60 text-sm leading-relaxed mb-8">
                    {t('ironman.pricing.price_note')}
                  </p>
                  <div className="space-y-3">
                    {[lang === 'pl' ? '✓ 7 nocy w prywatnej willi' : lang === 'ar' ? '✓ 7 ليالٍ في فيلا خاصة' : '✓ 7 nights private villa use', lang === 'pl' ? '✓ Pełne wyżywienie z prywatnym szefem kuchni i planem posiłków od dietetyka sportowego' : lang === 'ar' ? '✓ إقامة كاملة مع طاهٍ خاص وخطة وجبات من أخصائي تغذية رياضية' : '✓ Personalized meal plan by a private chef and sports nutritionist', lang === 'pl' ? '✓ Codzienny trening z trenerem Giacomo Giovenalim, w tym woda, elektrolity i żele' : lang === 'ar' ? '✓ تدريب يومي مع المدرب Giacomo Giovenali، بما في ذلك الماء والإلكتروليتات والجل' : '✓ Daily training with Coach Giacomo Giovenali, including water, electrolytes and gels', lang === 'pl' ? '✓ Transfery z lotniska Faro w obie strony' : lang === 'ar' ? '✓ نقل من وإلى مطار فارو' : '✓ Faro Airport transfers both ways', lang === 'pl' ? '✓ Kombinezon marki MBO dla każdego uczestnika oraz zdjęcia i wideo z obozu' : lang === 'ar' ? '✓ بدلة سباق من علامة MBO لكل مشارك، مع صور وفيديو من المعسكر' : '✓ Racesuit MBO for every attendee and video, pictures from a camp'].map((item) => <p key={item} className="text-white/80 text-sm">{item}</p>)}
                  </div>

                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ── FINISH LINE CTA ── */}
        <section className="relative py-28 overflow-hidden">
          <img src="/airo-assets/images/pages/ironman/finish-line" alt="Ironman finish line" className="absolute inset-0 w-full h-full object-cover" loading="lazy" width={1920} height={600} />
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/80 pointer-events-none" />
          <div className="relative z-10 max-w-3xl mx-auto px-4 text-center">
            <motion.div variants={stagger} initial="hidden" whileInView="visible" viewport={{
            once: true
          }}>
              <motion.div variants={fadeUp} className="flex items-center justify-center gap-2 mb-6">
                <Clock className="w-5 h-5 text-[#E8621A]" />
                <span className="text-[#E8621A] text-sm font-semibold uppercase tracking-wider">
                  {lang === 'pl' ? 'Ograniczona liczba miejsc' : lang === 'ar' ? 'أماكن محدودة' : 'Limited spots available'}
                </span>
              </motion.div>
              <motion.h2 variants={fadeUp} className="text-3xl md:text-5xl font-bold text-white font-[var(--font-heading)] mb-6">
                {t('ironman.cta.title')}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-white/75 text-lg mb-10 max-w-xl mx-auto">
                {t('ironman.cta.subtitle')}
              </motion.p>
              <motion.div variants={fadeUp}>
                <Link to={`/${lang}/contact`} className="inline-flex items-center gap-2 bg-[#E8621A] hover:bg-[#d4561a] text-white font-bold px-10 py-5 rounded-full transition text-lg shadow-xl">
                  {t('ironman.cta.button')}
                  <ChevronRight className="w-6 h-6" />
                </Link>
              </motion.div>
            </motion.div>
          </div>
        </section>

      </main>
    </>;
}