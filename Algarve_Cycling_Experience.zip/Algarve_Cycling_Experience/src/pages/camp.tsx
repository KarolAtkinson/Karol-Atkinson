import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from "react-router";
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { useState } from 'react';
import { Bike, Waves, PersonStanding, ChevronDown, ChevronUp, CheckCircle2, MapPin, Calendar, Users, Star, ArrowRight, Shield, Utensils, HeartHandshake, Repeat2 } from 'lucide-react';
const STRIPE_PRICE_ID = 'price_1Tx7kCRkcNwNBXygUll5eiz7';
const site = 'https://algarveexperience.pl';
const fadeUp = {
  hidden: {
    opacity: 0,
    y: 28
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: 'easeOut' as const
    }
  }
} as const;
const stagger = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1
    }
  }
} as const;
const DAY_ICONS = [Calendar, Waves, Bike, Waves, PersonStanding, Repeat2, Star, Star];
export default function CampPage() {
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  const {
    t
  } = useTranslation();
  const isRtl = lang === 'ar';
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const handleCheckout = async () => {
    setCheckoutLoading(true);
    try {
      const res = await fetch('/api/stripe/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          priceId: STRIPE_PRICE_ID,
          quantity: 1
        })
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
    } catch {
      setCheckoutLoading(false);
    }
  };
  const url = `${site}/${lang}/camp`;
  const metaTitle = t('camp.meta_title');
  const metaDesc = t('camp.meta_desc');
  const whatItems = [{
    key: 'swim',
    icon: <Waves className="w-6 h-6" />
  }, {
    key: 'bike',
    icon: <Bike className="w-6 h-6" />
  }, {
    key: 'run',
    icon: <PersonStanding className="w-6 h-6" />
  }, {
    key: 'coach',
    icon: <HeartHandshake className="w-6 h-6" />
  }, {
    key: 'chef',
    icon: <Utensils className="w-6 h-6" />
  }, {
    key: 'villa',
    icon: <MapPin className="w-6 h-6" />
  }, {
    key: 'transfer',
    icon: <ArrowRight className="w-6 h-6" />
  }, {
    key: 'support',
    icon: <Shield className="w-6 h-6" />
  }] as const;
  const days = [1, 2, 3, 4, 5, 6, 7, 8] as const;
  const faqs = [1, 2, 3, 4, 5, 6] as const;
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Event',
    name: metaTitle,
    description: metaDesc,
    startDate: '2026-11-06',
    endDate: '2026-11-13',
    location: {
      '@type': 'Place',
      name: 'Vilamoura, Algarve',
      address: {
        '@type': 'PostalAddress',
        addressCountry: 'PT',
        addressRegion: 'Algarve'
      }
    },
    organizer: {
      '@type': 'Organization',
      name: 'Algarve Cycling Experience',
      url: site
    },
    offers: {
      '@type': 'Offer',
      price: '2900',
      priceCurrency: 'EUR',
      availability: 'https://schema.org/LimitedAvailability',
      url
    }
  };
  return <>
      <Helmet>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDesc} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={metaTitle} />
        <meta property="og:description" content={metaDesc} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="/airo-assets/images/pages/camp/hero" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={metaTitle} />
        <meta name="twitter:description" content={metaDesc} />
        <meta name="twitter:image" content="/airo-assets/images/pages/camp/hero" />
        <script type="application/ld+json">{JSON.stringify(jsonLd)}</script>
      </Helmet>

      <main dir={isRtl ? 'rtl' : 'ltr'}>

        {/* ── HERO ── */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 pointer-events-none">
            <img src="/airo-assets/images/pages/camp/hero" alt="Triathlon training camp Algarve" className="w-full h-full object-cover" loading="eager" fetchPriority="high" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
          </div>

          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center text-white pt-24 pb-16">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-sm font-semibold tracking-wide text-primary mb-4 uppercase">
                {t('camp.hero.eyebrow')}
              </motion.p>
              <motion.h1 variants={fadeUp} className="text-5xl md:text-7xl font-bold leading-tight mb-6">
                {t('camp.hero.headline_1')}<br />
                <span className="text-primary">{t('camp.hero.headline_2')}</span>
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg md:text-xl text-white/85 max-w-2xl mx-auto mb-10 leading-relaxed">
                {t('camp.hero.subline')}
              </motion.p>

              {/* Price badge */}
              <motion.div variants={fadeUp} className="inline-flex items-center gap-3 bg-white/10 backdrop-blur border border-white/20 rounded-2xl px-6 py-3 mb-8">
                <span className="text-white/70 text-sm">{t('camp.hero.price_from')}</span>
                <span className="text-3xl font-bold text-primary">{t('camp.hero.price_value')}</span>
                <span className="text-white/70 text-sm">{t('camp.hero.price_per')}</span>
              </motion.div>

              <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
                <button onClick={handleCheckout} disabled={checkoutLoading} className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-8 py-4 rounded-full text-lg transition disabled:opacity-60">
                  {checkoutLoading ? '...' : t('camp.hero.cta_reserve')}
                </button>
                <a href="#programme" className="inline-flex items-center justify-center gap-2 border-2 border-white/40 hover:border-white text-white font-semibold px-8 py-4 rounded-full text-lg transition">
                  {t('camp.hero.cta_scroll')}
                </a>
              </motion.div>
            </motion.div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 animate-bounce pointer-events-none">
            <ChevronDown className="w-6 h-6" />
          </div>
        </section>

        {/* ── URGENCY BAR ── */}
        <section className="bg-primary text-primary-foreground py-5">
          <div className="max-w-5xl mx-auto px-6">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-10 text-center">
              <div className="flex items-center gap-2 font-semibold">
                <Calendar className="w-5 h-5 shrink-0" />
                <span>{t('camp.urgency.badge_date')}</span>
              </div>
              <div className="hidden sm:block w-px h-5 bg-primary-foreground/30" />
              <div className="flex items-center gap-2 font-semibold">
                <Users className="w-5 h-5 shrink-0" />
                <span>{t('camp.urgency.badge_spots')}</span>
              </div>
              <div className="hidden sm:block w-px h-5 bg-primary-foreground/30" />
              <div className="flex items-center gap-2 font-bold text-lg">
                <span>{t('camp.urgency.badge_price')}</span>
              </div>
            </div>
          </div>
        </section>

        {/* ── WHAT'S INCLUDED ── */}
        <section className="py-24 bg-background">
          <div className="max-w-6xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="text-center mb-16">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                {t('camp.what.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-bold text-foreground">
                {t('camp.what.title')}
              </motion.h2>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {whatItems.map(({
              key,
              icon
            }) => <motion.div key={key} variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 hover:border-primary/40 transition">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-4">
                    {icon}
                  </div>
                  <h3 className="font-bold text-foreground mb-2">
                    {t(`camp.what.${key}_title`)}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {t(`camp.what.${key}_desc`)}
                  </p>
                </motion.div>)}
            </motion.div>
          </div>
        </section>

        {/* ── DISCIPLINE PHOTOS swim → bike → run ── */}
        <section className="py-16 bg-muted/20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
                <img src="/airo-assets/images/pages/camp/swim-run" alt="Open water swimming Algarve triathlon camp" className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="text-xs font-semibold uppercase tracking-wide text-white/70 mb-1">{lang === 'pl' ? 'Dyscyplina 1' : lang === 'ar' ? 'التخصص ١' : 'Discipline 1'}</p>
                  <p className="text-lg font-bold">{lang === 'pl' ? 'Pływanie' : lang === 'ar' ? 'السباحة' : 'Swimming'}</p>
                </div>
              </div>
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
                <img src="/airo-assets/images/pages/camp/group-training" alt="Cycling training Algarve IRONMAN course" className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="text-xs font-semibold uppercase tracking-wide text-white/70 mb-1">{lang === 'pl' ? 'Dyscyplina 2' : lang === 'ar' ? 'التخصص ٢' : 'Discipline 2'}</p>
                  <p className="text-lg font-bold">{lang === 'pl' ? 'Rower' : lang === 'ar' ? 'الدراجة' : 'Cycling'}</p>
                </div>
              </div>
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3]">
                <img src="/airo-assets/images/pages/camp/run-course" alt="Running triathlon Algarve Portugal" className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="text-xs font-semibold uppercase tracking-wide text-white/70 mb-1">{lang === 'pl' ? 'Dyscyplina 3' : lang === 'ar' ? 'التخصص ٣' : 'Discipline 3'}</p>
                  <p className="text-lg font-bold">{lang === 'pl' ? 'Bieg' : lang === 'ar' ? 'الجري' : 'Running'}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── 8-DAY PROGRAMME ── */}
        <section id="programme" className="py-24 bg-muted/30">
          <div className="max-w-4xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="text-center mb-16">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                {t('camp.programme.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-bold text-foreground">
                {t('camp.programme.title')}
              </motion.h2>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="relative">
              {/* Vertical line */}
              <div className="absolute left-6 top-0 bottom-0 w-px bg-border hidden sm:block" />

              <div className="flex flex-col gap-6">
                {days.map((d, i) => {
                const Icon = DAY_ICONS[i];
                const isNoTraining = d === 1 || d === 8;
                return <motion.div key={d} variants={fadeUp} className="flex gap-6 items-start">
                      {/* Circle on timeline */}
                      <div className={`relative z-10 shrink-0 w-12 h-12 rounded-full flex items-center justify-center border-2 ${isNoTraining ? 'bg-muted border-border text-muted-foreground' : 'bg-primary border-primary text-primary-foreground'}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="bg-card border border-border rounded-2xl p-5 flex-1 hover:border-primary/30 transition">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-bold text-foreground">
                            {t(`camp.programme.day${d}_title`)}
                          </h3>
                          {isNoTraining && <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">
                              {lang === 'pl' ? 'Bez treningu' : lang === 'ar' ? 'بدون تدريب' : 'No training'}
                            </span>}
                        </div>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {t(`camp.programme.day${d}_desc`)}
                        </p>
                      </div>
                    </motion.div>;
              })}
              </div>
            </motion.div>
          </div>
        </section>

        {/* ── COACH ── */}
        <section className="py-24 bg-background">
          <div className="max-w-5xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div variants={fadeUp} className="relative">
                <div className="aspect-[3/4] rounded-3xl overflow-hidden">
                  <img src="/airo-assets/images/pages/ironman/coach-giacomo" alt="Coach Giacomo Giovenali" className="w-full h-full object-cover" loading="lazy" />
                </div>
                {/* Cert badges */}
                <div className="absolute -bottom-4 -right-4 bg-primary text-primary-foreground rounded-2xl px-5 py-3 shadow-xl">
                  <p className="text-xs font-semibold opacity-80">{t('camp.coach.cert_3')}</p>
                  <p className="text-lg font-bold">{t('camp.coach.cert_4')}</p>
                </div>
              </motion.div>

              <motion.div variants={stagger}>
                <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                  {t('camp.coach.label')}
                </motion.p>
                <motion.h2 variants={fadeUp} className="text-4xl font-bold text-foreground mb-2">
                  {t('camp.coach.title')}
                </motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground mb-6">
                  {t('camp.coach.subtitle')}
                </motion.p>
                <motion.p variants={fadeUp} className="text-foreground leading-relaxed mb-8">
                  {t('camp.coach.bio')}
                </motion.p>
                <motion.div variants={stagger} className="grid grid-cols-2 gap-3">
                  {(['cert_1', 'cert_2', 'cert_3', 'cert_4'] as const).map(c => <motion.div key={c} variants={fadeUp} className="flex items-center gap-2">
                      <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                      <span className="text-sm text-foreground font-medium">{t(`camp.coach.${c}`)}</span>
                    </motion.div>)}
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* ── COACH CONCIERGE ── */}
        <section className="py-20 bg-muted/30">
          <div className="max-w-5xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary tracking-wide mb-3">
                {lang === 'pl' ? 'Czym różni się ten obóz' : lang === 'ar' ? 'ما الذي يميز هذا المعسكر' : 'What makes this camp different'}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                {lang === 'pl' ? 'Usługa Coach Concierge' : lang === 'ar' ? 'خدمة Coach Concierge' : 'Coach Concierge Service'}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground text-lg max-w-2xl mx-auto leading-relaxed">
                {lang === 'pl'
                  ? 'To nie jest zwykła seria sesji treningowych. Giacomo zapewnia ciągłe, osobiste wsparcie przez cały obóz — tak abyś wyjechał z kompletnym systemem, nie tylko lepszą formą.'
                  : lang === 'ar'
                  ? 'هذه ليست مجرد سلسلة من جلسات التدريب. يقدم Giacomo دعماً شخصياً مستمراً طوال المعسكر — لتغادر بنظام متكامل، لا مجرد لياقة أفضل.'
                  : 'This is not simply a series of training sessions. Giacomo provides continuous personal support throughout the camp — so you leave with a complete system, not just fitness.'}
              </motion.p>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {([
                {
                  icon: <Waves className="w-5 h-5" />,
                  en: { title: 'Training', desc: 'Structured daily sessions across all three disciplines, adapted to each athlete\'s level and goals.' },
                  pl: { title: 'Trening', desc: 'Ustrukturyzowane codzienne sesje we wszystkich trzech dyscyplinach, dopasowane do poziomu i celów każdego sportowca.' },
                  ar: { title: 'التدريب', desc: 'جلسات يومية منظمة في جميع التخصصات الثلاثة، مكيّفة مع مستوى وأهداف كل رياضي.' }
                },
                {
                  icon: <Bike className="w-5 h-5" />,
                  en: { title: 'Equipment', desc: 'Bike position check, cleat alignment, and practical guidance on what to carry and how to organise it.' },
                  pl: { title: 'Sprzęt', desc: 'Sprawdzenie pozycji na rowerze, ustawienie bloków i praktyczne wskazówki dotyczące organizacji sprzętu.' },
                  ar: { title: 'المعدات', desc: 'فحص وضعية الدراجة، محاذاة المشابك، وإرشادات عملية حول ما تحمله وكيفية تنظيمه.' }
                },
                {
                  icon: <Utensils className="w-5 h-5" />,
                  en: { title: 'Nutrition', desc: 'Meals adapted to each day\'s training load. Learn to fuel before, during and after training and racing.' },
                  pl: { title: 'Żywienie', desc: 'Posiłki dostosowane do obciążenia każdego dnia. Naucz się jak się odżywiać przed, w trakcie i po treningu i wyścigu.' },
                  ar: { title: 'التغذية', desc: 'وجبات مكيّفة مع حجم تدريب كل يوم. تعلّم كيفية التغذية قبل وأثناء وبعد التدريب والسباق.' }
                },
                {
                  icon: <Repeat2 className="w-5 h-5" />,
                  en: { title: 'Transitions', desc: 'How to organise your gear, prepare transition bags, and manage T1 and T2 correctly. Practical drills included.' },
                  pl: { title: 'Przejścia', desc: 'Jak organizować sprzęt, przygotować torby zmian i prawidłowo zarządzać T1 i T2. Ćwiczenia praktyczne w programie.' },
                  ar: { title: 'الانتقالات', desc: 'كيفية تنظيم معداتك، تحضير حقائب الانتقال، وإدارة T1 وT2 بشكل صحيح. تمارين عملية مشمولة.' }
                },
                {
                  icon: <PersonStanding className="w-5 h-5" />,
                  en: { title: 'Race Preparation', desc: 'Strategy, pacing, mental preparation and a personalised plan for the next phase of your training.' },
                  pl: { title: 'Przygotowanie do wyścigu', desc: 'Strategia, tempo, przygotowanie mentalne i spersonalizowany plan na kolejny etap przygotowań.' },
                  ar: { title: 'التحضير للسباق', desc: 'الاستراتيجية، الإيقاع، التحضير الذهني وخطة مخصصة للمرحلة التالية من تدريبك.' }
                },
                {
                  icon: <HeartHandshake className="w-5 h-5" />,
                  en: { title: 'Personal Attention', desc: 'Maximum 8 athletes. Giacomo knows your name, your goals, and your weaknesses — from day one to departure.' },
                  pl: { title: 'Osobiste podejście', desc: 'Maksymalnie 8 sportowców. Giacomo zna Twoje imię, cele i słabe strony — od pierwszego do ostatniego dnia.' },
                  ar: { title: 'الاهتمام الشخصي', desc: 'حد أقصى 8 رياضيين. Giacomo يعرف اسمك وأهدافك ونقاط ضعفك — من اليوم الأول حتى المغادرة.' }
                }
              ] as const).map((item, i) => (
                <motion.div key={i} variants={fadeUp} className="bg-card border border-border rounded-2xl p-6 hover:border-primary/40 transition">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-4">
                    {item.icon}
                  </div>
                  <h3 className="font-bold text-foreground mb-2">
                    {lang === 'pl' ? item.pl.title : lang === 'ar' ? item.ar.title : item.en.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {lang === 'pl' ? item.pl.desc : lang === 'ar' ? item.ar.desc : item.en.desc}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── COURSE STATS ── */}
        <section className="py-20 bg-foreground text-background">
          <div className="max-w-5xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                {t('camp.course.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-4">
                {t('camp.course.title')}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-background/70 max-w-2xl mx-auto leading-relaxed">
                {t('camp.course.desc')}
              </motion.p>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {([1, 2, 3, 4] as const).map(n => <motion.div key={n} variants={fadeUp} className="text-center border border-background/20 rounded-2xl p-6">
                  <p className="text-4xl font-bold text-primary mb-1">{t(`camp.course.stat_${n}_value`)}</p>
                  <p className="text-background/60 text-sm">{t(`camp.course.stat_${n}_label`)}</p>
                </motion.div>)}
            </motion.div>

            {/* Course image */}
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={fadeUp} className="mt-12 rounded-3xl overflow-hidden aspect-video">
              <img src="/airo-assets/images/pages/ironman/bike-route" alt="IRONMAN 70.3 Vilamoura bike course Algarve" className="w-full h-full object-cover" loading="lazy" />
            </motion.div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section id="pricing" className="py-24 bg-background">
          <div className="max-w-3xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                {t('camp.pricing.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-bold text-foreground">
                {t('camp.pricing.title')}
              </motion.h2>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={fadeUp} className="bg-card border border-border rounded-3xl overflow-hidden shadow-xl">
              {/* Price header */}
              <div className="bg-primary text-primary-foreground p-10 text-center">
                <p className="text-6xl font-bold mb-1">{t('camp.pricing.price')}</p>
                <p className="text-primary-foreground/80 text-lg">{t('camp.pricing.per')}</p>
              </div>

              <div className="p-8 md:p-10">
                <p className="text-muted-foreground text-sm leading-relaxed mb-8 text-center">
                  {t('camp.pricing.note')}
                </p>

                {/* Deposit info */}
                <div className="bg-muted/50 rounded-2xl p-6 mb-6">
                  <h3 className="font-bold text-foreground mb-2">{t('camp.pricing.deposit_title')}</h3>
                  <p className="text-muted-foreground text-sm">{t('camp.pricing.deposit_desc')}</p>
                </div>

                {/* Not included */}
                <div className="border border-border rounded-2xl p-6 mb-8">
                  <h3 className="font-semibold text-foreground mb-2 text-sm">{t('camp.pricing.not_included_title')}</h3>
                  <p className="text-muted-foreground text-sm">{t('camp.pricing.not_included')}</p>
                </div>

                {/* CTA */}
                <button onClick={handleCheckout} disabled={checkoutLoading} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-5 rounded-2xl text-lg transition disabled:opacity-60 mb-3">
                  {checkoutLoading ? '...' : t('camp.pricing.cta')}
                </button>
                <p className="text-center text-muted-foreground text-xs flex items-center justify-center gap-2">
                  <Shield className="w-4 h-4" />
                  {t('camp.pricing.cta_sub')}
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ── FAQ ── */}
        <section className="py-24 bg-muted/30">
          <div className="max-w-3xl mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-sm font-semibold text-primary uppercase tracking-wide mb-3">
                {t('camp.faq.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="text-4xl font-bold text-foreground">
                {t('camp.faq.title')}
              </motion.h2>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger} className="flex flex-col gap-3">
              {faqs.map(n => <motion.div key={n} variants={fadeUp} className="bg-card border border-border rounded-2xl overflow-hidden">
                  <button className="w-full flex items-center justify-between gap-4 p-6 text-left hover:bg-muted/30 transition" onClick={() => setOpenFaq(openFaq === n ? null : n)} aria-expanded={openFaq === n}>
                    <span className="font-semibold text-foreground">{t(`camp.faq.q${n}`)}</span>
                    {openFaq === n ? <ChevronUp className="w-5 h-5 text-primary shrink-0" /> : <ChevronDown className="w-5 h-5 text-muted-foreground shrink-0" />}
                  </button>
                  {openFaq === n && <div className="px-6 pb-6">
                      <p className="text-muted-foreground leading-relaxed">{t(`camp.faq.a${n}`)}</p>
                    </div>}
                </motion.div>)}
            </motion.div>
          </div>
        </section>

        {/* ── FINAL CTA ── */}
        <section className="py-24 bg-foreground text-background">
          <div className="max-w-3xl mx-auto px-6 text-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{
            once: true
          }} variants={stagger}>
              <motion.h2 variants={fadeUp} className="text-4xl md:text-5xl font-bold mb-6">
                {t('camp.cta_final.title')}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-background/70 text-lg leading-relaxed mb-10 max-w-xl mx-auto">
                {t('camp.cta_final.desc')}
              </motion.p>
              <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
                <button onClick={handleCheckout} disabled={checkoutLoading} className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-10 py-5 rounded-full text-lg transition disabled:opacity-60">
                  {checkoutLoading ? '...' : t('camp.cta_final.cta')}
                </button>
                <Link to={`/${lang}/contact`} className="inline-flex items-center justify-center gap-2 border-2 border-background/30 hover:border-background text-background font-semibold px-10 py-5 rounded-full text-lg transition">
                  {t('camp.cta_final.ask')}
                </Link>
              </motion.div>
            </motion.div>
          </div>
        </section>

      </main>
    </>;
}
