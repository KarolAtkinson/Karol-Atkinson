import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from "react-router";
import { useTranslation } from 'react-i18next';
import { motion } from 'motion/react';
import { Bike, Camera, CheckCircle2, ClipboardList, MapPin, Calendar, Plane, Star, UserRound, Users, Utensils, HeartHandshake, Mountain, Wind, Wrench, Building2 } from 'lucide-react';
const site = 'https://algarveexperience.pl';

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } }
} as const;

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } }
} as const;

const DAY_ICONS = [Calendar, Bike, Mountain, Wind, Bike, Star, HeartHandshake, Star];

export default function CyclingCampPage() {
  const { lang = 'en' } = useParams<{ lang: string }>();
  const { t } = useTranslation();
  const isRtl = lang === 'ar';

  const url = `${site}/${lang}/cycling-camp`;
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsEvent',
    '@id': `${url}#event`,
    name: 'Algarve Cycling Camp 2027',
    description: t('cycling_camp.meta_desc'),
    sport: 'Cycling',
    startDate: '2027-04-01',
    endDate: '2027-04-08',
    eventStatus: 'https://schema.org/EventScheduled',
    eventAttendanceMode: 'https://schema.org/OfflineEventAttendanceMode',
    location: {
      '@type': 'Place',
      name: 'Algarve, Portugal',
      address: { '@type': 'PostalAddress', addressCountry: 'PT', addressRegion: 'Algarve' }
    },
    organizer: { '@id': `${site}/#organization` },
    offers: {
      '@type': 'Offer',
      price: '2190',
      priceCurrency: 'EUR',
      availability: 'https://schema.org/LimitedAvailability',
      validFrom: '2026-10-01',
      url
    },
    image: `${site}/airo-assets/images/pages/camp/group-training`,
    url,
    isPartOf: { '@id': `${site}/#website` },
  };

  const includedItems = [
    { key: 'villa', icon: <MapPin size={22} /> },
    { key: 'nutrition', icon: <Utensils size={22} /> },
    { key: 'bike', icon: <Wrench size={22} /> },
    { key: 'cycling', icon: <Bike size={22} /> },
    { key: 'airport_transfer', icon: <Plane size={22} /> },
    { key: 'premium_bike', icon: <Bike size={22} /> },
    { key: 'mobile_service', icon: <Wrench size={22} /> },
    { key: 'pro_coach', icon: <UserRound size={22} /> },
    { key: 'media', icon: <Camera size={22} /> },
    { key: 'training_plan', icon: <ClipboardList size={22} /> },
  ];

  const notIncludedItems = [
    { key: 'transfer', icon: <Wind size={22} /> },
    { key: 'support', icon: <CheckCircle2 size={22} /> },
  ];



  return (
    <>
      <Helmet>
        <title>{t('cycling_camp.meta_title')}</title>
        <meta name="description" content={t('cycling_camp.meta_desc')} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={t('cycling_camp.meta_title')} />
        <meta property="og:description" content={t('cycling_camp.meta_desc')} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/camp/group-training`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={t('cycling_camp.meta_title')} />
        <meta name="twitter:description" content={t('cycling_camp.meta_desc')} />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/camp/group-training`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main dir={isRtl ? 'rtl' : 'ltr'}>

        {/* ── HERO ── */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 pointer-events-none">
            <img
              src="/airo-assets/images/pages/camp/group-training"
              alt="Cyclists riding in Algarve Portugal"
              className="w-full h-full object-cover"
              loading="eager"
              fetchPriority="high"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-gray-900/70 via-gray-900/50 to-gray-900/80 pointer-events-none" />
          </div>

          <div className="relative z-10 container mx-auto px-6 text-center">
            <motion.div initial="hidden" animate="visible" variants={stagger} className="max-w-4xl mx-auto">
              <motion.p variants={fadeUp} className="text-primary font-semibold tracking-wide mb-5 text-lg md:text-xl uppercase">
                {t('cycling_camp.hero.eyebrow')}
              </motion.p>
              <motion.h1 variants={fadeUp} className="font-heading text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
                <span>{t('cycling_camp.hero.headline_1')}</span>
                <br />
                <span className="text-primary">{t('cycling_camp.hero.headline_2')}</span>
              </motion.h1>
              <motion.p variants={fadeUp} className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
                {t('cycling_camp.hero.subline')}
              </motion.p>

              {/* Price badge */}
              <motion.div variants={fadeUp} className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl px-6 py-4 mb-8">
                <span className="text-3xl font-bold text-primary">{t('cycling_camp.hero.price_value')}</span>
                <span className="text-white/70 text-sm">{t('cycling_camp.hero.price_per')}</span>
              </motion.div>

              <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="#included" className="border border-white/30 text-white font-medium px-8 py-4 rounded-xl hover:bg-white/10 transition-all duration-200 text-lg">
                  {t('cycling_camp.hero.cta_scroll')}
                </a>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* ── URGENCY STRIP ── */}
        <section className="bg-primary py-6">
          <div className="container mx-auto px-6">
            <div className="flex flex-wrap items-center justify-center gap-6 text-primary-foreground">
              <div className="flex items-center gap-2 font-semibold">
                <Calendar size={18} />
                <span>{t('cycling_camp.urgency.badge_date')}</span>
              </div>
              <div className="w-px h-5 bg-primary-foreground/30 hidden sm:block" />
              <div className="flex items-center gap-2 font-semibold">
                <Users size={18} />
                <span>{t('cycling_camp.urgency.badge_spots')}</span>
              </div>
              <div className="w-px h-5 bg-primary-foreground/30 hidden sm:block" />
              <div className="flex items-center gap-2 font-semibold">
                <Star size={18} />
                <span>{t('cycling_camp.urgency.badge_price')}</span>
              </div>
            </div>
          </div>
        </section>

        {/* ── URGENCY BLOCK ── */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-6 max-w-3xl text-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
              <motion.h2 variants={fadeUp} className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
                {t('cycling_camp.urgency.title')}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground text-lg leading-relaxed">
                {t('cycling_camp.urgency.desc')}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* ── WHAT'S INCLUDED ── */}
        <section id="included" className="py-24 bg-background">
          <div className="container mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-14">
              <motion.p variants={fadeUp} className="text-primary font-medium text-sm uppercase tracking-wide mb-3">
                {t('cycling_camp.what.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold text-foreground">
                {t('cycling_camp.what.title')}
              </motion.h2>
            </motion.div>

            <div className="max-w-5xl mx-auto flex flex-col gap-12">
              <section aria-labelledby="included-items-title">
                <h3 id="included-items-title" className="font-heading text-2xl font-bold text-foreground mb-6">{t('cycling_camp.what.included')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {includedItems.map((item, i) => (
                    <motion.div
                      key={item.key}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: i * 0.08 }}
                      className="bg-card rounded-2xl p-7 border border-border flex gap-5 items-start hover:-translate-y-1 hover:shadow-md transition-all duration-300"
                    >
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0">{item.icon}</div>
                      <div>
                        <h4 className="font-semibold text-foreground mb-1">
                          {item.key === 'villa' ? (
                            <Link to={`/${lang}/accommodation`} className="hover:text-primary transition-colors">
                              {t(`cycling_camp.what.${item.key}_title`)}
                            </Link>
                          ) : t(`cycling_camp.what.${item.key}_title`)}
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{t(`cycling_camp.what.${item.key}_desc`)}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              <section aria-labelledby="not-included-items-title">
                <h3 id="not-included-items-title" className="font-heading text-2xl font-bold text-foreground mb-6">{t('cycling_camp.what.not_included')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {notIncludedItems.map((item, i) => (
                    <motion.div
                      key={item.key}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: i * 0.08 }}
                      className="bg-card rounded-2xl p-7 border border-border flex gap-5 items-start hover:-translate-y-1 hover:shadow-md transition-all duration-300"
                    >
                      <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center text-muted-foreground shrink-0">{item.icon}</div>
                      <div>
                        <h4 className="font-semibold text-foreground mb-1">{t(`cycling_camp.what.${item.key}_title`)}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">{t(`cycling_camp.what.${item.key}_desc`)}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>

              <p className="text-sm text-muted-foreground">{t('cycling_camp.what.vat_note')}</p>
            </div>
          </div>
        </section>

        {/* ── PROGRAMME ── */}
        <section className="py-24 bg-muted">
          <div className="container mx-auto px-6">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-14">
              <motion.p variants={fadeUp} className="text-primary font-medium text-sm uppercase tracking-wide mb-3">
                {t('cycling_camp.programme.label')}
              </motion.p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-4xl mx-auto">
              {([1, 2, 3, 4, 5, 6, 7, 8] as const).map((day, i) => {
                const Icon = DAY_ICONS[i] ?? Bike;
                return (
                  <motion.div
                    key={day}
                    initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: i * 0.07 }}
                    className="bg-card rounded-2xl p-6 border border-border flex gap-4"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0 mt-0.5">
                      <Icon size={20} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">{t(`cycling_camp.programme.day${day}_title`)}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{t(`cycling_camp.programme.day${day}_desc`)}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section className="py-24 bg-card">
          <div className="container mx-auto px-6 max-w-3xl">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger} className="text-center mb-12">
              <motion.p variants={fadeUp} className="text-primary font-medium text-sm uppercase tracking-wide mb-3">
                {t('cycling_camp.pricing.label')}
              </motion.p>
              <motion.h2 variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold text-foreground">
                {t('cycling_camp.pricing.title')}
              </motion.h2>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-background rounded-3xl border border-border p-10 text-center"
            >
              <p className="text-6xl font-bold mb-1 text-foreground">{t('cycling_camp.pricing.price')}</p>
              <p className="text-muted-foreground mb-6">{t('cycling_camp.pricing.per')}</p>

              <div className="bg-primary/10 rounded-2xl p-5 mb-8 text-left">
                <div className="flex items-start gap-3">
                  <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                    <Building2 className="size-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground">{t('contact.payment.transfer_title')}</h3>
                    <p className="mt-1 text-2xl font-bold text-foreground">€500</p>
                    <p className="text-sm font-medium text-foreground">{t('cycling_camp.pricing.deposit_title')}</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-muted-foreground">{t('contact.payment.transfer_desc')}</p>
                <p className="mt-3 text-sm text-muted-foreground">{t('cycling_camp.pricing.deposit_desc')}</p>
              </div>

              <div className="mt-8 pt-6 border-t border-border text-left">
                <p className="text-sm font-semibold text-foreground mb-2">{t('cycling_camp.pricing.not_included_title')}</p>
                <p className="text-sm text-muted-foreground">{t('cycling_camp.pricing.not_included')}</p>
              </div>
            </motion.div>
          </div>
        </section>

      </main>
    </>
  );
}
