import { useState, useRef } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { useParams } from "react-router";
import { useTranslation } from 'react-i18next';
import { contact } from 'virtual:content';
import { motion } from 'motion/react';
import { Mail, Instagram, Clock, User, MapPin, CheckCircle, AlertCircle, Building2, Info, Phone } from 'lucide-react';
const site = 'https://algarveexperience.pl';
export default function ContactPage() {
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  const {
    t
  } = useTranslation();
  const isRtl = lang === 'ar';
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [selectedTour, setSelectedTour] = useState('');
  const honeypotRef = useRef<HTMLInputElement>(null);
  const url = `${site}/${lang}/contact`;
  const title = lang === 'pl' ? contact.seo.title.pl : lang === 'ar' ? contact.seo.title.ar : contact.seo.title.en;
  const description = lang === 'pl' ? contact.seo.description.pl : lang === 'ar' ? contact.seo.description.ar : contact.seo.description.en;
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'ContactPage',
    '@id': `${url}#webpage`,
    name: title,
    url,
    isPartOf: {
      '@id': `${site}/#website`
    },
    about: {
      '@id': `${site}/#organization`
    }
  };
  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    // Honeypot check
    if (honeypotRef.current?.value) return;
    const form = e.currentTarget;
    const data = new FormData(form);
    const name = data.get('name') as string;
    const email = data.get('email') as string;
    const phone = data.get('phone') as string;
    const tour = selectedTour;
    const dates = data.get('dates') as string;
    const persons = data.get('persons') as string;
    const message = data.get('message') as string;
    if (!name || !email || !message) return;
    setStatus('submitting');
    try {
      // Field mapping: only the message textarea goes in messages_attributes[0].body.
      // All other fields (dropdowns, radios, checkboxes) must be added to conversation.data as { "Label": value } pairs.
      const res = await fetch('/api/contact/booking-inquiry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          conversation: {
            messages_attributes: [{
              body: message || 'New booking enquiry'
            }],
            data: {
              __gd_contact_form_title: 'Booking Enquiry',
              'Tour of interest': tour || 'Not specified',
              'Preferred dates': dates || 'Not specified',
              'Number of riders': persons || 'Not specified',
              'Phone': phone || 'Not provided'
            }
          },
          user: {
            email,
            name
          }
        })
      });
      const json = await res.json();
      if (json.success) {
        setStatus('success');
        form.reset();
        setSelectedTour('');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  }
  const tourOptions = [{
    value: 'coastal',
    label: t('contact.form.tour_coastal')
  }, {
    value: 'village',
    label: t('contact.form.tour_village')
  }, {
    value: 'mountain',
    label: t('contact.form.tour_mountain')
  }, {
    value: 'women',
    label: t('contact.form.tour_women')
  }, {
    value: 'custom',
    label: t('contact.form.tour_custom')
  }];
  const infoItems = [{
    icon: Clock,
    title: t('contact.info.response_title'),
    desc: t('contact.info.response_desc')
  }, {
    icon: User,
    title: t('contact.info.personal_title'),
    desc: t('contact.info.personal_desc')
  }, {
    icon: MapPin,
    title: t('contact.info.local_title'),
    desc: t('contact.info.local_desc')
  }];
  return <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/contact/hero`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/contact/hero`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main dir={isRtl ? 'rtl' : 'ltr'}>
        {/* Hero */}
        <section className="relative h-72 md:h-96 overflow-hidden">
          <img src="/airo-assets/images/pages/contact/hero" alt="Cycling in the Algarve" className="absolute inset-0 w-full h-full object-cover" loading="eager" fetchPriority="high" width={1920} height={600} />
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/60 to-gray-900/75 pointer-events-none" />
          <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
            <motion.p initial={{
            opacity: 0,
            y: 16
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5,
            ease: 'easeOut' as const
          }} className="text-sm font-medium tracking-wide text-[#E8621A] mb-3 uppercase">
              {t('contact.hero.eyebrow')}
            </motion.p>
            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.1,
            ease: 'easeOut' as const
          }} className="text-3xl md:text-5xl font-bold text-white font-[var(--font-heading)] mb-4">
              {t('contact.hero.title')}
            </motion.h1>
            <motion.p initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2,
            ease: 'easeOut' as const
          }} className="text-base md:text-lg text-white/85 max-w-xl">
              {t('contact.hero.subtitle')}
            </motion.p>
          </div>
        </section>

        {/* Main content */}
        <section className="py-16 md:py-24 bg-background">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">

              {/* Form — wider column */}
              <motion.div initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              ease: 'easeOut' as const
            }} className="lg:col-span-3">
                <div className="bg-card rounded-2xl shadow-sm border border-border p-8 md:p-10">
                  <h2 className="text-2xl font-bold text-foreground font-[var(--font-heading)] mb-8">
                    {t('contact.form.title')}
                  </h2>

                  {status === 'success' ? <motion.div initial={{
                  opacity: 0,
                  scale: 0.95
                }} animate={{
                  opacity: 1,
                  scale: 1
                }} className="flex flex-col items-center text-center py-12 gap-4">
                      <CheckCircle className="w-16 h-16 text-green-500" />
                      <h3 className="text-xl font-bold text-foreground font-[var(--font-heading)]">
                        {t('contact.form.success_title')}
                      </h3>
                      <p className="text-muted-foreground max-w-sm">
                        {t('contact.form.success_text')}
                      </p>
                      <button onClick={() => setStatus('idle')} className="mt-4 text-sm text-[#E8621A] hover:underline">
                        {t('calculator.summary.reset')}
                      </button>
                    </motion.div> : <form onSubmit={handleSubmit} noValidate className="space-y-6">
                      {/* Honeypot */}
                      <input ref={honeypotRef} type="text" name="_gotcha" tabIndex={-1} autoComplete="off" style={{
                    position: 'absolute',
                    left: '-9999px'
                  }} aria-hidden="true" />

                      {/* Name + Email */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1.5">
                            {t('contact.form.name_label')} <span className="text-[#E8621A]">*</span>
                          </label>
                          <input id="name" name="name" type="text" required placeholder={t('contact.form.name_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition" />
                        </div>
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1.5">
                            {t('contact.form.email_label')} <span className="text-[#E8621A]">*</span>
                          </label>
                          <input id="email" name="email" type="email" required placeholder={t('contact.form.email_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition" />
                        </div>
                      </div>

                      {/* Phone */}
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-1.5">
                          {t('contact.form.phone_label')}
                        </label>
                        <input id="phone" name="phone" type="tel" placeholder={t('contact.form.phone_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition" />
                      </div>

                      {/* Tour interest */}
                      <div>
                        <label htmlFor="tour" className="block text-sm font-medium text-foreground mb-1.5">
                          {t('contact.form.tour_label')}
                        </label>
                        <select id="tour" value={selectedTour} onChange={e => setSelectedTour(e.target.value)} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition">
                          <option value="">{t('contact.form.tour_placeholder')}</option>
                          {tourOptions.map(opt => <option key={opt.value} value={opt.label}>
                              {opt.label}
                            </option>)}
                        </select>
                      </div>

                      {/* Dates + Persons */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="dates" className="block text-sm font-medium text-foreground mb-1.5">
                            {t('contact.form.dates_label')}
                          </label>
                          <input id="dates" name="dates" type="text" placeholder={t('contact.form.dates_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition" />
                        </div>
                        <div>
                          <label htmlFor="persons" className="block text-sm font-medium text-foreground mb-1.5">
                            {t('contact.form.persons_label')}
                          </label>
                          <input id="persons" name="persons" type="number" min={1} max={20} placeholder={t('contact.form.persons_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition" />
                        </div>
                      </div>

                      {/* Message */}
                      <div>
                        <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1.5">
                          {t('contact.form.message_label')} <span className="text-[#E8621A]">*</span>
                        </label>
                        <textarea id="message" name="message" required rows={5} placeholder={t('contact.form.message_placeholder')} className="w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#E8621A]/40 focus:border-[#E8621A] transition resize-none" />
                      </div>

                      {/* Error */}
                      {status === 'error' && <div className="flex items-center gap-2 text-sm text-red-600 bg-red-50 rounded-lg px-4 py-3">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>{t('contact.form.error_text')}</span>
                        </div>}

                      {/* Submit */}
                      <button type="submit" disabled={status === 'submitting'} className="w-full bg-[#E8621A] hover:bg-[#d4561a] text-white font-semibold py-3 px-6 rounded-lg transition disabled:opacity-60 disabled:cursor-not-allowed">
                        {status === 'submitting' ? t('contact.form.submitting') : t('contact.form.submit')}
                      </button>
                    </form>}
                </div>
              </motion.div>

              {/* Info sidebar */}
              <motion.div initial={{
              opacity: 0,
              y: 30
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.15,
              ease: 'easeOut' as const
            }} className="lg:col-span-2 flex flex-col gap-8">
                <div>
                  <h2 className="text-xl font-bold text-foreground font-[var(--font-heading)] mb-6">
                    {t('contact.info.title')}
                  </h2>
                  <div className="flex flex-col gap-6">
                    {infoItems.map(item => <div key={item.title} className="flex gap-4">
                        <div className="shrink-0 w-10 h-10 rounded-full bg-[#E8621A]/10 flex items-center justify-center">
                          <item.icon className="w-5 h-5 text-[#E8621A]" />
                        </div>
                        <div>
                          <p className="font-semibold text-foreground text-sm">{item.title}</p>
                          <p className="text-muted-foreground text-sm mt-0.5">{item.desc}</p>
                        </div>
                      </div>)}
                  </div>
                </div>

                {/* Direct contact */}
                <div className="rounded-2xl bg-primary/5 border border-primary/20 p-6 flex flex-col gap-4">
                  <div className="flex items-start gap-3 text-sm font-medium text-foreground">
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                      <Phone className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{t('contact.info.phone_label')}</p>
                      <a href="tel:+351911826188" className="block hover:text-primary transition-colors">+351 911 826 188</a>
                      <a href="tel:+48602634209" className="block hover:text-primary transition-colors">+48 602 634 209</a>
                    </div>
                  </div>
                  <a href="mailto:info@algarveexperience.pl" className="flex items-center gap-3 text-sm font-medium text-foreground hover:text-primary transition group">
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition">
                      <Mail className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{t('contact.info.email_label')}</p>
                      <p>info@algarveexperience.pl</p>
                    </div>
                  </a>
                  <a href="https://instagram.com/algarveexperience" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-sm font-medium text-foreground hover:text-[#E8621A] transition group">
                    <div className="w-9 h-9 rounded-full bg-[#E8621A]/10 flex items-center justify-center group-hover:bg-[#E8621A]/20 transition">
                      <Instagram className="w-4 h-4 text-[#E8621A]" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">{t('contact.info.instagram_label')}</p>
                      <p>@algarveexperience</p>
                    </div>
                  </a>
                </div>

                {/* Calculator CTA — hidden while calculator is not yet public */}
                {/* <div className="rounded-2xl bg-card border border-border p-6">
                  ...
                 </div> */}

                {/* Payment methods */}
                <motion.div initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.5,
                delay: 0.2,
                ease: 'easeOut' as const
              }} className="rounded-2xl bg-card border border-border p-6">
                  <h3 className="text-base font-bold text-foreground font-[var(--font-heading)] mb-1">
                    {t('contact.payment.title')}
                  </h3>
                  <p className="text-xs text-muted-foreground mb-5">
                    {t('contact.payment.subtitle')}
                  </p>

                  <div className="flex flex-col gap-4">
                    {/* Bank transfer */}
                    <div className="flex gap-3 items-start">
                      <div className="shrink-0 w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center mt-0.5">
                        <Building2 className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-foreground">{t('contact.payment.transfer_title')}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{t('contact.payment.transfer_desc')}</p>
                      </div>
                    </div>

                    {/* Deposit info */}
                    <div className="mt-1 rounded-xl bg-primary/5 border border-primary/15 px-4 py-3 flex gap-2.5 items-start">
                      <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-semibold text-foreground">{t('contact.payment.deposit_title')}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{t('contact.payment.deposit_desc')}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </motion.div>

            </div>
          </div>
        </section>
      </main>
    </>;
}
