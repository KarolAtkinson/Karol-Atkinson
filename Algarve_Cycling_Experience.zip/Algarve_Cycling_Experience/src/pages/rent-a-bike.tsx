import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from 'react-router';
import { Bike, CheckCircle2, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { rent_a_bike } from 'virtual:content';

const site = 'https://algarveexperience.pl';

type BikeRental = {
  id: string;
  image: string;
  available?: number;
  brand: string;
  price_from?: number;
  price_1day?: number;
  price_3days?: number;
  price_7days?: number;
  price_15days?: number;
  reference_only?: boolean;
};

export default function RentABikePage() {
  const { lang = 'en' } = useParams<{ lang: string }>();
  const { t } = useTranslation();
  const bikes = rent_a_bike.bikes as BikeRental[];
  const bikeLabel = (bike: BikeRental, field: 'name' | 'description') => t(`rent_bike.bikes.${bike.id === 'road-aluminium' ? 'road_alu' : bike.id.replaceAll('-', '_')}.${field}`);
  const price = (value?: number) => value === undefined ? t('rent_bike.price_on_request') : `€${value}`;
  const url = `${site}/${lang}/rent-a-bike`;
  const title = `${t('rent_bike.nav_label')} | Algarve Cycling`;
  const description = t('rent_bike.hero_subtitle');
  const conditions = t('rent_bike.conditions', { returnObjects: true }) as string[];
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    '@id': `${url}#webpage`,
    name: title,
    url,
    isPartOf: { '@id': `${site}/#website` },
    about: { '@id': `${site}/#organization` },
  };

  return <>
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={url} />
      <meta property="og:image" content={`${site}/airo-assets/images/pages/rent-a-bike/road-aluminium`} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={`${site}/airo-assets/images/pages/rent-a-bike/road-aluminium`} />
      <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
    </Helmet>
    <main>
      <section className="relative overflow-hidden bg-foreground py-28 md:py-36">
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-br from-primary to-foreground" />
        <div className="relative container mx-auto px-6">
          <div className="max-w-3xl">
            <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-primary-foreground"><Bike size={18} />{t('rent_bike.hero_eyebrow')}</p>
            <h1 className="font-heading text-4xl font-bold leading-tight text-primary-foreground md:text-6xl">{t('rent_bike.hero_title')}</h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-primary-foreground">{t('rent_bike.hero_subtitle')}</p>
          </div>
        </div>
      </section>

      <section className="bg-background py-16 md:py-24">
        <div className="container mx-auto px-6">
          <div className="mb-10 max-w-2xl">
            <h2 className="font-heading text-3xl font-bold text-foreground md:text-4xl">{t('rent_bike.table_title')}</h2>
            <p className="mt-3 text-muted-foreground">{t('rent_bike.table_intro')}</p>
          </div>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
            {bikes.map((bike) => <Link key={bike.id} to={`/${lang}/rent-a-bike/${bike.id}`} className="group overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-shadow hover:shadow-lg block">
              <div className="overflow-hidden bg-muted"><img src={bike.image} alt={bikeLabel(bike, 'name')} className="aspect-[4/3] w-full object-contain p-5 transition-transform duration-500 group-hover:scale-105" loading="lazy" fetchPriority="auto" width={1200} height={900} /></div>
              <div className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-semibold text-primary">{bike.brand}</p>
                    <h3 className="mt-1 font-heading text-2xl font-bold text-card-foreground">{bikeLabel(bike, 'name')}</h3>
                  </div>
                  <div className="shrink-0 rounded-lg bg-muted px-3 py-2 text-right"><p className="text-xs text-muted-foreground">{t('rent_bike.from')}</p><p className="font-heading text-lg font-bold text-foreground">{price(bike.price_from ?? bike.price_15days)}<span className="text-xs font-normal"> {t('rent_bike.per_day')}</span></p></div>
                </div>
                <p className="mt-4 min-h-16 text-sm leading-relaxed text-muted-foreground">{bikeLabel(bike, 'description')}</p>
                <div className="mt-5 border-t border-border pt-4">
                  <p className="flex items-start gap-2 text-sm leading-relaxed text-muted-foreground"><CheckCircle2 size={16} className="mt-0.5 shrink-0 text-primary" />{t('rent_bike.equipment_included')}</p>
                  {bike.available !== undefined && <p className="mt-3 flex items-center gap-2 text-sm font-medium text-foreground"><CheckCircle2 size={16} className="text-primary" />{bike.available} {t('rent_bike.available')}</p>}
                  <p className="mt-4 flex items-center gap-1 text-sm font-semibold text-primary group-hover:gap-2 transition-all">View details <ChevronRight size={14} /></p>
                </div>
              </div>
            </Link>)}
            <article className="flex flex-col self-start rounded-2xl border border-primary bg-secondary p-6 shadow-sm">
              <div>
                <Bike size={32} className="text-secondary-foreground" aria-hidden="true" />
                <h3 className="mt-6 font-heading text-2xl font-bold text-secondary-foreground">{t('rent_bike.special_request.title')}</h3>
                <p className="mt-4 text-sm leading-relaxed text-secondary-foreground">{t('rent_bike.special_request.description')}</p>
              </div>
              <Link to={`/${lang}/contact`} className="mt-8 inline-flex w-fit items-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-accent hover:text-accent-foreground">
                {t('rent_bike.special_request.cta')}<ChevronRight size={16} aria-hidden="true" />
              </Link>
            </article>
          </div>

          <div className="mt-12 overflow-x-auto rounded-2xl border border-border bg-card">
            <table className="w-full min-w-[720px] border-collapse text-left">
              <thead className="bg-muted"><tr><th className="p-5 font-semibold text-foreground">{t('rent_bike.columns.bike')}</th><th className="p-5 font-semibold text-foreground">{t('rent_bike.columns.one_day')}</th><th className="p-5 font-semibold text-foreground">{t('rent_bike.columns.three_days')}</th><th className="p-5 font-semibold text-foreground">{t('rent_bike.columns.seven_days')}</th><th className="p-5 font-semibold text-foreground">{t('rent_bike.columns.fifteen_days')}</th></tr></thead>
              <tbody>{bikes.map((bike) => <tr key={bike.id} className="border-t border-border"><th scope="row" className="p-5 font-medium text-foreground">{bikeLabel(bike, 'name')}</th><td className="p-5 text-muted-foreground">{price(bike.price_1day)}</td><td className="p-5 text-muted-foreground">{price(bike.price_3days)}</td><td className="p-5 text-muted-foreground">{price(bike.price_7days)}</td><td className="p-5 text-muted-foreground">{price(bike.price_15days)}</td></tr>)}</tbody>
            </table>
          </div>

          <section className="mt-12 rounded-2xl border border-border bg-muted p-6 md:p-8">
            <div className="flex flex-col gap-3 border-b border-border pb-6 md:flex-row md:items-center md:justify-between">
              <h2 className="font-heading text-2xl font-bold text-foreground">{t('rent_bike.conditions_title')}</h2>
              <p className="text-sm font-medium text-foreground">{t('rent_bike.insurance')}</p>
            </div>
            <ul className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
              {conditions.map((condition) => <li key={condition} className="flex gap-3 text-sm leading-relaxed text-muted-foreground"><CheckCircle2 size={18} className="mt-0.5 shrink-0 text-primary" />{condition}</li>)}
            </ul>
          </section>

          <section className="mt-16 flex flex-col items-start justify-between gap-6 rounded-2xl bg-secondary p-8 text-secondary-foreground md:flex-row md:items-center">
            <div><h2 className="font-heading text-2xl font-bold">{t('rent_bike.cta_title')}</h2><p className="mt-2 max-w-xl">{t('rent_bike.cta_text')}</p></div>
            <Link to={`/${lang}/contact`} className="inline-flex shrink-0 items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-transform hover:-translate-y-0.5">{t('rent_bike.cta_button')}<ChevronRight size={18} /></Link>
          </section>
        </div>
      </section>
    </main>
  </>;
}
