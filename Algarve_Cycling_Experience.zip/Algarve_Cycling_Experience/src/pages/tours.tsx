import React from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from "react-router";
import { motion } from 'motion/react';
import { Clock, MapPin, Users, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { tours } from 'virtual:content';
const site = 'https://algarveexperience.pl';
const difficultyColor: Record<string, string> = {
  Easy: 'bg-green-100 text-green-800 border-green-200',
  Moderate: 'bg-amber-100 text-amber-800 border-amber-200',
  Challenging: 'bg-red-100 text-red-800 border-red-200'
};
const tourImages = ['/airo-assets/images/pages/tours/tour-coastal-detail', '/airo-assets/images/pages/tours/tour-village-detail', '/airo-assets/images/pages/tours/tour-mountain-detail'];

export default function ToursPage(): React.ReactElement {
  const {
    t
  } = useTranslation();
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  return <>
      <Helmet>
        <title>Cycling Tours — Algarve Cycling Experience</title>
        <meta name="description" content="Tailor-made guided cycling tours in Algarve, Portugal. Coastal cliffs, mountain trails and village routes — premium bikes, expert guides and accommodation included. Request a quote." />
        <link rel="canonical" href={`${site}/tours`} />
        <meta property="og:title" content="Cycling Tours — Algarve Cycling Experience" />
        <meta property="og:description" content="Guided cycling tours along Portugal's Algarve coast. Choose your adventure." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${site}/tours`} />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/tours/intro-background`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Cycling Tours — Algarve Cycling Experience" />
        <meta name="twitter:description" content="Guided cycling tours along Portugal's Algarve coast. Choose your adventure." />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/tours/intro-background`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@graph': [{
            '@type': 'WebPage',
            '@id': `${site}/tours#webpage`,
            name: 'Tailor Made Cycling Tours — Algarve Cycling Experience',
            url: `${site}/tours`,
            isPartOf: { '@id': `${site}/#website` },
            about: { '@id': `${site}/#organization` },
            description: 'Tailor-made guided cycling tours in Algarve, Portugal. Coastal cliffs, mountain trails and village routes — premium bikes, expert guides and accommodation included.',
          }, {
            '@type': 'TouristTrip',
            '@id': `${site}/tours#touristtrip`,
            name: 'Tailor Made Cycling Tours — Algarve, Portugal',
            description: 'Custom guided cycling tours along the Algarve coast, mountains and villages. Coastal cliffs, mountain trails and whitewashed village routes with premium accommodation.',
            touristType: ['Cyclist', 'Sports Enthusiast', 'Adventure Traveller'],
            itinerary: {
              '@type': 'ItemList',
              itemListElement: [
                { '@type': 'ListItem', position: 1, name: 'Coastal Route — Algarve Cliffs & Atlantic Ocean' },
                { '@type': 'ListItem', position: 2, name: 'Mountain Route — Serra do Caldeirão Highlands' },
                { '@type': 'ListItem', position: 3, name: 'Village Route — Traditional Algarve Villages' },
              ]
            },
            provider: { '@id': `${site}/#organization` },
            url: `${site}/tours`,
          }]
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ── */}
        <section className="relative h-[52vh] min-h-[380px] flex items-end overflow-hidden">
          <div className="absolute inset-0">
            <img src="/airo-assets/images/pages/tours/hero" alt="Cyclists on the Algarve coast" className="w-full h-full object-cover" loading="eager" fetchPriority="high" width={1600} height={900} />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent pointer-events-none" />
          </div>
          <div className="relative z-10 container mx-auto px-6 pb-14">
            <motion.p initial={{
            opacity: 0,
            y: 12
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.5
          }} className="text-white/70 text-sm font-medium tracking-widest uppercase mb-3">
              {tours.hero.label}
            </motion.p>
            <motion.h1 initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.1
          }} className="font-heading text-5xl md:text-6xl font-bold text-white">
              {t('tours.hero.title')}
            </motion.h1>
            <motion.p initial={{
            opacity: 0,
            y: 16
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} className="text-white/75 text-lg mt-3 max-w-xl">
              {t('tours.hero.subtitle')}
            </motion.p>
          </div>
        </section>

        {/* ── INTRO / REGION BANNER ── */}
        <section className="relative py-28 overflow-hidden">
          <div className="absolute inset-0">
            <video src="/airo-assets/videos/pages/tours/intro-video" autoPlay muted loop playsInline className="w-full h-full object-cover object-top" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/40 to-black/20 pointer-events-none" />
          </div>
          <div className="relative z-10 container mx-auto px-6">
            <motion.div initial={{
            opacity: 0,
            x: -30
          }} whileInView={{
            opacity: 1,
            x: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.7,
            ease: 'easeOut'
          }} className="max-w-xl">
              <p className="text-white/70 text-sm font-medium tracking-widest uppercase mb-3">
                {t('tours.region.label', 'Algarve, Portugal')}
              </p>
              <h2 className="font-heading text-4xl md:text-5xl font-bold text-white mb-5 leading-tight">
                {t('tours.region.title', 'Three routes. One unforgettable region.')}
              </h2>
              <p className="text-white/80 text-lg leading-relaxed">
                {t('tours.region.description', 'From dramatic sea cliffs to hidden mountain villages — every route is designed to show you the real Algarve at the perfect pace.')}
              </p>
            </motion.div>
          </div>
        </section>

        {/* ── TOUR CARDS ── */}
        <section className="py-24 bg-background" id="packages">
          <div className="container mx-auto px-6">
            <div className="flex flex-col gap-16">
              {tours.tours.map((tour, i) => <motion.article key={tour.id} initial={{
              opacity: 0,
              y: 32
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.7,
              ease: 'easeOut'
            }} className={`grid grid-cols-1 lg:grid-cols-2 gap-0 rounded-2xl overflow-hidden border border-border shadow-sm hover:shadow-xl transition-shadow duration-300 ${i % 2 === 1 ? 'lg:[&>*:first-child]:order-2' : ''}`}>
                  {/* Image */}
                  <div className="relative overflow-hidden" style={{
                minHeight: '380px'
              }}>
                    <img src={tourImages[i]} alt={tour.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 hover:scale-105" loading="lazy" width={800} height={560} />
                    <div className="absolute top-5 left-5">
                      <span className={`text-xs font-semibold px-3 py-1.5 rounded-full border ${difficultyColor[tour.difficulty]}`}>
                        {tour.difficulty}
                      </span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="bg-card p-10 flex flex-col justify-between">
                    <div>
                      <p className="text-primary text-xs font-semibold tracking-widest uppercase mb-2">
                        {tour.tagline}
                      </p>
                      <h2 className="font-heading text-3xl font-bold text-foreground mb-4">
                        {tour.name}
                      </h2>
                      <p className="text-muted-foreground leading-relaxed mb-6">
                        {tour.description}
                      </p>

                      {/* Stats */}
                      <div className="grid grid-cols-3 gap-4 mb-6 py-5 border-y border-border">
                        <div className="flex flex-col items-center gap-1 text-center">
                          <Clock size={16} className="text-primary" />
                          <span className="text-xs text-muted-foreground">{t('tours.stats.duration')}</span>
                          <span className="text-sm font-semibold text-foreground">{tour.duration}</span>
                        </div>
                        <div className="flex flex-col items-center gap-1 text-center">
                          <MapPin size={16} className="text-primary" />
                          <span className="text-xs text-muted-foreground">{t('tours.stats.distance')}</span>
                          <span className="text-sm font-semibold text-foreground">{tour.distance}</span>
                        </div>
                        <div className="flex flex-col items-center gap-1 text-center">
                          <Users size={16} className="text-primary" />
                          <span className="text-xs text-muted-foreground">{t('tours.stats.groupSize')}</span>
                          <span className="text-sm font-semibold text-foreground">{tour.group_size}</span>
                        </div>
                      </div>

                      {/* Highlights */}
                      <ul className="flex flex-col gap-2 mb-8">
                        {tour.highlights.map((h, hi) => <li key={hi} className="flex items-center gap-2 text-sm text-foreground/80">
                            <ChevronRight size={14} className="text-primary shrink-0" />
                            <span>{h}</span>
                          </li>)}
                      </ul>
                    </div>

                    {/* CTA */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-4 border-t border-border">
                      <Link to={`/${lang}/contact`} className="inline-flex items-center gap-2 px-7 py-3.5 bg-primary text-white font-semibold rounded-full hover:bg-primary/90 transition-all duration-200 hover:shadow-md hover:-translate-y-0.5 whitespace-nowrap">
                        {t('tours.askForPrice')}
                      </Link>
                    </div>
                  </div>
                </motion.article>)}
            </div>
          </div>
        </section>



        {/* ── CTA ── */}
        <section className="py-20 bg-primary">
          <div className="container mx-auto px-6 text-center">
            <motion.h2 initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6
          }} className="font-heading text-4xl md:text-5xl font-bold text-white mb-4">
              {t('tours.cta.title')}
            </motion.h2>
            <motion.p initial={{
            opacity: 0,
            y: 16
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.1
          }} className="text-white/80 text-lg mb-10 max-w-xl mx-auto">
              {t('tours.cta.subtitle')}
            </motion.p>
            <motion.div initial={{
            opacity: 0,
            y: 12
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.2
          }}>
              <Link to={`/${lang}/contact`} className="inline-flex items-center px-10 py-4 bg-white text-primary font-bold rounded-full text-lg hover:bg-white/90 transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5">
                {t('tours.cta.button')}
              </Link>
            </motion.div>
          </div>
        </section>
      </main>
    </>;
}
