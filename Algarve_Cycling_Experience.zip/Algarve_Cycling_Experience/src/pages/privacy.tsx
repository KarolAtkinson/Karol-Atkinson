import { Helmet } from '@dr.pogodin/react-helmet';
import { useParams } from 'react-router';
import { useTranslation } from 'react-i18next';

const site = 'https://algarvecycling.com';
type LegalSection = { heading: string; body: string };

export default function PrivacyPage() {
  const { lang = 'en' } = useParams<{ lang: string }>();
  const { t } = useTranslation();
  const url = `${site}/${lang}/privacy`;
  const title = `${t('legal.privacy_title')} | Algarve Cycling`;
  const description = t('legal.privacy_description');
  const sections = t('legal.privacy_sections', { returnObjects: true }) as LegalSection[];
  const jsonLd = { '@context': 'https://schema.org', '@type': 'WebPage', '@id': `${url}#webpage`, name: title, url, isPartOf: { '@id': `${site}/#website` }, about: { '@id': `${site}/#organization` } };

  return <><Helmet><title>{title}</title><meta name="description" content={description} /><link rel="canonical" href={url} /><meta property="og:title" content={title} /><meta property="og:description" content={description} /><meta property="og:type" content="website" /><meta property="og:url" content={url} /><meta property="og:image" content={`${site}/airo-assets/images/pages/home/tour-coastal`} /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content={title} /><meta name="twitter:description" content={description} /><meta name="twitter:image" content={`${site}/airo-assets/images/pages/home/tour-coastal`} /><script type="application/ld+json">{JSON.stringify(jsonLd)}</script></Helmet><main className="container mx-auto px-6 py-16 md:py-24"><article className="mx-auto max-w-3xl"><p className="mb-4 text-sm text-muted-foreground"><span>{t('legal.last_updated')} </span><time dateTime="2026-09-02">{t('legal.last_updated_date')}</time></p><h1 className="text-4xl font-bold tracking-tight text-foreground md:text-5xl">{t('legal.privacy_title')}</h1><p className="mt-6 text-lg leading-relaxed text-muted-foreground">{t('legal.privacy_intro')}</p><div className="mt-12 flex flex-col gap-10">{sections.map((section) => <section key={section.heading}><h2 className="text-2xl font-semibold text-foreground">{section.heading}</h2><p className="mt-3 text-base leading-relaxed text-muted-foreground">{section.body}</p></section>)}</div></article></main></>;
}
