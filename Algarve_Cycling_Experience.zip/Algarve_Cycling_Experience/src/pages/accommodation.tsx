import { Helmet } from '@dr.pogodin/react-helmet';
import { useParams } from 'react-router';
import { motion } from 'motion/react';
import { Bed, Coffee, Lock, Wifi, Utensils, MapPin, CheckCircle, Waves, Bike, Plane, Umbrella, Trophy, Users, Home } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { accommodation } from 'virtual:content';
const iconMap: Record<string, React.ReactElement> = {
  Bed: <Bed size={20} />,
  Coffee: <Coffee size={20} />,
  Lock: <Lock size={20} />,
  Wifi: <Wifi size={20} />,
  Utensils: <Utensils size={20} />,
  MapPin: <MapPin size={20} />,
  Waves: <Waves size={20} />,
  Bike: <Bike size={20} />,
  Plane: <Plane size={20} />,
  Umbrella: <Umbrella size={20} />,
  Trophy: <Trophy size={20} />,
  Users: <Users size={20} />,
  Home: <Home size={20} />
};
const site = 'https://algarveexperience.pl';
const url = `${site}/accommodation`;
const title = 'Accommodation — Algarve Cycling Experience';
const description = 'Stay at Villa Faro — exclusive private villa for groups up to 10, or book individual rooms. Pool, garden, cycling path at the door, 5 min from Faro Airport.';
export default function AccommodationPage() {
  const {
    t
  } = useTranslation();
  const { lang = 'en' } = useParams<{lang: string;}>();
  return <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/accommodation/villa-faro-pool`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/accommodation/villa-faro-pool`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'WebPage',
          '@id': `${url}#webpage`,
          name: title,
          url,
          isPartOf: { '@id': `${site}/#website` },
          about: { '@id': `${site}/#organization` },
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative h-[65vh] min-h-[480px] overflow-hidden">
          <img src="/airo-assets/images/pages/accommodation/villa-faro-exterior" alt="Villa Faro — private pool and garden in Faro, Algarve" className="absolute inset-0 w-full h-full object-cover" loading="eager" fetchPriority="high" width={1920} height={900} />
          
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/20 via-gray-900/40 to-gray-900/75 pointer-events-none" />
          <div className="relative h-full flex items-end pb-16 pointer-events-none">
            <div className="container mx-auto px-6">
              <motion.div initial={{
              opacity: 0,
              y: 30
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.7,
              ease: 'easeOut'
            }}>
                
                <p className="text-white/70 text-sm font-medium tracking-widest uppercase mb-3">
                  {t('accommodation.hero.eyebrow')}
                </p>
                <h1 className="font-heading text-4xl md:text-6xl text-white max-w-3xl leading-tight mb-4">
                  {t('accommodation.hero.title')}
                </h1>
                <p className="text-white/80 text-lg max-w-xl leading-relaxed">
                  {t('accommodation.hero.subtitle')}
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── VILLA FARO — Featured property ── */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-6">

            {/* Header */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            ease: 'easeOut'
          }} className="mb-14">
              
              <span className="inline-block text-xs font-semibold tracking-widest uppercase text-primary bg-primary/10 px-3 py-1.5 rounded-full mb-4">
                {t('accommodation.villa.eyebrow')}
              </span>
              <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
                <div>
                  <h2 className="font-heading text-4xl md:text-5xl text-foreground mb-2">
                    {accommodation.villa.name}
                  </h2>
                  <p className="font-heading text-xl text-muted-foreground italic">
                    {accommodation.villa.tagline}
                  </p>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground text-sm">
                  <MapPin size={14} className="text-primary shrink-0" />
                  <span>{accommodation.villa.location}</span>
                </div>
              </div>
            </motion.div>

            {/* Photo grid */}
            <motion.div initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            ease: 'easeOut'
          }} className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-14">
              
              <img src="/airo-assets/images/pages/accommodation/villa-faro-pool" alt="Villa Faro — private pool" className="w-full h-[320px] md:h-[420px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={560} />
              
              <>
                <img src="/airo-assets/images/pages/accommodation/villa-faro-exterior" alt="Villa Faro — exterior and garden" className="w-full h-[320px] md:h-[420px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={560} />
                
                






                
              </>
            </motion.div>

            {/* Villa bedroom gallery */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            ease: 'easeOut'
          }} className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-14">
              <img src="/airo-assets/images/pages/accommodation/villa-faro-bedroom-terrace" alt="Villa Faro bedroom with a sunny private terrace" className="w-full h-[280px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={600} />
              <img src="/airo-assets/images/pages/accommodation/villa-faro-bedroom-ensuite" alt="Villa Faro double bedroom with en-suite bathroom" className="w-full h-[280px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={600} />
              <img src="/airo-assets/images/pages/accommodation/villa-faro-bedroom-workspace" alt="Villa Faro double bedroom with workspace" className="w-full h-[280px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={600} />
              <img src="/airo-assets/images/pages/accommodation/villa-faro-bedroom-skylight" alt="Villa Faro attic bedroom with skylight" className="w-full h-[280px] object-cover rounded-2xl shadow-md" loading="lazy" width={800} height={600} />
            </motion.div>

            {/* Description + size */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            ease: 'easeOut'
          }} className="max-w-3xl mb-14">
              
              <p className="text-sm font-semibold text-muted-foreground mb-3 tracking-wide">
                {accommodation.villa.size}
              </p>
              <p className="text-foreground text-lg leading-relaxed">
                {accommodation.villa.description}
              </p>
            </motion.div>

            {/* Two booking options */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-14">
              {/* Exclusive hire */}
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              ease: 'easeOut'
            }} className="rounded-2xl border-2 border-primary bg-primary/5 p-8">
                
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shrink-0">
                    <Users size={18} />
                  </div>
                  <h3 className="font-heading text-xl text-foreground">
                    {accommodation.villa.optionExclusive.label}
                  </h3>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {accommodation.villa.optionExclusive.description}
                </p>
              </motion.div>

              {/* Room by room */}
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5,
              ease: 'easeOut',
              delay: 0.1
            }} className="rounded-2xl border border-border bg-card p-8">
                
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-muted text-foreground flex items-center justify-center shrink-0">
                    <Bed size={18} />
                  </div>
                  <h3 className="font-heading text-xl text-foreground">
                    {accommodation.villa.optionRooms.label}
                  </h3>
                </div>
                <p className="text-muted-foreground leading-relaxed">
                  {accommodation.villa.optionRooms.description}
                </p>
              </motion.div>
            </div>

            {/* Highlights grid */}
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            ease: 'easeOut'
          }}>
              
              <h3 className="font-heading text-2xl text-foreground mb-6">{t('legal.villa_highlights')}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {accommodation.villa.highlights.map((h: typeof accommodation.villa.highlights[number], i: number) => <motion.div key={h.id} initial={{
                opacity: 0,
                y: 16
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.4,
                ease: 'easeOut',
                delay: i * 0.05
              }} className="flex flex-col items-center text-center gap-3 bg-muted/30 rounded-xl p-5 border border-border">
                  
                    <div className="w-11 h-11 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                      {iconMap[h.icon] ?? <CheckCircle size={20} />}
                    </div>
                    <span className="text-sm font-medium text-foreground leading-snug">
                      {h.label}
                    </span>
                  </motion.div>)}
              </div>
            </motion.div>
          </div>
        </section>

        {/* ── VILA GALÉ AMPALIUS ── */}
        <section className="py-24 bg-muted">
          <div className="container mx-auto px-6">
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, ease: 'easeOut' }} className="mb-12">
              <span className="inline-block rounded-full bg-primary px-3 py-1.5 text-xs font-semibold tracking-wide text-primary-foreground mb-4">
                {accommodation.vilaGale.eyebrow}
              </span>
              <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
                <div>
                  <h2 className="font-heading text-4xl md:text-5xl text-foreground mb-2">{accommodation.vilaGale.name}</h2>
                  <p className="font-heading text-xl italic text-muted-foreground">{accommodation.vilaGale.tagline}</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin size={14} className="text-primary shrink-0" />
                  <span>{accommodation.vilaGale.location}</span>
                </div>
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, ease: 'easeOut' }} className="grid grid-cols-1 gap-4 md:grid-cols-2 mb-10">
              <img src="/airo-assets/images/pages/accommodation/vila-gale-ampalius-sea-view-room" alt="Vila Galé Ampalius room with balcony and sea view" className="h-[320px] w-full rounded-2xl object-cover shadow-md" loading="lazy" width={900} height={600} />
              <img src="/airo-assets/images/pages/accommodation/vila-gale-ampalius-pool-bar" alt="Vila Galé Ampalius poolside bar and terrace" className="h-[320px] w-full rounded-2xl object-cover shadow-md" loading="lazy" width={900} height={600} />
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, ease: 'easeOut' }} className="grid grid-cols-1 gap-4 md:grid-cols-3 mb-12">
              <img src="/airo-assets/images/pages/accommodation/vila-gale-ampalius-standard-room" alt="Vila Galé Ampalius standard room with balcony" className="h-[220px] w-full rounded-2xl object-cover shadow-md" loading="lazy" width={700} height={460} />
              <img src="/airo-assets/images/pages/accommodation/vila-gale-ampalius-ocean-pool" alt="Vila Galé Ampalius outdoor pool near the ocean" className="h-[220px] w-full rounded-2xl object-cover shadow-md" loading="lazy" width={700} height={460} />
              <img src="/airo-assets/images/pages/accommodation/vila-gale-ampalius-junior-suite-balcony" alt="Vila Galé Ampalius junior suite balcony overlooking the sea" className="h-[220px] w-full rounded-2xl object-cover shadow-md" loading="lazy" width={700} height={460} />
            </motion.div>

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1.25fr_0.75fr] lg:items-start">
              <div>
                <p className="text-lg leading-relaxed text-foreground">{accommodation.vilaGale.description}</p>
                <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
                  {accommodation.vilaGale.features.map((feature: typeof accommodation.vilaGale.features[number]) => <div key={feature.id} className="flex flex-col items-center gap-3 rounded-xl border border-border bg-card p-4 text-center">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">{iconMap[feature.icon] ?? <CheckCircle size={20} />}</div>
                    <span className="text-sm font-medium leading-snug text-foreground">{feature.label}</span>
                  </div>)}
                </div>
              </div>
              <aside className="rounded-2xl border-2 border-primary bg-card p-8 shadow-sm">
                <p className="text-sm font-semibold text-muted-foreground mb-2">{t('legal.room_rates')}</p>
                <p className="font-heading text-3xl text-foreground mb-4">{accommodation.vilaGale.price}</p>
                <p className="text-sm leading-relaxed text-muted-foreground">{t('legal.room_rates_note')}</p>
              </aside>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-6 text-center">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.6,
            ease: 'easeOut'
          }}>
              
              <h2 className="text-2xl font-heading text-foreground mb-4">Ready to book your stay? Contact us via email <a className="text-primary underline decoration-primary underline-offset-4 transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" href={`/${lang}/contact`}>info@algarveexperience.pl</a>
            </h2>
            </motion.div>
          </div>
        </section>
      </main>
    </>;
}