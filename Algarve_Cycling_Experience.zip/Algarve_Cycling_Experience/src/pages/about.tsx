import { Helmet } from '@dr.pogodin/react-helmet';
import { useParams } from "react-router";
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { about } from 'virtual:content';
const site = 'https://algarveexperience.pl';
const url = `${site}/about`;
const title = 'About Us — Algarve Cycling Experience';
const description = 'Meet Aneta, founder of Algarve Cycling Experience. A story of early morning rides, house music, and a passion for sharing Portugal\'s finest cycling roads with the world.';
export default function AboutPage() {
  const {
    t
  } = useTranslation();
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  return <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/about/hero`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={title} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/about/hero`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@type': 'AboutPage',
          '@id': `${url}#webpage`,
          name: title,
          url,
          isPartOf: { '@id': `${site}/#website` },
          about: { '@id': `${site}/#organization` },
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── Zespół: Aneta i Ela — spójna siatka ── */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-6 max-w-5xl">

            {/* Nagłówek sekcji */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="text-center mb-16"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">
                {lang === 'pl' ? 'Nasz zespół' : lang === 'ar' ? 'فريقنا' : 'Our team'}
              </p>
              <h1 className="font-heading text-4xl md:text-5xl text-foreground">
                {lang === 'pl' ? 'Ludzie za Algarve Cycling' : lang === 'ar' ? 'الأشخاص وراء Algarve Cycling' : 'The people behind Algarve Cycling'}
              </h1>
            </motion.div>

            {/* Karta — Aneta */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="flex flex-col md:flex-row items-start gap-10 mb-16 pb-16 border-b border-border"
            >
              {/* Zdjęcie + badge */}
              <div className="shrink-0 flex flex-col items-center gap-4 w-40">
                <div className="w-40 h-40 rounded-full border-4 border-primary/40 overflow-hidden shadow-xl">
                  <img
                    src="/airo-assets/images/pages/about/founder"
                    alt="Aneta Piątek Ribeiro, founder of Algarve Cycling Portugal"
                    className="w-full h-full object-cover object-top"
                    loading="lazy"
                    width={160}
                    height={160}
                  />
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl px-3 py-2 shadow flex items-center gap-2 w-full justify-center">
                  <span className="text-lg">🇵🇱</span>
                  <p className="text-xs text-muted-foreground leading-tight">{t('legal.founder_badge')}</p>
                </div>
              </div>

              {/* Tekst */}
              <div className="flex-1 pt-2">
                <p className="text-primary text-xs font-semibold tracking-widest uppercase mb-2">
                  {lang === 'pl' ? 'Założycielka' : lang === 'ar' ? 'المؤسسة' : 'Founder'}
                </p>
                <h3 className="font-heading text-3xl text-foreground mb-1">{about.founder.name}</h3>
                <p className="text-muted-foreground text-sm font-medium tracking-wide mb-5">{about.founder.role}</p>

                <div className="flex flex-col gap-4">
                  <p className="text-muted-foreground text-base leading-relaxed">{about.story.chapter1.body1}</p>
                  <p className="text-muted-foreground text-base leading-relaxed">{about.story.chapter1.body2}</p>
                  <p className="text-muted-foreground text-base leading-relaxed">{about.story.chapter2.body1}</p>
                  <div className="border-l-4 border-primary pl-4 py-1">
                    <p className="text-foreground font-medium text-base italic leading-relaxed">{about.story.chapter2.body2}</p>
                  </div>
                  <p className="text-muted-foreground text-base leading-relaxed">{about.story.chapter3.body1}</p>
                  <p className="text-muted-foreground text-base leading-relaxed">{about.story.chapter3.body2}</p>
                </div>

                <div className="pt-5 mt-5 border-t border-border">
                  <p className="text-primary text-xl leading-snug" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 600 }}>
                    {about.founder.sign_off}
                  </p>
                  <p className="text-foreground text-3xl leading-none" style={{ fontFamily: "'Dancing Script', cursive", fontWeight: 600 }}>
                    {about.founder.name}
                  </p>
                </div>
              </div>
            </motion.div>

            {/* Karta — Elżbieta */}
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
              className="flex flex-col md:flex-row items-start gap-10"
            >
              {/* Zdjęcie */}
              <div className="shrink-0 flex flex-col items-center gap-4 w-40">
                <div className="w-40 h-40 rounded-full border-4 border-primary/40 overflow-hidden shadow-xl">
                  <img
                    src="/airo-assets/images/pages/about/team-ela-atkinson"
                    alt="Elżbieta Atkinson — Tour Leader"
                    className="w-full h-full object-cover object-top"
                    loading="lazy"
                    width={160}
                    height={160}
                  />
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl px-3 py-2 shadow flex items-center gap-2 w-full justify-center">
                  <span className="text-lg">🇵🇱</span>
                  <p className="text-xs text-muted-foreground leading-tight">{t('legal.team_badge')}</p>
                </div>
              </div>

              {/* Bio */}
              <div className="flex-1 pt-2">
                <p className="text-primary text-xs font-semibold tracking-widest uppercase mb-2">
                  {lang === 'pl' ? 'Członek zespołu' : lang === 'ar' ? 'عضو الفريق' : 'Team member'}
                </p>
                <h3 className="font-heading text-3xl text-foreground mb-1">{about.team_member.name}</h3>
                <p className="text-muted-foreground text-sm font-medium tracking-wide mb-5">
                  {lang === 'pl' ? about.team_member.role_pl : about.team_member.role_en}
                </p>
                <p className="text-muted-foreground text-base leading-relaxed">
                  {lang === 'pl' ? about.team_member.bio_pl : about.team_member.bio_en}
                </p>
              </div>
            </motion.div>

          </div>
        </section>

      </main>
    </>;
}
