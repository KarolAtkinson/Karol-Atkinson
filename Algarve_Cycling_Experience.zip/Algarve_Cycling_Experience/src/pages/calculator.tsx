import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router';
import { calculator } from 'virtual:content';
import StayCalculator from '@/components/StayCalculator';

export default function CalculatorPage() {
  const { t } = useTranslation();
  const { lang = 'en' } = useParams<{ lang: string }>();

  const site = 'https://algarvecycling.com';
  const url = `${site}/${lang}/calculator`;
  const title = lang === 'pl'
    ? 'Kalkulator Kosztów Pobytu — Algarve Cycling Experience'
    : 'Stay Cost Calculator — Algarve Cycling Experience';
  const description = lang === 'pl'
    ? 'Oblicz orientacyjny koszt swojej wycieczki rowerowej w Algarve. Wybierz daty, rodzaj roweru i dodatki — natychmiastowa wycena.'
    : 'Calculate the estimated cost of your Algarve cycling trip. Choose dates, bike type and add-ons — instant estimate.';

  return (
    <>
      <Helmet>
        <title>{title}</title>
        <meta name="description" content={description} />
        <link rel="canonical" href={url} />
        <meta property="og:title" content={title} />
        <meta property="og:description" content={description} />
        <meta property="og:url" content={url} />
        <meta property="og:type" content="website" />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* ── HERO ── */}
        <section className="relative min-h-[42vh] flex items-end pb-16 overflow-hidden">
          <div className="absolute inset-0">
            <img
              src="/airo-assets/images/pages/tours/hero"
              alt="Cyclist on Algarve road"
              className="w-full h-full object-cover"
              loading="eager"
              fetchPriority="high"
              width={1600}
              height={700}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/70 pointer-events-none" />
          </div>

          <div className="relative z-10 container mx-auto px-6 pt-36">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-white/70 text-sm font-medium tracking-widest uppercase mb-3"
            >
              {t('calculator.hero.eyebrow')}
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-heading text-4xl md:text-6xl font-bold text-white max-w-2xl leading-tight mb-4"
            >
              {t('calculator.hero.title')}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-white/80 text-lg max-w-xl leading-relaxed"
            >
              {t('calculator.hero.subtitle')}
            </motion.p>
          </div>
        </section>

        {/* ── CALCULATOR ── */}
        <section className="py-20 bg-background">
          <div className="container mx-auto px-6">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <StayCalculator
                content={{
                  bike_types: calculator.bike_types,
                  extras: calculator.extras,
                  base_price_per_day: calculator.base_price_per_day,
                  accommodation_per_night: calculator.accommodation_per_night,
                }}
              />
            </motion.div>

            {/* Disclaimer note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="text-center text-xs text-muted-foreground mt-10 max-w-lg mx-auto leading-relaxed"
            >
              {calculator.disclaimer}
            </motion.p>
          </div>
        </section>
      </main>
    </>
  );
}
