import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from "react-router";
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { home } from 'virtual:content';
const site = 'https://algarveexperience.pl';
const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [{
    '@type': 'WebSite',
    '@id': `${site}/#website`,
    name: 'Algarve Cycling Experience',
    url: `${site}/`,
    potentialAction: {
      '@type': 'SearchAction',
      target: `${site}/en/tours?q={search_term_string}`,
      'query-input': 'required name=search_term_string'
    }
  }, {
    '@type': ['Organization', 'SportsActivityLocation'],
    '@id': `${site}/#organization`,
    name: 'Algarve Cycling Experience',
    url: `${site}/`,
    logo: `${site}/airo-assets/images/logo/horizontal`,
    image: `${site}/airo-assets/images/pages/home/hero`,
    address: {
      '@type': 'PostalAddress',
      addressRegion: 'Algarve',
      addressCountry: 'PT'
    },
    telephone: '+351911826188',
    email: 'info@algarveexperience.pl',
    sameAs: [
      'https://www.instagram.com/algarveexperience',
      'https://www.facebook.com/algarveexperience'
    ],
    sport: 'Cycling'
  }, {
    '@type': 'WebPage',
    '@id': `${site}/#webpage`,
    url: `${site}/`,
    name: 'Algarve Cycling Experience — Guided Cycling Tours & Training Camps in Portugal',
    isPartOf: {
      '@id': `${site}/#website`
    },
    about: {
      '@id': `${site}/#organization`
    },
    datePublished: '2026-07-12',
    dateModified: '2026-10-05'
  }]
};
const difficultyColor: Record<string, string> = {
  Easy: 'bg-green-100 text-green-800',
  Moderate: 'bg-amber-100 text-amber-800',
  Challenging: 'bg-red-100 text-red-800'
};
const tourImages = ['/airo-assets/images/pages/home/tour-coastal', '/airo-assets/images/pages/home/tour-village', '/airo-assets/images/pages/home/tour-mountains'];
export default function HomePage() {
  const {
    t
  } = useTranslation();
  const {
    lang = 'en'
  } = useParams<{
    lang: string;
  }>();
  return <>
      <Helmet>
        <title>Algarve Cycling Experience — Cycling Tours & Training Camps in Algarve, Portugal</title>
        <meta name="description" content="Guided cycling tours, cycling camps and triathlon training camps in Algarve, Portugal. Premium bikes, expert coaches, private villa accommodation. Small groups, max 8 athletes." />
        
        <link rel="canonical" href={`${site}/${lang}`} />
        <meta property="og:title" content="Algarve Cycling Experience" />
        <meta property="og:description" content="Guided cycling tours along Portugal's most spectacular coastline — with handpicked accommodation included." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={site} />
        <meta property="og:image" content={`${site}/airo-assets/images/pages/home/hero`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Algarve Cycling Experience" />
        <meta name="twitter:description" content="Guided cycling tours along Portugal's most spectacular coastline." />
        <meta name="twitter:image" content={`${site}/airo-assets/images/pages/home/hero`} />
        <script type="application/ld+json">{JSON.stringify(jsonLd).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ── */}
        <section className="relative h-screen min-h-[600px] flex items-center overflow-hidden">
          {/* Background image with subtle parallax feel */}
          <div className="absolute inset-0">
            <img src="/airo-assets/images/pages/home/hero" alt="Cyclist riding along the Algarve coastal cliffs" className="w-full h-full object-cover" loading="eager" fetchPriority="high" width={1920} height={1080} />
            
            {/* Warm terracotta overlay */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#C4622D]/55 via-[#C4622D]/30 to-transparent pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
          </div>

          {/* Content */}
          <div className="relative z-10 container mx-auto px-6">
            <div className="max-w-2xl">
              <motion.h1 initial={{
              opacity: 0,
              y: 24
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.7,
              delay: 0.1,
              ease: 'easeOut'
            }} className="font-heading text-6xl md:text-7xl lg:text-8xl font-black text-white leading-[0.95] mb-6" style={{
              color: "#ffffff"
            }}>
                
                <span>{t('home.hero.headline_line1')}</span>
                <br />
                <span className="text-[#F5C842]">{t('home.hero.headline_line2')}</span>
              </motion.h1>

              <motion.p initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.7,
              delay: 0.25,
              ease: 'easeOut'
            }} className="text-white/85 text-lg md:text-xl leading-relaxed mb-10 max-w-lg">
                
                {t('home.hero.tagline')}
              </motion.p>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.6,
              delay: 0.4,
              ease: 'easeOut'
            }} className="flex flex-wrap gap-4">
                
                <Link to={`/${lang}/cycling-camp`} className="inline-flex items-center px-8 py-4 bg-primary text-white font-semibold rounded-full hover:bg-primary/90 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 text-base">
                  
                  {t('home.hero.cta_primary')}
                </Link>
                <Link to={`/${lang}/tours`} className="inline-flex items-center px-8 py-4 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-foreground transition-all duration-200 text-base">
                  
                  {t('home.hero.cta_secondary')}
                </Link>
              </motion.div>
            </div>
          </div>

          {/* Scroll indicator */}
          <motion.div initial={{
          opacity: 0
        }} animate={{
          opacity: 1
        }} transition={{
          delay: 1.2,
          duration: 0.6
        }} className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/60 pointer-events-none">
            
            <span className="text-xs tracking-widest uppercase">{t('home.scroll')}</span>
            <motion.div animate={{
            y: [0, 6, 0]
          }} transition={{
            duration: 1.6,
            repeat: Infinity,
            ease: 'easeInOut'
          }}>
              
              <ChevronDown size={18} />
            </motion.div>
          </motion.div>
        </section>

        {/* ── FEATURED TOURS ── */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-6">
            <div className="mb-14">
              <motion.p initial={{
              opacity: 0,
              y: 12
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5
            }} className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">
                
                {t('home.tours.section_label')}
              </motion.p>
              <motion.h2 initial={{
              opacity: 0,
              y: 16
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.1
            }} className="font-heading text-4xl md:text-5xl font-bold text-foreground">
                
                {t('home.tours.section_title')}
              </motion.h2>
            </div>

            {/* Bento grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Large hero card */}
              {home.tours.items.slice(0, 1).map((tour, i) => <motion.div key={tour.id} initial={{
              opacity: 0,
              y: 24
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: i * 0.1
            }} className="md:row-span-2 group relative rounded-2xl overflow-hidden cursor-pointer" style={{
              minHeight: '520px'
            }}>
                
                  <img src={tourImages[0]} alt={tour.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" width={800} height={600} />
                
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent pointer-events-none" />
                  <div className="absolute inset-0 p-8 flex flex-col justify-end pointer-events-none">
                    <span className={`self-start text-xs font-semibold px-3 py-1 rounded-full mb-3 ${difficultyColor[tour.difficulty]}`}>
                      {tour.difficulty}
                    </span>
                    <h3 className="font-heading text-3xl font-bold text-white mb-2">{tour.name}</h3>
                    <p className="text-white/80 text-sm leading-relaxed mb-4">{tour.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70 text-sm">{tour.duration}</span>
                      {tour.price && <span className="text-[#F5C842] font-bold text-lg">{tour.price}</span>}
                    </div>
                  </div>
                  <div className="absolute inset-0 ring-2 ring-primary/0 group-hover:ring-primary/40 rounded-2xl transition-all duration-300 pointer-events-none" />
                </motion.div>)}

              {/* Two smaller cards */}
              {home.tours.items.slice(1).map((tour, i) => <motion.div key={tour.id} initial={{
              opacity: 0,
              y: 24
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: (i + 1) * 0.15
            }} className="group relative rounded-2xl overflow-hidden cursor-pointer" style={{
              minHeight: '248px'
            }}>
                
                  <img src={tourImages[i + 1]} alt={tour.name} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" width={600} height={400} />
                
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent pointer-events-none" />
                  <div className="absolute inset-0 p-6 flex flex-col justify-end pointer-events-none">
                    <span className={`self-start text-xs font-semibold px-3 py-1 rounded-full mb-2 ${difficultyColor[tour.difficulty]}`}>
                      {tour.difficulty}
                    </span>
                    <h3 className="font-heading text-xl font-bold text-white mb-1">{tour.name}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-white/70 text-sm">{tour.duration}</span>
                      {tour.price && <span className="text-[#F5C842] font-semibold">{tour.price}</span>}
                    </div>
                  </div>
                  <div className="absolute inset-0 ring-2 ring-primary/0 group-hover:ring-primary/40 rounded-2xl transition-all duration-300 pointer-events-none" />
                </motion.div>)}
            </div>

            <motion.div initial={{
            opacity: 0,
            y: 12
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} transition={{
            duration: 0.5,
            delay: 0.3
          }} className="mt-10 text-center">
              
              <Link to={`/${lang}/tours`} className="inline-flex items-center gap-2 px-8 py-4 border-2 border-primary text-primary font-semibold rounded-full hover:bg-primary hover:text-white transition-all duration-200">
                
                {t('home.tours.viewAll')}
              </Link>
            </motion.div>
          </div>
        </section>

        {/* ── WHY CHOOSE US ── */}
        <section className="py-24 bg-muted overflow-hidden">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 items-stretch">
              {/* Photo — bleeds into text column */}
              <motion.div initial={{
              opacity: 0,
              x: -30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.8,
              ease: 'easeOut'
            }} className="relative rounded-2xl lg:rounded-r-none overflow-hidden" style={{
              minHeight: '560px'
            }}>
                
                <img src="/airo-assets/images/pages/home/why-us-photo" alt="Group of cyclists on a guided tour in Portugal" className="absolute inset-0 w-full h-full object-cover" loading="lazy" width={700} height={900} />
                
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-muted/30 pointer-events-none" />
              </motion.div>

              {/* Text */}
              <motion.div initial={{
              opacity: 0,
              x: 30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.8,
              ease: 'easeOut',
              delay: 0.1
            }} className="bg-background lg:rounded-r-2xl p-10 lg:p-14 flex flex-col justify-center">
                
                <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">
                  {t('home.why_us.section_label')}
                </p>
                <h2 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-4">
                  {t('home.why_us.section_title')}
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed mb-10">
                  {t('home.why_us.intro')}
                </p>

                <div className="flex flex-col gap-8">
                  {home.why_us.points.map((point, i) => <motion.div key={point.id} initial={{
                  opacity: 0,
                  y: 16
                }} whileInView={{
                  opacity: 1,
                  y: 0
                }} viewport={{
                  once: true
                }} transition={{
                  duration: 0.5,
                  delay: i * 0.1
                }} className="flex gap-5">
                    
                      <div className="w-1 shrink-0 rounded-full bg-primary mt-1" style={{
                    minHeight: '100%'
                  }} />
                      <div>
                        <h3 className="font-heading text-lg font-bold text-foreground mb-1">
                          {point.title}
                        </h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">
                          {point.description}
                        </p>
                      </div>
                    </motion.div>)}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── WOMEN ONLY ── */}
        <section className="py-24 bg-background overflow-hidden">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">

              {/* Photo */}
              <motion.div initial={{
              opacity: 0,
              x: -30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.8,
              ease: 'easeOut'
            }} className="relative rounded-3xl overflow-hidden" style={{
              minHeight: '500px'
            }}>
                <img src="/airo-assets/images/pages/home/women-cycling-group" alt="Women cycling group in Algarve Portugal" className="absolute inset-0 w-full h-full object-cover" loading="lazy" width={800} height={600} />
                {/* Badge overlay */}
                <div className="absolute top-6 left-6">
                  <span className="inline-flex items-center gap-2 bg-white/95 backdrop-blur-sm text-[#C8622A] text-xs font-bold px-4 py-2 rounded-full shadow-md tracking-wide uppercase">
                    <span className="w-2 h-2 rounded-full bg-[#C8622A] inline-block" />
                    {t('home.women_only.badge')}
                  </span>
                </div>
              </motion.div>

              {/* Text */}
              <motion.div initial={{
              opacity: 0,
              x: 30
            }} whileInView={{
              opacity: 1,
              x: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.8,
              ease: 'easeOut',
              delay: 0.1
            }}>

                <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">
                  {t('home.women_only.subheadline')}
                </p>
                <h2 className="font-heading text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
                  {t('home.women_only.headline')}
                </h2>
                <p className="text-muted-foreground text-lg leading-relaxed mb-10">
                  {t('home.women_only.description')}
                </p>

                {/* 3 highlights */}
                <div className="flex flex-col gap-6 mb-10">
                  {[{
                  title: t('home.women_only.highlight_1_title'),
                  desc: t('home.women_only.highlight_1_desc'),
                  icon: '♀'
                }, {
                  title: t('home.women_only.highlight_2_title'),
                  desc: t('home.women_only.highlight_2_desc'),
                  icon: '🌙'
                }].map((item, i) => <motion.div key={i} initial={{
                  opacity: 0,
                  y: 12
                }} whileInView={{
                  opacity: 1,
                  y: 0
                }} viewport={{
                  once: true
                }} transition={{
                  duration: 0.5,
                  delay: 0.2 + i * 0.1
                }} className="flex gap-4 items-start">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-primary font-bold text-base">
                        {item.icon}
                      </div>
                      <div>
                        <h3 className="font-heading text-base font-bold text-foreground mb-1">{item.title}</h3>
                        <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
                      </div>
                    </motion.div>)}
                </div>

                <Link to={`/${lang}/tours`} className="inline-flex items-center px-8 py-4 bg-primary text-white font-semibold rounded-full hover:bg-primary/90 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 text-base">
                  {t('home.women_only.cta')}
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ── TESTIMONIALS ── */}
        <section className="py-24 bg-muted">
          <div className="container mx-auto px-6">
            <div className="mb-14 text-center">
              <motion.p initial={{
              opacity: 0,
              y: 12
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.5
            }} className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">
                
                {home.testimonials.section_label}
              </motion.p>
              <motion.h2 initial={{
              opacity: 0,
              y: 16
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.1
            }} className="font-heading text-4xl md:text-5xl font-bold text-foreground">
                
                {t('home.testimonials.section_title')}
              </motion.h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {home.testimonials.items.map((testimonial, i) => <motion.div key={testimonial.id} initial={{
              opacity: 0,
              y: 24
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: i * 0.12
            }} className="bg-card rounded-2xl p-8 border border-border hover:-translate-y-1 hover:shadow-lg transition-all duration-300">
                
                  <div className="font-heading text-6xl text-primary/20 leading-none mb-4 select-none">"</div>
                  <p className="text-foreground/80 text-base leading-relaxed mb-6 italic">
                    {testimonial.quote}
                  </p>
                  <div>
                    <p className="font-semibold text-foreground text-sm">{testimonial.author}</p>
                    <p className="text-primary text-xs mt-0.5">{testimonial.tour}</p>
                  </div>
                </motion.div>)}
            </div>
          </div>
        </section>

        {/* ── CTA SECTION ── */}
        <section className="relative py-32 overflow-hidden">
          <div className="absolute inset-0">
            <img src="/airo-assets/images/pages/home/cta-sunset" alt="Cyclist at sunset in Algarve" className="w-full h-full object-cover" loading="lazy" width={1600} height={900} />
            
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent pointer-events-none" />
          </div>

          <div className="relative z-10 container mx-auto px-6">
            <div className="max-w-xl">
              <motion.h2 initial={{
              opacity: 0,
              y: 24
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.7,
              ease: 'easeOut'
            }} className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
                
                {t('home.cta.headline')}
              </motion.h2>
              <motion.p initial={{
              opacity: 0,
              y: 16
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.15
            }} className="text-white/75 text-lg mb-10">
                
                {t('home.cta.subtext')}
              </motion.p>
              <motion.div initial={{
              opacity: 0,
              y: 16
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              duration: 0.6,
              delay: 0.25
            }}>
                
                <Link to={`/${lang}/tours`} className="inline-flex items-center px-10 py-5 bg-primary text-white font-bold rounded-full text-lg hover:bg-primary/90 transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5">
                  
                  {t('home.cta.button')}
                </Link>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </>;
}
