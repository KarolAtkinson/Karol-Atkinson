import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

import { defaultLanguage, languageCodes } from './config.js';

import en from '../../locales/en.json';
import pl from '../../locales/pl.json';
import ar from '../../locales/ar.json';

const resources = {
  en: { translation: en },
  pl: { translation: pl },
  ar: { translation: ar },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: defaultLanguage,
    supportedLngs: languageCodes,
    defaultNS: 'translation',
    ns: ['translation'],
    detection: {
      order: ['path', 'localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
      lookupLocalStorage: 'i18nextLng',
    },
    interpolation: {
      escapeValue: false,
    },
    saveMissing: false,
    debug: false,
  });

export default i18n;
