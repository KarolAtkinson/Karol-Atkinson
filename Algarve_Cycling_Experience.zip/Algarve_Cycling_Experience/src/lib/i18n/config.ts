export interface Language {
  code: string;
  name: string;
  dir: 'ltr' | 'rtl';
}

export const supportedLanguages: Language[] = [
  { code: 'en', name: 'English', dir: 'ltr' },
  { code: 'pl', name: 'Polski', dir: 'ltr' },
  { code: 'ar', name: 'العربية', dir: 'rtl' },
];

export const defaultLanguage = 'en';
export const languageCodes = supportedLanguages.map((lang) => lang.code);

export function isLanguageSupported(code: string): boolean {
  return languageCodes.includes(code);
}

export function getLanguage(code: string): Language | undefined {
  return supportedLanguages.find((lang) => lang.code === code);
}
