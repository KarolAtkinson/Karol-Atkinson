import { z } from 'zod';
export const schemas = {
  home: z.object({
    "hero": z.object({
      "headline_line1": z.string(),
      "headline_line2": z.string(),
      "tagline": z.string(),
      "cta_primary": z.string(),
      "cta_secondary": z.string()
    }),
    "tours": z.object({
      "section_label": z.string(),
      "section_title": z.string(),
      "items": z.array(z.object({
        "id": z.string(),
        "name": z.string(),
        "description": z.string(),
        "duration": z.string(),
        "difficulty": z.string(),
        "price": z.string(),
        "highlight": z.boolean().optional()
      }))
    }),
    "why_us": z.object({
      "section_label": z.string(),
      "section_title": z.string(),
      "intro": z.string(),
      "points": z.array(z.object({
        "id": z.string(),
        "title": z.string(),
        "description": z.string()
      }))
    }),
    "accommodation": z.object({
      "section_label": z.string(),
      "section_title": z.string(),
      "items": z.array(z.object({
        "id": z.string(),
        "name": z.string(),
        "description": z.string()
      }))
    }),
    "testimonials": z.object({
      "section_label": z.string(),
      "section_title": z.string(),
      "items": z.array(z.object({
        "id": z.string(),
        "quote": z.string(),
        "author": z.string(),
        "tour": z.string()
      }))
    }),
    "cta": z.object({
      "headline": z.string(),
      "subtext": z.string(),
      "button": z.string()
    })
  }),
  tours: z.object({
    "hero": z.object({
      "label": z.string(),
      "title": z.string(),
      "subtitle": z.string()
    }),
    "filter_label": z.string(),
    "tours": z.array(z.object({
      "id": z.string(),
      "name": z.string(),
      "slug": z.string(),
      "tagline": z.string(),
      "description": z.string(),
      "highlights": z.array(z.string()),
      "duration": z.string(),
      "distance": z.string(),
      "difficulty": z.string(),
      "group_size": z.string(),
      "price": z.string(),
      "price_note": z.string(),
      "departure": z.string(),
      "image_slot": z.string()
    })),
    "included": z.object({
      "title": z.string(),
      "items": z.array(z.object({
        "id": z.string(),
        "label": z.string(),
        "detail": z.string()
      }))
    }),
    "cta": z.object({
      "title": z.string(),
      "subtitle": z.string(),
      "button": z.string()
    })
  }),
  about: z.object({
    "hero": z.object({
      "eyebrow": z.string(),
      "title": z.string(),
      "subtitle": z.string()
    }),
    "story": z.object({
      "chapter1": z.object({
        "label": z.string(),
        "heading": z.string(),
        "body1": z.string(),
        "body2": z.string()
      }),
      "chapter2": z.object({
        "label": z.string(),
        "heading": z.string(),
        "body1": z.string(),
        "body2": z.string()
      }),
      "chapter3": z.object({
        "label": z.string(),
        "heading": z.string(),
        "body1": z.string(),
        "body2": z.string()
      })
    }),
    "values": z.array(z.object({
      "id": z.string(),
      "icon": z.string(),
      "title": z.string(),
      "description": z.string()
    })),
    "founder": z.object({
      "name": z.string(),
      "role": z.string(),
      "quote": z.string(),
      "bio": z.string(),
      "sign_off": z.string(),
      "polish_note": z.string().optional()
    }),
    "team_member": z.object({
      "name": z.string(),
      "role_pl": z.string(),
      "role_en": z.string(),
      "bio_pl": z.string(),
      "bio_en": z.string()
    }),
    "cta": z.object({
      "heading": z.string(),
      "subheading": z.string(),
      "buttonLabel": z.string(),
      "buttonHref": z.string()
    })
  }),
  accommodation: z.object({
    "hero": z.object({
      "eyebrow": z.string(),
      "title": z.string(),
      "subtitle": z.string()
    }),
    "intro": z.object({
      "heading": z.string(),
      "body": z.string()
    }),
    "villa": z.object({
      "eyebrow": z.string(),
      "name": z.string(),
      "tagline": z.string(),
      "location": z.string(),
      "size": z.string(),
      "description": z.string(),
      "optionExclusive": z.object({
        "label": z.string(),
        "description": z.string()
      }),
      "optionRooms": z.object({
        "label": z.string(),
        "description": z.string()
      }),
      "highlights": z.array(z.object({
        "id": z.string(),
        "icon": z.string(),
        "label": z.string()
      }))
    }),
    "vilaGale": z.object({
      "eyebrow": z.string(),
      "name": z.string(),
      "tagline": z.string(),
      "location": z.string(),
      "price": z.string(),
      "description": z.string(),
      "features": z.array(z.object({
        "id": z.string(),
        "icon": z.string(),
        "label": z.string()
      }))
    }),
    "properties": z.array(z.object({
      "id": z.string(),
      "name": z.string(),
      "type": z.string(),
      "location": z.string(),
      "description": z.string(),
      "highlights": z.array(z.string()),
      "tours": z.array(z.string())
    })),
    "included": z.object({
      "heading": z.string(),
      "items": z.array(z.object({
        "id": z.string(),
        "icon": z.string(),
        "label": z.string()
      }))
    }),
    "cta": z.object({
      "heading": z.string(),
      "subheading": z.string(),
      "buttonLabel": z.string(),
      "buttonHref": z.string()
    })
  }),
  calculator: z.object({
    "hero": z.object({
      "eyebrow": z.string(),
      "title": z.string(),
      "subtitle": z.string()
    }),
    "bike_types": z.array(z.object({
      "id": z.string(),
      "name": z.string(),
      "description": z.string(),
      "price_1day": z.number(),
      "price_3days": z.number(),
      "price_7days": z.number(),
      "price_15days": z.number(),
      "icon": z.string(),
      "image": z.string(),
      "available": z.number(),
      "brand": z.string()
    })),
    "hotel_room": z.object({
      "id": z.string(),
      "name": z.string(),
      "description": z.string(),
      "capacity": z.string(),
      "beds": z.string(),
      "bathroom": z.string(),
      "icon": z.string(),
      "image_slot": z.string(),
      "prices": z.object({
        "jan": z.number(),
        "feb": z.number(),
        "mar": z.number(),
        "easter": z.number(),
        "apr": z.number(),
        "may": z.number(),
        "jun": z.number(),
        "jul": z.number(),
        "motard": z.number(),
        "aug": z.number(),
        "sep": z.number(),
        "oct": z.number(),
        "nov": z.number(),
        "dec": z.number(),
        "xmas": z.number()
      }),
      "price_per_person": z.boolean(),
      "city_tax_tier": z.number()
    }),
    "room_types": z.array(z.object({
      "id": z.string(),
      "name": z.string(),
      "description": z.string(),
      "capacity": z.string(),
      "beds": z.string().optional(),
      "bathroom": z.string().optional(),
      "icon": z.string(),
      "image_slot": z.string().optional(),
      "prices": z.object({
        "jan": z.number(),
        "feb": z.number(),
        "mar": z.number(),
        "easter": z.number(),
        "apr": z.number(),
        "may": z.number(),
        "jun": z.number(),
        "jul": z.number(),
        "motard": z.number(),
        "aug": z.number(),
        "sep": z.number(),
        "oct": z.number(),
        "nov": z.number(),
        "dec": z.number(),
        "xmas": z.number()
      }),
      "price_per_person": z.boolean().optional(),
      "city_tax_tier": z.number()
    })),
    "room_note": z.string(),
    "seasons": z.array(z.object({
      "id": z.string(),
      "label": z.string(),
      "months": z.string(),
      "modifier": z.number(),
      "note": z.string()
    })),
    "extras": z.array(z.object({
      "id": z.string(),
      "name": z.string(),
      "description": z.string(),
      "price": z.number(),
      "icon": z.string()
    })),
    "base_price_per_day": z.number(),
    "accommodation_per_night": z.number(),
    "disclaimer": z.string(),
    "cta": z.object({
      "heading": z.string(),
      "subheading": z.string(),
      "button": z.string()
    })
  }),
  pages: {
    cycling_camp: z.object({
      "days": z.array(z.number()),
      "faqs": z.array(z.number())
    }),
    privacy: z.object({
      "title": z.string(),
      "lastUpdated": z.string(),
      "intro": z.string(),
      "sections": z.array(z.object({
        "heading": z.string(),
        "body": z.array(z.object({
          "text": z.string(),
          "id": z.string()
        })),
        "id": z.string()
      }))
    }),
    terms: z.object({
      "title": z.string(),
      "lastUpdated": z.string(),
      "intro": z.string(),
      "sections": z.array(z.object({
        "heading": z.string(),
        "body": z.array(z.object({
          "text": z.string(),
          "id": z.string()
        })),
        "id": z.string()
      }))
    }),
    calculator: z.object({
      "hero": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "subtitle": z.string()
      }),
      "bike_types": z.array(z.object({
        "id": z.string(),
        "name": z.string(),
        "description": z.string(),
        "price_modifier": z.number(),
        "icon": z.string()
      })),
      "seasons": z.array(z.object({
        "id": z.string(),
        "label": z.string(),
        "months": z.string(),
        "modifier": z.number(),
        "note": z.string()
      })),
      "extras": z.array(z.object({
        "id": z.string(),
        "name": z.string(),
        "description": z.string(),
        "price": z.number(),
        "icon": z.string()
      })),
      "base_price_per_day": z.number(),
      "accommodation_per_night": z.number(),
      "disclaimer": z.string(),
      "cta": z.object({
        "heading": z.string(),
        "subheading": z.string(),
        "button": z.string()
      })
    }),
    rent_a_bike: z.object({
      "special_request": z.object({
        "title": z.string(),
        "description": z.string()
      }),
      "bikes": z.array(z.object({
        "available": z.number().optional(),
        "brand": z.string(),
        "description": z.string(),
        "id": z.string(),
        "image": z.string(),
        "name": z.string(),
        "price_from": z.number().optional(),
        "price_15days": z.number().optional(),
        "price_1day": z.number().optional(),
        "price_3days": z.number().optional(),
        "price_7days": z.number().optional()
      }))
    }),
    ironman_training: z.object({
      "coach": z.object({
        "name": z.string(),
        "trainingLabName": z.string(),
        "trainingLabUrl": z.string()
      }),
      "course": z.object({
        "location": z.string()
      })
    }),
    contact: z.object({
      "seo": z.object({
        "description": z.object({
          "en": z.string(),
          "pl": z.string(),
          "ar": z.string()
        }),
        "title": z.object({
          "en": z.string(),
          "pl": z.string(),
          "ar": z.string()
        })
      })
    })
  }
};
export type Schemas = typeof schemas;