import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bike, Mountain, Zap, Plane, User, Shield, Briefcase,
  ChevronRight, ChevronLeft, RotateCcw, Send, Check,
  Calendar, Users, Sun, Snowflake, Leaf
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useParams } from 'react-router';

// ─── Types ────────────────────────────────────────────────────────────────────

interface BikeType {
  id: string;
  name: string;
  description: string;
  price_modifier: number;
  icon: string;
}

interface Extra {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
}

interface CalculatorContent {
  bike_types: BikeType[];
  extras: Extra[];
  base_price_per_day: number;
  accommodation_per_night: number;
}

interface CalcState {
  startDate: string;
  days: number;
  persons: number;
  bikeId: string;
  extraIds: string[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const BIKE_ICONS: Record<string, React.ReactNode> = {
  road: <Bike size={22} />,
  gravel: <Mountain size={22} />,
  ebike: <Zap size={22} />,
};

const EXTRA_ICONS: Record<string, React.ReactNode> = {
  transfer: <Plane size={18} />,
  guide: <User size={18} />,
  insurance: <Shield size={18} />,
  luggage: <Briefcase size={18} />,
};

function getSeasonFromDate(dateStr: string): 'low' | 'mid' | 'high' {
  if (!dateStr) return 'mid';
  const month = new Date(dateStr).getMonth() + 1; // 1-12
  if (month >= 6 && month <= 9) return 'high';
  if (month === 11 || month <= 3) return 'low';
  return 'mid';
}

function getSeasonModifier(season: 'low' | 'mid' | 'high'): number {
  if (season === 'low') return -0.15;
  if (season === 'high') return 0.20;
  return 0;
}

function SeasonIcon({ season }: { season: 'low' | 'mid' | 'high' }) {
  if (season === 'high') return <Sun size={14} className="text-yellow-500" />;
  if (season === 'low') return <Snowflake size={14} className="text-blue-400" />;
  return <Leaf size={14} className="text-green-500" />;
}

// ─── Step indicators ──────────────────────────────────────────────────────────

const STEPS = ['dates', 'bike', 'extras', 'summary'] as const;

function StepDot({ step, current, done }: { step: number; current: number; done: boolean }) {
  const active = step === current;
  return (
    <div
      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
        done
          ? 'bg-primary text-white'
          : active
          ? 'bg-primary text-white ring-4 ring-primary/20'
          : 'bg-muted text-muted-foreground'
      }`}
    >
      {done ? <Check size={14} /> : step + 1}
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function StayCalculator({ content }: { content: CalculatorContent }) {
  const calculator = content;
  const { t } = useTranslation();
  const { lang = 'en' } = useParams<{ lang: string }>();

  const [step, setStep] = useState<number>(0);
  const [state, setState] = useState<CalcState>({
    startDate: '',
    days: 7,
    persons: 2,
    bikeId: 'road',
    extraIds: [],
  });

  const season = useMemo(() => getSeasonFromDate(state.startDate), [state.startDate]);
  const seasonModifier = useMemo(() => getSeasonModifier(season), [season]);

  // ── Pricing ────────────────────────────────────────────────────────────────

  const selectedBike = calculator.bike_types.find((b) => b.id === state.bikeId);
  const bikeUpgrade = (selectedBike?.price_modifier ?? 0) * state.days;

  const baseTourCost = calculator.base_price_per_day * state.days;
  const accommodationCost = calculator.accommodation_per_night * (state.days - 1);
  const seasonAdjustment = Math.round((baseTourCost + accommodationCost) * seasonModifier);
  const extrasCost = calculator.extras
    .filter((e) => state.extraIds.includes(e.id))
    .reduce((sum, e) => sum + e.price, 0);

  const subtotalPerPerson = baseTourCost + accommodationCost + bikeUpgrade + seasonAdjustment + extrasCost;
  const totalAll = subtotalPerPerson * state.persons;

  // ── Handlers ───────────────────────────────────────────────────────────────

  const toggleExtra = (id: string) => {
    setState((prev) => ({
      ...prev,
      extraIds: prev.extraIds.includes(id)
        ? prev.extraIds.filter((e) => e !== id)
        : [...prev.extraIds, id],
    }));
  };

  const reset = () => {
    setStep(0);
    setState({ startDate: '', days: 7, persons: 2, bikeId: 'road', extraIds: [] });
  };

  const canProceed = () => {
    if (step === 0) return state.days >= 3 && state.persons >= 1;
    return true;
  };

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <div className="w-full max-w-3xl mx-auto">
      {/* Step progress */}
      <div className="flex items-center justify-between mb-10 px-2">
        {STEPS.map((s, i) => (
          <div key={s} className="flex items-center flex-1">
            <div className="flex flex-col items-center gap-1.5">
              <StepDot step={i} current={step} done={i < step} />
              <span className={`text-xs font-medium hidden sm:block transition-colors ${
                i === step ? 'text-primary' : i < step ? 'text-primary/60' : 'text-muted-foreground'
              }`}>
                {t(`calculator.steps.${s}`)}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`flex-1 h-px mx-2 transition-colors duration-500 ${
                i < step ? 'bg-primary' : 'bg-border'
              }`} />
            )}
          </div>
        ))}
      </div>

      {/* Step content */}
      <div className="bg-card rounded-3xl border border-border shadow-sm overflow-hidden">
        <AnimatePresence mode="wait">
          {/* ── STEP 0: Dates & Duration ── */}
          {step === 0 && (
            <motion.div
              key="step-dates"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
              className="p-8 md:p-10"
            >
              <h2 className="font-heading text-2xl font-bold text-foreground mb-1">
                {t('calculator.steps.dates')}
              </h2>
              <p className="text-muted-foreground text-sm mb-8">
                {t('calculator.dates.days_hint')}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {/* Start date */}
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <Calendar size={15} className="text-primary" />
                    {t('calculator.dates.start_label')}
                  </label>
                  <input
                    type="date"
                    value={state.startDate}
                    min={new Date().toISOString().split('T')[0]}
                    onChange={(e) => setState((p) => ({ ...p, startDate: e.target.value }))}
                    className="w-full px-4 py-3 rounded-xl border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                  />
                  {state.startDate && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-1.5 text-xs font-medium mt-0.5"
                    >
                      <SeasonIcon season={season} />
                      <span className={
                        season === 'high' ? 'text-yellow-600' :
                        season === 'low' ? 'text-blue-500' : 'text-green-600'
                      }>
                        {t(`calculator.season_badge.${season}`)}
                      </span>
                    </motion.div>
                  )}
                </div>

                {/* Days */}
                <div className="flex flex-col gap-2">
                  <label className="text-sm font-semibold text-foreground">
                    {t('calculator.dates.days_label')}
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setState((p) => ({ ...p, days: Math.max(3, p.days - 1) }))}
                      className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-lg font-bold hover:bg-muted transition-colors"
                    >
                      −
                    </button>
                    <span className="text-3xl font-bold text-foreground w-12 text-center tabular-nums">
                      {state.days}
                    </span>
                    <button
                      onClick={() => setState((p) => ({ ...p, days: Math.min(21, p.days + 1) }))}
                      className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-lg font-bold hover:bg-muted transition-colors"
                    >
                      +
                    </button>
                  </div>
                  <input
                    type="range"
                    min={3}
                    max={21}
                    value={state.days}
                    onChange={(e) => setState((p) => ({ ...p, days: Number(e.target.value) }))}
                    className="w-full accent-primary mt-1"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>3</span><span>21</span>
                  </div>
                </div>

                {/* Persons */}
                <div className="flex flex-col gap-2 sm:col-span-2">
                  <label className="text-sm font-semibold text-foreground flex items-center gap-2">
                    <Users size={15} className="text-primary" />
                    {t('calculator.dates.persons_label')}
                  </label>
                  <div className="flex flex-wrap gap-3">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                      <button
                        key={n}
                        onClick={() => setState((p) => ({ ...p, persons: n }))}
                        className={`w-12 h-12 rounded-xl border-2 text-sm font-bold transition-all duration-200 ${
                          state.persons === n
                            ? 'border-primary bg-primary text-white shadow-md scale-105'
                            : 'border-border hover:border-primary/50 text-foreground'
                        }`}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ── STEP 1: Bike type ── */}
          {step === 1 && (
            <motion.div
              key="step-bike"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
              className="p-8 md:p-10"
            >
              <h2 className="font-heading text-2xl font-bold text-foreground mb-1">
                {t('calculator.bike.label')}
              </h2>
              <p className="text-muted-foreground text-sm mb-8">
                {t('calculator.steps.bike')}
              </p>

              <div className="grid grid-cols-1 gap-4">
                {calculator.bike_types.map((bike) => {
                  const selected = state.bikeId === bike.id;
                  return (
                    <motion.button
                      key={bike.id}
                      onClick={() => setState((p) => ({ ...p, bikeId: bike.id }))}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                      className={`w-full text-left p-5 rounded-2xl border-2 transition-all duration-200 flex items-start gap-4 ${
                        selected
                          ? 'border-primary bg-primary/5 shadow-md'
                          : 'border-border hover:border-primary/40'
                      }`}
                    >
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${
                        selected ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                      }`}>
                        {BIKE_ICONS[bike.id]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <span className="font-semibold text-foreground">{bike.name}</span>
                          <span className={`text-sm font-bold ${selected ? 'text-primary' : 'text-muted-foreground'}`}>
                            {bike.price_modifier === 0
                              ? t('calculator.bike.included')
                              : t('calculator.bike.extra').replace('{price}', String(bike.price_modifier))}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground mt-0.5">{bike.description}</p>
                      </div>
                      {selected && (
                        <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center shrink-0 mt-0.5">
                          <Check size={11} className="text-white" />
                        </div>
                      )}
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* ── STEP 2: Extras ── */}
          {step === 2 && (
            <motion.div
              key="step-extras"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
              className="p-8 md:p-10"
            >
              <h2 className="font-heading text-2xl font-bold text-foreground mb-1">
                {t('calculator.extras.label')}
              </h2>
              <p className="text-muted-foreground text-sm mb-8">
                {t('calculator.steps.extras')}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {calculator.extras.map((extra) => {
                  const selected = state.extraIds.includes(extra.id);
                  return (
                    <motion.button
                      key={extra.id}
                      onClick={() => toggleExtra(extra.id)}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      className={`text-left p-5 rounded-2xl border-2 transition-all duration-200 ${
                        selected
                          ? 'border-primary bg-primary/5 shadow-md'
                          : 'border-border hover:border-primary/40'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center transition-colors ${
                          selected ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                        }`}>
                          {EXTRA_ICONS[extra.id]}
                        </div>
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                          selected ? 'bg-primary border-primary' : 'border-border'
                        }`}>
                          {selected && <Check size={10} className="text-white" />}
                        </div>
                      </div>
                      <p className="font-semibold text-foreground text-sm">{extra.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 mb-2">{extra.description}</p>
                      <p className={`text-sm font-bold ${selected ? 'text-primary' : 'text-muted-foreground'}`}>
                        €{extra.price} <span className="font-normal text-xs">{t('calculator.extras.per_person')}</span>
                      </p>
                    </motion.button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* ── STEP 3: Summary ── */}
          {step === 3 && (
            <motion.div
              key="step-summary"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
              className="p-8 md:p-10"
            >
              <h2 className="font-heading text-2xl font-bold text-foreground mb-1">
                {t('calculator.summary.title')}
              </h2>
              <p className="text-muted-foreground text-sm mb-8">
                {t('calculator.summary.days').replace('{n}', String(state.days))}
                {' · '}
                {t('calculator.summary.persons').replace('{n}', String(state.persons))}
                {state.startDate && ` · ${new Date(state.startDate).toLocaleDateString(lang === 'pl' ? 'pl-PL' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}`}
              </p>

              {/* Breakdown */}
              <div className="bg-muted/50 rounded-2xl p-6 mb-6 space-y-3">
                <LineItem label={t('calculator.summary.base')} value={`€${baseTourCost.toLocaleString()}`} />
                <LineItem label={`${t('calculator.summary.accommodation')} (${state.days - 1} ${t('calculator.summary.nights').replace('{n}', '')})`} value={`€${accommodationCost.toLocaleString()}`} />
                {bikeUpgrade > 0 && (
                  <LineItem label={t('calculator.summary.bike_upgrade')} value={`€${bikeUpgrade.toLocaleString()}`} />
                )}
                {seasonAdjustment !== 0 && (
                  <LineItem
                    label={t('calculator.summary.season')}
                    value={`${seasonAdjustment > 0 ? '+' : ''}€${seasonAdjustment.toLocaleString()}`}
                    highlight={seasonAdjustment < 0 ? 'green' : 'orange'}
                  />
                )}
                {state.extraIds.length > 0 && (
                  <LineItem label={t('calculator.summary.extras')} value={`€${extrasCost.toLocaleString()}`} />
                )}
                <div className="border-t border-border pt-3 mt-3">
                  <LineItem label={t('calculator.summary.per_person')} value={`€${subtotalPerPerson.toLocaleString()}`} bold />
                </div>
              </div>

              {/* Total */}
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.4 }}
                className="bg-primary rounded-2xl p-6 text-white text-center mb-6"
              >
                <p className="text-white/70 text-sm mb-1">{t('calculator.summary.total')}</p>
                <p className="font-heading text-5xl font-black tracking-tight">
                  €{totalAll.toLocaleString()}
                </p>
                <p className="text-white/60 text-xs mt-2">
                  {t('calculator.summary.persons').replace('{n}', String(state.persons))}
                  {' · '}
                  {t('calculator.summary.days').replace('{n}', String(state.days))}
                </p>
              </motion.div>

              <p className="text-xs text-muted-foreground text-center mb-6 leading-relaxed">
                {t('calculator.summary.disclaimer')}
              </p>

              {/* CTA */}
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={`/${lang}/contact`}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 bg-primary text-white font-semibold rounded-full hover:bg-primary/90 transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5"
                >
                  <Send size={16} />
                  {t('calculator.summary.cta_button')}
                </a>
                <button
                  onClick={reset}
                  className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-4 border-2 border-border text-foreground font-semibold rounded-full hover:bg-muted transition-all duration-200"
                >
                  <RotateCcw size={16} />
                  {t('calculator.summary.reset')}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation buttons */}
        {step < 3 && (
          <div className="px-8 md:px-10 pb-8 flex items-center justify-between gap-4 border-t border-border pt-6">
            <button
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft size={16} />
              Back
            </button>

            {/* Live mini-total */}
            {step > 0 && (
              <div className="text-center">
                <p className="text-xs text-muted-foreground">{t('calculator.summary.per_person')}</p>
                <p className="font-bold text-foreground tabular-nums">€{subtotalPerPerson.toLocaleString()}</p>
              </div>
            )}

            <button
              onClick={() => setStep((s) => Math.min(3, s + 1))}
              disabled={!canProceed()}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-primary text-white text-sm font-semibold hover:bg-primary/90 transition-all duration-200 hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {step === 2 ? t('calculator.steps.summary') : 'Next'}
              <ChevronRight size={16} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Helper component ─────────────────────────────────────────────────────────

function LineItem({
  label,
  value,
  bold = false,
  highlight,
}: {
  label: string;
  value: string;
  bold?: boolean;
  highlight?: 'green' | 'orange';
}) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className={`text-sm ${bold ? 'font-semibold text-foreground' : 'text-muted-foreground'}`}>
        {label}
      </span>
      <span className={`text-sm font-semibold tabular-nums ${
        highlight === 'green' ? 'text-green-600' :
        highlight === 'orange' ? 'text-orange-500' :
        bold ? 'text-foreground text-base' : 'text-foreground'
      }`}>
        {value}
      </span>
    </div>
  );
}
