import { useEffect, useRef, useState } from 'react';
import { Music, Pause, Play, Volume2, VolumeX } from 'lucide-react';

/**
 * Floating music player — royalty-free motivational track.
 * User-initiated only (no autoplay). Persists across page navigation.
 */

const TRACK = {
  url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  title: 'Motivational Ride',
  artist: 'Royalty Free',
};

export default function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const [isExpanded, setIsExpanded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const audio = new Audio(TRACK.url);
    audio.loop = true;
    audio.volume = volume;
    audio.preload = 'none';

    audio.addEventListener('canplay', () => setIsLoaded(true));
    audio.addEventListener('timeupdate', () => {
      if (audio.duration) {
        setProgress((audio.currentTime / audio.duration) * 100);
      }
    });

    audioRef.current = audio;

    return () => {
      audio.pause();
      audio.src = '';
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (audioRef.current) audioRef.current.volume = val;
  };

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio || !audio.duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    audio.currentTime = pct * audio.duration;
  };

  return (
    <div
      className={`fixed bottom-6 right-6 z-50 transition-all duration-300 ${isExpanded ? 'w-64' : 'w-auto'}`}
      style={{ fontFamily: 'var(--font-sans)' }}
    >
      <div
        className="rounded-2xl shadow-2xl overflow-hidden bg-foreground"
        style={{ border: '1px solid hsl(var(--primary) / 0.35)' }}
      >
        {/* Expanded panel */}
        {isExpanded && (
          <div className="px-4 pt-4 pb-2">
            {/* Track info */}
            <div className="flex items-center gap-2 mb-3">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-primary ${isPlaying ? 'animate-spin' : ''}`}
                style={{ animationDuration: '3s' }}
              >
                <Music size={14} className="text-primary-foreground" />
              </div>
              <div className="min-w-0">
                <p className="text-primary-foreground text-xs font-semibold truncate">{TRACK.title}</p>
                <p className="text-xs truncate text-primary-foreground/50">{TRACK.artist}</p>
              </div>
            </div>

            {/* Progress bar */}
            <div
              className="w-full h-1 rounded-full mb-3 cursor-pointer bg-primary-foreground/20"
              onClick={handleProgressClick}
            >
              <div
                className="h-full rounded-full bg-primary transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2 mb-3">
              <button
                onClick={toggleMute}
                className="text-primary-foreground/60 hover:text-primary-foreground transition-colors"
              >
                {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="flex-1 h-1 rounded-full appearance-none cursor-pointer accent-primary"
              />
            </div>

            {/* Royalty-free notice */}
            <p className="text-center text-xs mb-2 text-primary-foreground/30">
              🎵 Royalty-free music
            </p>
          </div>
        )}

        {/* Control bar */}
        <div className="flex items-center gap-2 px-3 py-3">
          {/* Play/Pause */}
          <button
            onClick={togglePlay}
            disabled={!isLoaded && !isPlaying}
            className="w-9 h-9 rounded-full flex items-center justify-center bg-primary transition-all hover:scale-110 active:scale-95 disabled:opacity-50"
            title={isPlaying ? 'Pause' : 'Play music'}
          >
            {isPlaying ? (
              <Pause size={16} className="text-primary-foreground" />
            ) : (
              <Play size={16} className="text-primary-foreground ml-0.5" />
            )}
          </button>

          {/* Expand toggle */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className={`flex items-center gap-1.5 transition-colors ${isExpanded ? 'text-primary' : 'text-primary-foreground/70'}`}
          >
            <Music size={14} />
            {!isExpanded && (
              <span className="text-xs font-medium text-primary-foreground/70">
                {isPlaying ? 'Playing...' : 'Music'}
              </span>
            )}
          </button>

          {/* Playing indicator bars */}
          {isPlaying && (
            <div className="flex items-end gap-0.5 h-4">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-0.5 rounded-full bg-primary"
                  style={{
                    animation: 'musicBar 0.8s ease-in-out infinite alternate',
                    animationDelay: `${i * 0.15}s`,
                    height: '100%',
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <style>{`
        @keyframes musicBar {
          from { transform: scaleY(0.3); }
          to   { transform: scaleY(1); }
        }
      `}</style>
    </div>
  );
}
