"""CV optimiser application package."""

from cv_optimiser.models import MasterBlueprint

__all__ = ["MasterBlueprint"]
